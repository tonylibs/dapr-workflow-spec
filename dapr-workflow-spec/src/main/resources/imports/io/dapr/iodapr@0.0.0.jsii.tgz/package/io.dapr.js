"use strict";
var _a, _b, _c, _d, _e, _f, _g, _h;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkflowAccessPolicySpecRulesWorkflowsOperations = exports.WorkflowAccessPolicy = exports.SubscriptionV2Alpha1 = exports.Subscription = exports.Resiliency = exports.McpServer = exports.HttpEndpointSpecClientTlsRenegotiation = exports.HttpEndpoint = exports.ConfigurationSpecMtlsTokenValidatorsName = exports.Configuration = exports.Component = void 0;
exports.toJson_ComponentProps = toJson_ComponentProps;
exports.toJson_ComponentAuth = toJson_ComponentAuth;
exports.toJson_ComponentSpec = toJson_ComponentSpec;
exports.toJson_ComponentSpecMetadata = toJson_ComponentSpecMetadata;
exports.toJson_ComponentSpecMetadataSecretKeyRef = toJson_ComponentSpecMetadataSecretKeyRef;
exports.toJson_ConfigurationProps = toJson_ConfigurationProps;
exports.toJson_ConfigurationSpec = toJson_ConfigurationSpec;
exports.toJson_ConfigurationSpecAccessControl = toJson_ConfigurationSpecAccessControl;
exports.toJson_ConfigurationSpecApi = toJson_ConfigurationSpecApi;
exports.toJson_ConfigurationSpecAppHttpPipeline = toJson_ConfigurationSpecAppHttpPipeline;
exports.toJson_ConfigurationSpecComponents = toJson_ConfigurationSpecComponents;
exports.toJson_ConfigurationSpecFeatures = toJson_ConfigurationSpecFeatures;
exports.toJson_ConfigurationSpecHttpPipeline = toJson_ConfigurationSpecHttpPipeline;
exports.toJson_ConfigurationSpecLogging = toJson_ConfigurationSpecLogging;
exports.toJson_ConfigurationSpecMetric = toJson_ConfigurationSpecMetric;
exports.toJson_ConfigurationSpecMetrics = toJson_ConfigurationSpecMetrics;
exports.toJson_ConfigurationSpecMtls = toJson_ConfigurationSpecMtls;
exports.toJson_ConfigurationSpecNameResolution = toJson_ConfigurationSpecNameResolution;
exports.toJson_ConfigurationSpecSecrets = toJson_ConfigurationSpecSecrets;
exports.toJson_ConfigurationSpecTracing = toJson_ConfigurationSpecTracing;
exports.toJson_ConfigurationSpecWasm = toJson_ConfigurationSpecWasm;
exports.toJson_ConfigurationSpecWorkflow = toJson_ConfigurationSpecWorkflow;
exports.toJson_ConfigurationSpecAccessControlPolicies = toJson_ConfigurationSpecAccessControlPolicies;
exports.toJson_ConfigurationSpecApiAllowed = toJson_ConfigurationSpecApiAllowed;
exports.toJson_ConfigurationSpecApiDenied = toJson_ConfigurationSpecApiDenied;
exports.toJson_ConfigurationSpecAppHttpPipelineHandlers = toJson_ConfigurationSpecAppHttpPipelineHandlers;
exports.toJson_ConfigurationSpecHttpPipelineHandlers = toJson_ConfigurationSpecHttpPipelineHandlers;
exports.toJson_ConfigurationSpecLoggingApiLogging = toJson_ConfigurationSpecLoggingApiLogging;
exports.toJson_ConfigurationSpecMetricHttp = toJson_ConfigurationSpecMetricHttp;
exports.toJson_ConfigurationSpecMetricRules = toJson_ConfigurationSpecMetricRules;
exports.toJson_ConfigurationSpecMetricsHttp = toJson_ConfigurationSpecMetricsHttp;
exports.toJson_ConfigurationSpecMetricsRules = toJson_ConfigurationSpecMetricsRules;
exports.toJson_ConfigurationSpecMtlsTokenValidators = toJson_ConfigurationSpecMtlsTokenValidators;
exports.toJson_ConfigurationSpecSecretsScopes = toJson_ConfigurationSpecSecretsScopes;
exports.toJson_ConfigurationSpecTracingOtel = toJson_ConfigurationSpecTracingOtel;
exports.toJson_ConfigurationSpecTracingZipkin = toJson_ConfigurationSpecTracingZipkin;
exports.toJson_ConfigurationSpecWorkflowActivityConcurrencyLimits = toJson_ConfigurationSpecWorkflowActivityConcurrencyLimits;
exports.toJson_ConfigurationSpecWorkflowStateRetentionPolicy = toJson_ConfigurationSpecWorkflowStateRetentionPolicy;
exports.toJson_ConfigurationSpecWorkflowWorkflowConcurrencyLimits = toJson_ConfigurationSpecWorkflowWorkflowConcurrencyLimits;
exports.toJson_ConfigurationSpecAccessControlPoliciesOperations = toJson_ConfigurationSpecAccessControlPoliciesOperations;
exports.toJson_ConfigurationSpecAppHttpPipelineHandlersSelector = toJson_ConfigurationSpecAppHttpPipelineHandlersSelector;
exports.toJson_ConfigurationSpecHttpPipelineHandlersSelector = toJson_ConfigurationSpecHttpPipelineHandlersSelector;
exports.toJson_ConfigurationSpecMetricRulesLabels = toJson_ConfigurationSpecMetricRulesLabels;
exports.toJson_ConfigurationSpecMetricsRulesLabels = toJson_ConfigurationSpecMetricsRulesLabels;
exports.toJson_ConfigurationSpecTracingOtelHeaders = toJson_ConfigurationSpecTracingOtelHeaders;
exports.toJson_ConfigurationSpecAppHttpPipelineHandlersSelectorFields = toJson_ConfigurationSpecAppHttpPipelineHandlersSelectorFields;
exports.toJson_ConfigurationSpecHttpPipelineHandlersSelectorFields = toJson_ConfigurationSpecHttpPipelineHandlersSelectorFields;
exports.toJson_ConfigurationSpecTracingOtelHeadersSecretKeyRef = toJson_ConfigurationSpecTracingOtelHeadersSecretKeyRef;
exports.toJson_HttpEndpointProps = toJson_HttpEndpointProps;
exports.toJson_HttpEndpointAuth = toJson_HttpEndpointAuth;
exports.toJson_HttpEndpointSpec = toJson_HttpEndpointSpec;
exports.toJson_HttpEndpointSpecClientTls = toJson_HttpEndpointSpecClientTls;
exports.toJson_HttpEndpointSpecHeaders = toJson_HttpEndpointSpecHeaders;
exports.toJson_HttpEndpointSpecClientTlsCertificate = toJson_HttpEndpointSpecClientTlsCertificate;
exports.toJson_HttpEndpointSpecClientTlsPrivateKey = toJson_HttpEndpointSpecClientTlsPrivateKey;
exports.toJson_HttpEndpointSpecClientTlsRootCa = toJson_HttpEndpointSpecClientTlsRootCa;
exports.toJson_HttpEndpointSpecHeadersSecretKeyRef = toJson_HttpEndpointSpecHeadersSecretKeyRef;
exports.toJson_HttpEndpointSpecClientTlsCertificateSecretKeyRef = toJson_HttpEndpointSpecClientTlsCertificateSecretKeyRef;
exports.toJson_HttpEndpointSpecClientTlsPrivateKeySecretKeyRef = toJson_HttpEndpointSpecClientTlsPrivateKeySecretKeyRef;
exports.toJson_HttpEndpointSpecClientTlsRootCaSecretKeyRef = toJson_HttpEndpointSpecClientTlsRootCaSecretKeyRef;
exports.toJson_McpServerProps = toJson_McpServerProps;
exports.toJson_McpServerSpec = toJson_McpServerSpec;
exports.toJson_McpServerSpecCatalog = toJson_McpServerSpecCatalog;
exports.toJson_McpServerSpecEndpoint = toJson_McpServerSpecEndpoint;
exports.toJson_McpServerSpecMiddleware = toJson_McpServerSpecMiddleware;
exports.toJson_McpServerSpecCatalogOwner = toJson_McpServerSpecCatalogOwner;
exports.toJson_McpServerSpecEndpointSse = toJson_McpServerSpecEndpointSse;
exports.toJson_McpServerSpecEndpointStdio = toJson_McpServerSpecEndpointStdio;
exports.toJson_McpServerSpecEndpointStreamableHttp = toJson_McpServerSpecEndpointStreamableHttp;
exports.toJson_McpServerSpecMiddlewareAfterCallTool = toJson_McpServerSpecMiddlewareAfterCallTool;
exports.toJson_McpServerSpecMiddlewareAfterListTools = toJson_McpServerSpecMiddlewareAfterListTools;
exports.toJson_McpServerSpecMiddlewareBeforeCallTool = toJson_McpServerSpecMiddlewareBeforeCallTool;
exports.toJson_McpServerSpecMiddlewareBeforeListTools = toJson_McpServerSpecMiddlewareBeforeListTools;
exports.toJson_McpServerSpecEndpointSseAuth = toJson_McpServerSpecEndpointSseAuth;
exports.toJson_McpServerSpecEndpointSseHeaders = toJson_McpServerSpecEndpointSseHeaders;
exports.toJson_McpServerSpecEndpointStdioEnv = toJson_McpServerSpecEndpointStdioEnv;
exports.toJson_McpServerSpecEndpointStreamableHttpAuth = toJson_McpServerSpecEndpointStreamableHttpAuth;
exports.toJson_McpServerSpecEndpointStreamableHttpHeaders = toJson_McpServerSpecEndpointStreamableHttpHeaders;
exports.toJson_McpServerSpecMiddlewareAfterCallToolWorkflow = toJson_McpServerSpecMiddlewareAfterCallToolWorkflow;
exports.toJson_McpServerSpecMiddlewareAfterListToolsWorkflow = toJson_McpServerSpecMiddlewareAfterListToolsWorkflow;
exports.toJson_McpServerSpecMiddlewareBeforeCallToolWorkflow = toJson_McpServerSpecMiddlewareBeforeCallToolWorkflow;
exports.toJson_McpServerSpecMiddlewareBeforeListToolsWorkflow = toJson_McpServerSpecMiddlewareBeforeListToolsWorkflow;
exports.toJson_McpServerSpecEndpointSseAuthOauth2 = toJson_McpServerSpecEndpointSseAuthOauth2;
exports.toJson_McpServerSpecEndpointSseAuthSpiffe = toJson_McpServerSpecEndpointSseAuthSpiffe;
exports.toJson_McpServerSpecEndpointSseHeadersSecretKeyRef = toJson_McpServerSpecEndpointSseHeadersSecretKeyRef;
exports.toJson_McpServerSpecEndpointStdioEnvSecretKeyRef = toJson_McpServerSpecEndpointStdioEnvSecretKeyRef;
exports.toJson_McpServerSpecEndpointStreamableHttpAuthOauth2 = toJson_McpServerSpecEndpointStreamableHttpAuthOauth2;
exports.toJson_McpServerSpecEndpointStreamableHttpAuthSpiffe = toJson_McpServerSpecEndpointStreamableHttpAuthSpiffe;
exports.toJson_McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef = toJson_McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef;
exports.toJson_McpServerSpecEndpointSseAuthOauth2SecretKeyRef = toJson_McpServerSpecEndpointSseAuthOauth2SecretKeyRef;
exports.toJson_McpServerSpecEndpointSseAuthSpiffeJwt = toJson_McpServerSpecEndpointSseAuthSpiffeJwt;
exports.toJson_McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef = toJson_McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef;
exports.toJson_McpServerSpecEndpointStreamableHttpAuthSpiffeJwt = toJson_McpServerSpecEndpointStreamableHttpAuthSpiffeJwt;
exports.toJson_ResiliencyProps = toJson_ResiliencyProps;
exports.toJson_ResiliencySpec = toJson_ResiliencySpec;
exports.toJson_ResiliencySpecPolicies = toJson_ResiliencySpecPolicies;
exports.toJson_ResiliencySpecTargets = toJson_ResiliencySpecTargets;
exports.toJson_ResiliencySpecPoliciesCircuitBreakers = toJson_ResiliencySpecPoliciesCircuitBreakers;
exports.toJson_ResiliencySpecPoliciesRetries = toJson_ResiliencySpecPoliciesRetries;
exports.toJson_ResiliencySpecTargetsActors = toJson_ResiliencySpecTargetsActors;
exports.toJson_ResiliencySpecTargetsApps = toJson_ResiliencySpecTargetsApps;
exports.toJson_ResiliencySpecTargetsComponents = toJson_ResiliencySpecTargetsComponents;
exports.toJson_ResiliencySpecPoliciesRetriesMatching = toJson_ResiliencySpecPoliciesRetriesMatching;
exports.toJson_ResiliencySpecTargetsComponentsInbound = toJson_ResiliencySpecTargetsComponentsInbound;
exports.toJson_ResiliencySpecTargetsComponentsOutbound = toJson_ResiliencySpecTargetsComponentsOutbound;
exports.toJson_SubscriptionProps = toJson_SubscriptionProps;
exports.toJson_SubscriptionSpec = toJson_SubscriptionSpec;
exports.toJson_SubscriptionSpecBulkSubscribe = toJson_SubscriptionSpecBulkSubscribe;
exports.toJson_SubscriptionV2Alpha1Props = toJson_SubscriptionV2Alpha1Props;
exports.toJson_SubscriptionV2Alpha1Spec = toJson_SubscriptionV2Alpha1Spec;
exports.toJson_SubscriptionV2Alpha1SpecBulkSubscribe = toJson_SubscriptionV2Alpha1SpecBulkSubscribe;
exports.toJson_SubscriptionV2Alpha1SpecRoutes = toJson_SubscriptionV2Alpha1SpecRoutes;
exports.toJson_SubscriptionV2Alpha1SpecRoutesRules = toJson_SubscriptionV2Alpha1SpecRoutesRules;
exports.toJson_WorkflowAccessPolicyProps = toJson_WorkflowAccessPolicyProps;
exports.toJson_WorkflowAccessPolicySpec = toJson_WorkflowAccessPolicySpec;
exports.toJson_WorkflowAccessPolicySpecRules = toJson_WorkflowAccessPolicySpecRules;
exports.toJson_WorkflowAccessPolicySpecRulesActivities = toJson_WorkflowAccessPolicySpecRulesActivities;
exports.toJson_WorkflowAccessPolicySpecRulesCallers = toJson_WorkflowAccessPolicySpecRulesCallers;
exports.toJson_WorkflowAccessPolicySpecRulesWorkflows = toJson_WorkflowAccessPolicySpecRulesWorkflows;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
// generated by cdk8s
const cdk8s_1 = require("cdk8s");
/**
 * Component describes an Dapr component type.
 *
 * @schema Component
 */
class Component extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "Component".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Component.GVK,
            ...toJson_ComponentProps(props),
        };
    }
    /**
     * Defines a "Component" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Component.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Component.GVK,
            ...toJson_ComponentProps(resolved),
        };
    }
}
exports.Component = Component;
_a = JSII_RTTI_SYMBOL_1;
Component[_a] = { fqn: "iodapr.Component", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "Component"
 */
Component.GVK = {
    apiVersion: 'dapr.io/v1alpha1',
    kind: 'Component',
};
/**
 * Converts an object of type 'ComponentProps' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ComponentProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'auth': toJson_ComponentAuth(obj.auth),
        'scopes': obj.scopes?.map(y => y),
        'spec': toJson_ComponentSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ComponentAuth' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ComponentAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretStore': obj.secretStore,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ComponentSpec' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ComponentSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'ignoreErrors': obj.ignoreErrors,
        'initTimeout': obj.initTimeout,
        'metadata': obj.metadata?.map(y => toJson_ComponentSpecMetadata(y)),
        'type': obj.type,
        'version': obj.version,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ComponentSpecMetadata' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ComponentSpecMetadata(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'envRef': obj.envRef,
        'name': obj.name,
        'secretKeyRef': toJson_ComponentSpecMetadataSecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ComponentSpecMetadataSecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ComponentSpecMetadataSecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * Configuration describes an Dapr configuration setting.
 *
 * @schema Configuration
 */
class Configuration extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "Configuration".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Configuration.GVK,
            ...toJson_ConfigurationProps(props),
        };
    }
    /**
     * Defines a "Configuration" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Configuration.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Configuration.GVK,
            ...toJson_ConfigurationProps(resolved),
        };
    }
}
exports.Configuration = Configuration;
_b = JSII_RTTI_SYMBOL_1;
Configuration[_b] = { fqn: "iodapr.Configuration", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "Configuration"
 */
Configuration.GVK = {
    apiVersion: 'dapr.io/v1alpha1',
    kind: 'Configuration',
};
/**
 * Converts an object of type 'ConfigurationProps' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'spec': toJson_ConfigurationSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpec' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'accessControl': toJson_ConfigurationSpecAccessControl(obj.accessControl),
        'api': toJson_ConfigurationSpecApi(obj.api),
        'appHttpPipeline': toJson_ConfigurationSpecAppHttpPipeline(obj.appHttpPipeline),
        'components': toJson_ConfigurationSpecComponents(obj.components),
        'features': obj.features?.map(y => toJson_ConfigurationSpecFeatures(y)),
        'httpPipeline': toJson_ConfigurationSpecHttpPipeline(obj.httpPipeline),
        'logging': toJson_ConfigurationSpecLogging(obj.logging),
        'metric': toJson_ConfigurationSpecMetric(obj.metric),
        'metrics': toJson_ConfigurationSpecMetrics(obj.metrics),
        'mtls': toJson_ConfigurationSpecMtls(obj.mtls),
        'nameResolution': toJson_ConfigurationSpecNameResolution(obj.nameResolution),
        'secrets': toJson_ConfigurationSpecSecrets(obj.secrets),
        'tracing': toJson_ConfigurationSpecTracing(obj.tracing),
        'wasm': toJson_ConfigurationSpecWasm(obj.wasm),
        'workflow': toJson_ConfigurationSpecWorkflow(obj.workflow),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecAccessControl' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecAccessControl(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'defaultAction': obj.defaultAction,
        'policies': obj.policies?.map(y => toJson_ConfigurationSpecAccessControlPolicies(y)),
        'trustDomain': obj.trustDomain,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecApi' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecApi(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'allowed': obj.allowed?.map(y => toJson_ConfigurationSpecApiAllowed(y)),
        'denied': obj.denied?.map(y => toJson_ConfigurationSpecApiDenied(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecAppHttpPipeline' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecAppHttpPipeline(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'handlers': obj.handlers?.map(y => toJson_ConfigurationSpecAppHttpPipelineHandlers(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecComponents' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecComponents(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'deny': obj.deny?.map(y => y),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecFeatures' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecFeatures(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'enabled': obj.enabled,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecHttpPipeline' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecHttpPipeline(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'handlers': obj.handlers?.map(y => toJson_ConfigurationSpecHttpPipelineHandlers(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecLogging' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecLogging(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'apiLogging': toJson_ConfigurationSpecLoggingApiLogging(obj.apiLogging),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMetric' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMetric(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'enabled': obj.enabled,
        'http': toJson_ConfigurationSpecMetricHttp(obj.http),
        'latencyDistributionBuckets': obj.latencyDistributionBuckets?.map(y => y),
        'recordErrorCodes': obj.recordErrorCodes,
        'rules': obj.rules?.map(y => toJson_ConfigurationSpecMetricRules(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMetrics' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMetrics(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'enabled': obj.enabled,
        'http': toJson_ConfigurationSpecMetricsHttp(obj.http),
        'latencyDistributionBuckets': obj.latencyDistributionBuckets?.map(y => y),
        'recordErrorCodes': obj.recordErrorCodes,
        'rules': obj.rules?.map(y => toJson_ConfigurationSpecMetricsRules(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMtls' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMtls(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'allowedClockSkew': obj.allowedClockSkew,
        'controlPlaneTrustDomain': obj.controlPlaneTrustDomain,
        'enabled': obj.enabled,
        'sentryAddress': obj.sentryAddress,
        'tokenValidators': obj.tokenValidators?.map(y => toJson_ConfigurationSpecMtlsTokenValidators(y)),
        'workloadCertTTL': obj.workloadCertTtl,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecNameResolution' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecNameResolution(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'component': obj.component,
        'configuration': obj.configuration,
        'version': obj.version,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecSecrets' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecSecrets(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'scopes': obj.scopes?.map(y => toJson_ConfigurationSpecSecretsScopes(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecTracing' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecTracing(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'otel': toJson_ConfigurationSpecTracingOtel(obj.otel),
        'samplingRate': obj.samplingRate,
        'stdout': obj.stdout,
        'zipkin': toJson_ConfigurationSpecTracingZipkin(obj.zipkin),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecWasm' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecWasm(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'strictSandbox': obj.strictSandbox,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecWorkflow' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecWorkflow(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'activityConcurrencyLimits': obj.activityConcurrencyLimits?.map(y => toJson_ConfigurationSpecWorkflowActivityConcurrencyLimits(y)),
        'globalMaxConcurrentActivityInvocations': obj.globalMaxConcurrentActivityInvocations,
        'globalMaxConcurrentWorkflowInvocations': obj.globalMaxConcurrentWorkflowInvocations,
        'maxConcurrentActivityInvocations': obj.maxConcurrentActivityInvocations,
        'maxConcurrentWorkflowInvocations': obj.maxConcurrentWorkflowInvocations,
        'stateRetentionPolicy': toJson_ConfigurationSpecWorkflowStateRetentionPolicy(obj.stateRetentionPolicy),
        'workflowConcurrencyLimits': obj.workflowConcurrencyLimits?.map(y => toJson_ConfigurationSpecWorkflowWorkflowConcurrencyLimits(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecAccessControlPolicies' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecAccessControlPolicies(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appId': obj.appId,
        'defaultAction': obj.defaultAction,
        'namespace': obj.namespace,
        'operations': obj.operations?.map(y => toJson_ConfigurationSpecAccessControlPoliciesOperations(y)),
        'trustDomain': obj.trustDomain,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecApiAllowed' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecApiAllowed(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'protocol': obj.protocol,
        'version': obj.version,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecApiDenied' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecApiDenied(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'protocol': obj.protocol,
        'version': obj.version,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecAppHttpPipelineHandlers' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecAppHttpPipelineHandlers(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'selector': toJson_ConfigurationSpecAppHttpPipelineHandlersSelector(obj.selector),
        'type': obj.type,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecHttpPipelineHandlers' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecHttpPipelineHandlers(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'selector': toJson_ConfigurationSpecHttpPipelineHandlersSelector(obj.selector),
        'type': obj.type,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecLoggingApiLogging' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecLoggingApiLogging(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'enabled': obj.enabled,
        'obfuscateURLs': obj.obfuscateUrLs,
        'omitHealthChecks': obj.omitHealthChecks,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMetricHttp' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMetricHttp(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'excludeVerbs': obj.excludeVerbs,
        'increasedCardinality': obj.increasedCardinality,
        'pathMatching': obj.pathMatching?.map(y => y),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMetricRules' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMetricRules(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'labels': obj.labels?.map(y => toJson_ConfigurationSpecMetricRulesLabels(y)),
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMetricsHttp' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMetricsHttp(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'excludeVerbs': obj.excludeVerbs,
        'increasedCardinality': obj.increasedCardinality,
        'pathMatching': obj.pathMatching?.map(y => y),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMetricsRules' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMetricsRules(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'labels': obj.labels?.map(y => toJson_ConfigurationSpecMetricsRulesLabels(y)),
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMtlsTokenValidators' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMtlsTokenValidators(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'options': obj.options,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecSecretsScopes' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecSecretsScopes(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'allowedSecrets': obj.allowedSecrets?.map(y => y),
        'defaultAccess': obj.defaultAccess,
        'deniedSecrets': obj.deniedSecrets?.map(y => y),
        'storeName': obj.storeName,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecTracingOtel' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecTracingOtel(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'endpointAddress': obj.endpointAddress,
        'headers': obj.headers?.map(y => toJson_ConfigurationSpecTracingOtelHeaders(y)),
        'isSecure': obj.isSecure,
        'protocol': obj.protocol,
        'timeout': obj.timeout,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecTracingZipkin' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecTracingZipkin(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'endpointAddress': obj.endpointAddress,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecWorkflowActivityConcurrencyLimits' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecWorkflowActivityConcurrencyLimits(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'maxConcurrent': obj.maxConcurrent,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecWorkflowStateRetentionPolicy' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecWorkflowStateRetentionPolicy(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'anyTerminal': obj.anyTerminal,
        'completed': obj.completed,
        'failed': obj.failed,
        'terminated': obj.terminated,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecWorkflowWorkflowConcurrencyLimits' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecWorkflowWorkflowConcurrencyLimits(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'maxConcurrent': obj.maxConcurrent,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecAccessControlPoliciesOperations' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecAccessControlPoliciesOperations(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'action': obj.action,
        'httpVerb': obj.httpVerb?.map(y => y),
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecAppHttpPipelineHandlersSelector' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecAppHttpPipelineHandlersSelector(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'fields': obj.fields?.map(y => toJson_ConfigurationSpecAppHttpPipelineHandlersSelectorFields(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecHttpPipelineHandlersSelector' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecHttpPipelineHandlersSelector(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'fields': obj.fields?.map(y => toJson_ConfigurationSpecHttpPipelineHandlersSelectorFields(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMetricRulesLabels' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMetricRulesLabels(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'regex': ((obj.regex) === undefined) ? undefined : (Object.entries(obj.regex).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecMetricsRulesLabels' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecMetricsRulesLabels(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'regex': ((obj.regex) === undefined) ? undefined : (Object.entries(obj.regex).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * Name of the validator
 *
 * @schema ConfigurationSpecMtlsTokenValidatorsName
 */
var ConfigurationSpecMtlsTokenValidatorsName;
(function (ConfigurationSpecMtlsTokenValidatorsName) {
    /** jwks */
    ConfigurationSpecMtlsTokenValidatorsName["JWKS"] = "jwks";
})(ConfigurationSpecMtlsTokenValidatorsName || (exports.ConfigurationSpecMtlsTokenValidatorsName = ConfigurationSpecMtlsTokenValidatorsName = {}));
/**
 * Converts an object of type 'ConfigurationSpecTracingOtelHeaders' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecTracingOtelHeaders(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'envRef': obj.envRef,
        'name': obj.name,
        'secretKeyRef': toJson_ConfigurationSpecTracingOtelHeadersSecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecAppHttpPipelineHandlersSelectorFields' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecAppHttpPipelineHandlersSelectorFields(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'field': obj.field,
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecHttpPipelineHandlersSelectorFields' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecHttpPipelineHandlersSelectorFields(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'field': obj.field,
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ConfigurationSpecTracingOtelHeadersSecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ConfigurationSpecTracingOtelHeadersSecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * HTTPEndpoint describes a Dapr HTTPEndpoint type for external service invocation.
This endpoint can be external to Dapr, or external to the environment.
 *
 * @schema HTTPEndpoint
 */
class HttpEndpoint extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "HTTPEndpoint".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...HttpEndpoint.GVK,
            ...toJson_HttpEndpointProps(props),
        };
    }
    /**
     * Defines a "HTTPEndpoint" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...HttpEndpoint.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...HttpEndpoint.GVK,
            ...toJson_HttpEndpointProps(resolved),
        };
    }
}
exports.HttpEndpoint = HttpEndpoint;
_c = JSII_RTTI_SYMBOL_1;
HttpEndpoint[_c] = { fqn: "iodapr.HttpEndpoint", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "HTTPEndpoint"
 */
HttpEndpoint.GVK = {
    apiVersion: 'dapr.io/v1alpha1',
    kind: 'HTTPEndpoint',
};
/**
 * Converts an object of type 'HttpEndpointProps' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'auth': toJson_HttpEndpointAuth(obj.auth),
        'scopes': obj.scopes?.map(y => y),
        'spec': toJson_HttpEndpointSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointAuth' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretStore': obj.secretStore,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpec' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'baseUrl': obj.baseUrl,
        'clientTLS': toJson_HttpEndpointSpecClientTls(obj.clientTls),
        'headers': obj.headers?.map(y => toJson_HttpEndpointSpecHeaders(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTls' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecClientTls(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'certificate': toJson_HttpEndpointSpecClientTlsCertificate(obj.certificate),
        'privateKey': toJson_HttpEndpointSpecClientTlsPrivateKey(obj.privateKey),
        'renegotiation': obj.renegotiation,
        'rootCA': toJson_HttpEndpointSpecClientTlsRootCa(obj.rootCa),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpecHeaders' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecHeaders(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'envRef': obj.envRef,
        'name': obj.name,
        'secretKeyRef': toJson_HttpEndpointSpecHeadersSecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsCertificate' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecClientTlsCertificate(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretKeyRef': toJson_HttpEndpointSpecClientTlsCertificateSecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsPrivateKey' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecClientTlsPrivateKey(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretKeyRef': toJson_HttpEndpointSpecClientTlsPrivateKeySecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * Renegotiation sets the underlying tls negotiation strategy for an http channel.
 *
 * @schema HttpEndpointSpecClientTlsRenegotiation
 */
var HttpEndpointSpecClientTlsRenegotiation;
(function (HttpEndpointSpecClientTlsRenegotiation) {
    /** Never */
    HttpEndpointSpecClientTlsRenegotiation["NEVER"] = "Never";
    /** OnceAsClient */
    HttpEndpointSpecClientTlsRenegotiation["ONCE_AS_CLIENT"] = "OnceAsClient";
    /** FreelyAsClient */
    HttpEndpointSpecClientTlsRenegotiation["FREELY_AS_CLIENT"] = "FreelyAsClient";
})(HttpEndpointSpecClientTlsRenegotiation || (exports.HttpEndpointSpecClientTlsRenegotiation = HttpEndpointSpecClientTlsRenegotiation = {}));
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsRootCa' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecClientTlsRootCa(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'secretKeyRef': toJson_HttpEndpointSpecClientTlsRootCaSecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpecHeadersSecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecHeadersSecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsCertificateSecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecClientTlsCertificateSecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsPrivateKeySecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecClientTlsPrivateKeySecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsRootCaSecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_HttpEndpointSpecClientTlsRootCaSecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * MCPServer describes a Dapr MCPServer resource that declares a connection to
an MCP (Model Context Protocol) server for durable tool execution.
 *
 * @schema MCPServer
 */
class McpServer extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "MCPServer".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...McpServer.GVK,
            ...toJson_McpServerProps(props),
        };
    }
    /**
     * Defines a "MCPServer" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...McpServer.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...McpServer.GVK,
            ...toJson_McpServerProps(resolved),
        };
    }
}
exports.McpServer = McpServer;
_d = JSII_RTTI_SYMBOL_1;
McpServer[_d] = { fqn: "iodapr.McpServer", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "MCPServer"
 */
McpServer.GVK = {
    apiVersion: 'dapr.io/v1alpha1',
    kind: 'MCPServer',
};
/**
 * Converts an object of type 'McpServerProps' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'scopes': obj.scopes?.map(y => y),
        'spec': toJson_McpServerSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpec' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'catalog': toJson_McpServerSpecCatalog(obj.catalog),
        'endpoint': toJson_McpServerSpecEndpoint(obj.endpoint),
        'ignoreErrors': obj.ignoreErrors,
        'middleware': toJson_McpServerSpecMiddleware(obj.middleware),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecCatalog' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecCatalog(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'description': obj.description,
        'displayName': obj.displayName,
        'links': ((obj.links) === undefined) ? undefined : (Object.entries(obj.links).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'owner': toJson_McpServerSpecCatalogOwner(obj.owner),
        'tags': obj.tags?.map(y => y),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpoint' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpoint(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'sse': toJson_McpServerSpecEndpointSse(obj.sse),
        'stdio': toJson_McpServerSpecEndpointStdio(obj.stdio),
        'streamableHTTP': toJson_McpServerSpecEndpointStreamableHttp(obj.streamableHttp),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddleware' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddleware(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'afterCallTool': obj.afterCallTool?.map(y => toJson_McpServerSpecMiddlewareAfterCallTool(y)),
        'afterListTools': obj.afterListTools?.map(y => toJson_McpServerSpecMiddlewareAfterListTools(y)),
        'beforeCallTool': obj.beforeCallTool?.map(y => toJson_McpServerSpecMiddlewareBeforeCallTool(y)),
        'beforeListTools': obj.beforeListTools?.map(y => toJson_McpServerSpecMiddlewareBeforeListTools(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecCatalogOwner' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecCatalogOwner(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'contact': obj.contact,
        'team': obj.team,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointSse' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointSse(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_McpServerSpecEndpointSseAuth(obj.auth),
        'headers': obj.headers?.map(y => toJson_McpServerSpecEndpointSseHeaders(y)),
        'protocolVersion': obj.protocolVersion,
        'timeout': obj.timeout,
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStdio' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStdio(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'args': obj.args?.map(y => y),
        'command': obj.command,
        'env': obj.env?.map(y => toJson_McpServerSpecEndpointStdioEnv(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttp' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStreamableHttp(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'auth': toJson_McpServerSpecEndpointStreamableHttpAuth(obj.auth),
        'headers': obj.headers?.map(y => toJson_McpServerSpecEndpointStreamableHttpHeaders(y)),
        'protocolVersion': obj.protocolVersion,
        'timeout': obj.timeout,
        'url': obj.url,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareAfterCallTool' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddlewareAfterCallTool(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'mutate': obj.mutate,
        'workflow': toJson_McpServerSpecMiddlewareAfterCallToolWorkflow(obj.workflow),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareAfterListTools' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddlewareAfterListTools(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'mutate': obj.mutate,
        'workflow': toJson_McpServerSpecMiddlewareAfterListToolsWorkflow(obj.workflow),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareBeforeCallTool' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddlewareBeforeCallTool(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'mutate': obj.mutate,
        'workflow': toJson_McpServerSpecMiddlewareBeforeCallToolWorkflow(obj.workflow),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareBeforeListTools' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddlewareBeforeListTools(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'workflow': toJson_McpServerSpecMiddlewareBeforeListToolsWorkflow(obj.workflow),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuth' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointSseAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'oauth2': toJson_McpServerSpecEndpointSseAuthOauth2(obj.oauth2),
        'secretStore': obj.secretStore,
        'spiffe': toJson_McpServerSpecEndpointSseAuthSpiffe(obj.spiffe),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseHeaders' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointSseHeaders(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'envRef': obj.envRef,
        'name': obj.name,
        'secretKeyRef': toJson_McpServerSpecEndpointSseHeadersSecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStdioEnv' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStdioEnv(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'envRef': obj.envRef,
        'name': obj.name,
        'secretKeyRef': toJson_McpServerSpecEndpointStdioEnvSecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuth' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStreamableHttpAuth(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'oauth2': toJson_McpServerSpecEndpointStreamableHttpAuthOauth2(obj.oauth2),
        'secretStore': obj.secretStore,
        'spiffe': toJson_McpServerSpecEndpointStreamableHttpAuthSpiffe(obj.spiffe),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpHeaders' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStreamableHttpHeaders(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'envRef': obj.envRef,
        'name': obj.name,
        'secretKeyRef': toJson_McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef(obj.secretKeyRef),
        'value': obj.value,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareAfterCallToolWorkflow' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddlewareAfterCallToolWorkflow(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appID': obj.appId,
        'workflowName': obj.workflowName,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareAfterListToolsWorkflow' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddlewareAfterListToolsWorkflow(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appID': obj.appId,
        'workflowName': obj.workflowName,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareBeforeCallToolWorkflow' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddlewareBeforeCallToolWorkflow(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appID': obj.appId,
        'workflowName': obj.workflowName,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareBeforeListToolsWorkflow' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecMiddlewareBeforeListToolsWorkflow(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appID': obj.appId,
        'workflowName': obj.workflowName,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuthOauth2' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointSseAuthOauth2(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audience': obj.audience,
        'clientID': obj.clientId,
        'issuer': obj.issuer,
        'scopes': obj.scopes?.map(y => y),
        'secretKeyRef': toJson_McpServerSpecEndpointSseAuthOauth2SecretKeyRef(obj.secretKeyRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuthSpiffe' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointSseAuthSpiffe(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'jwt': toJson_McpServerSpecEndpointSseAuthSpiffeJwt(obj.jwt),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseHeadersSecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointSseHeadersSecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStdioEnvSecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStdioEnvSecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuthOauth2' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStreamableHttpAuthOauth2(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audience': obj.audience,
        'clientID': obj.clientId,
        'issuer': obj.issuer,
        'scopes': obj.scopes?.map(y => y),
        'secretKeyRef': toJson_McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef(obj.secretKeyRef),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuthSpiffe' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStreamableHttpAuthSpiffe(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'jwt': toJson_McpServerSpecEndpointStreamableHttpAuthSpiffeJwt(obj.jwt),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuthOauth2SecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointSseAuthOauth2SecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuthSpiffeJwt' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointSseAuthSpiffeJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audience': obj.audience,
        'header': obj.header,
        'headerValuePrefix': obj.headerValuePrefix,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'key': obj.key,
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuthSpiffeJwt' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_McpServerSpecEndpointStreamableHttpAuthSpiffeJwt(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'audience': obj.audience,
        'header': obj.header,
        'headerValuePrefix': obj.headerValuePrefix,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 *
 *
 * @schema Resiliency
 */
class Resiliency extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "Resiliency".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Resiliency.GVK,
            ...toJson_ResiliencyProps(props),
        };
    }
    /**
     * Defines a "Resiliency" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Resiliency.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Resiliency.GVK,
            ...toJson_ResiliencyProps(resolved),
        };
    }
}
exports.Resiliency = Resiliency;
_e = JSII_RTTI_SYMBOL_1;
Resiliency[_e] = { fqn: "iodapr.Resiliency", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "Resiliency"
 */
Resiliency.GVK = {
    apiVersion: 'dapr.io/v1alpha1',
    kind: 'Resiliency',
};
/**
 * Converts an object of type 'ResiliencyProps' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencyProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'scopes': obj.scopes?.map(y => y),
        'spec': toJson_ResiliencySpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpec' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'policies': toJson_ResiliencySpecPolicies(obj.policies),
        'targets': toJson_ResiliencySpecTargets(obj.targets),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecPolicies' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecPolicies(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'circuitBreakers': ((obj.circuitBreakers) === undefined) ? undefined : (Object.entries(obj.circuitBreakers).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: toJson_ResiliencySpecPoliciesCircuitBreakers(i[1]) }), {})),
        'retries': ((obj.retries) === undefined) ? undefined : (Object.entries(obj.retries).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: toJson_ResiliencySpecPoliciesRetries(i[1]) }), {})),
        'timeouts': ((obj.timeouts) === undefined) ? undefined : (Object.entries(obj.timeouts).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecTargets' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecTargets(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'actors': ((obj.actors) === undefined) ? undefined : (Object.entries(obj.actors).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: toJson_ResiliencySpecTargetsActors(i[1]) }), {})),
        'apps': ((obj.apps) === undefined) ? undefined : (Object.entries(obj.apps).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: toJson_ResiliencySpecTargetsApps(i[1]) }), {})),
        'components': ((obj.components) === undefined) ? undefined : (Object.entries(obj.components).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: toJson_ResiliencySpecTargetsComponents(i[1]) }), {})),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecPoliciesCircuitBreakers' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecPoliciesCircuitBreakers(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'interval': obj.interval,
        'maxRequests': obj.maxRequests,
        'timeout': obj.timeout,
        'trip': obj.trip,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecPoliciesRetries' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecPoliciesRetries(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'duration': obj.duration,
        'matching': toJson_ResiliencySpecPoliciesRetriesMatching(obj.matching),
        'maxInterval': obj.maxInterval,
        'maxRetries': obj.maxRetries,
        'policy': obj.policy,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecTargetsActors' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecTargetsActors(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'circuitBreaker': obj.circuitBreaker,
        'circuitBreakerCacheSize': obj.circuitBreakerCacheSize,
        'circuitBreakerScope': obj.circuitBreakerScope,
        'retry': obj.retry,
        'timeout': obj.timeout,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecTargetsApps' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecTargetsApps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'circuitBreaker': obj.circuitBreaker,
        'circuitBreakerCacheSize': obj.circuitBreakerCacheSize,
        'retry': obj.retry,
        'timeout': obj.timeout,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecTargetsComponents' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecTargetsComponents(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'inbound': toJson_ResiliencySpecTargetsComponentsInbound(obj.inbound),
        'outbound': toJson_ResiliencySpecTargetsComponentsOutbound(obj.outbound),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecPoliciesRetriesMatching' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecPoliciesRetriesMatching(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'gRPCStatusCodes': obj.gRpcStatusCodes,
        'httpStatusCodes': obj.httpStatusCodes,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecTargetsComponentsInbound' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecTargetsComponentsInbound(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'circuitBreaker': obj.circuitBreaker,
        'retry': obj.retry,
        'timeout': obj.timeout,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'ResiliencySpecTargetsComponentsOutbound' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_ResiliencySpecTargetsComponentsOutbound(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'circuitBreaker': obj.circuitBreaker,
        'retry': obj.retry,
        'timeout': obj.timeout,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * Subscription describes an pub/sub event subscription.
 *
 * @schema Subscription
 */
class Subscription extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "Subscription".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...Subscription.GVK,
            ...toJson_SubscriptionProps(props),
        };
    }
    /**
     * Defines a "Subscription" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...Subscription.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...Subscription.GVK,
            ...toJson_SubscriptionProps(resolved),
        };
    }
}
exports.Subscription = Subscription;
_f = JSII_RTTI_SYMBOL_1;
Subscription[_f] = { fqn: "iodapr.Subscription", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "Subscription"
 */
Subscription.GVK = {
    apiVersion: 'dapr.io/v1alpha1',
    kind: 'Subscription',
};
/**
 * Converts an object of type 'SubscriptionProps' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_SubscriptionProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'scopes': obj.scopes?.map(y => y),
        'spec': toJson_SubscriptionSpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'SubscriptionSpec' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_SubscriptionSpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'bulkSubscribe': toJson_SubscriptionSpecBulkSubscribe(obj.bulkSubscribe),
        'deadLetterTopic': obj.deadLetterTopic,
        'metadata': ((obj.metadata) === undefined) ? undefined : (Object.entries(obj.metadata).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'pubsubname': obj.pubsubname,
        'route': obj.route,
        'topic': obj.topic,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'SubscriptionSpecBulkSubscribe' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_SubscriptionSpecBulkSubscribe(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'enabled': obj.enabled,
        'maxAwaitDurationMs': obj.maxAwaitDurationMs,
        'maxMessagesCount': obj.maxMessagesCount,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * Subscription describes an pub/sub event subscription.
 *
 * @schema SubscriptionV2Alpha1
 */
class SubscriptionV2Alpha1 extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "SubscriptionV2Alpha1".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...SubscriptionV2Alpha1.GVK,
            ...toJson_SubscriptionV2Alpha1Props(props),
        };
    }
    /**
     * Defines a "SubscriptionV2Alpha1" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...SubscriptionV2Alpha1.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...SubscriptionV2Alpha1.GVK,
            ...toJson_SubscriptionV2Alpha1Props(resolved),
        };
    }
}
exports.SubscriptionV2Alpha1 = SubscriptionV2Alpha1;
_g = JSII_RTTI_SYMBOL_1;
SubscriptionV2Alpha1[_g] = { fqn: "iodapr.SubscriptionV2Alpha1", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "SubscriptionV2Alpha1"
 */
SubscriptionV2Alpha1.GVK = {
    apiVersion: 'dapr.io/v2alpha1',
    kind: 'Subscription',
};
/**
 * Converts an object of type 'SubscriptionV2Alpha1Props' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_SubscriptionV2Alpha1Props(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'scopes': obj.scopes?.map(y => y),
        'spec': toJson_SubscriptionV2Alpha1Spec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1Spec' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_SubscriptionV2Alpha1Spec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'bulkSubscribe': toJson_SubscriptionV2Alpha1SpecBulkSubscribe(obj.bulkSubscribe),
        'deadLetterTopic': obj.deadLetterTopic,
        'metadata': ((obj.metadata) === undefined) ? undefined : (Object.entries(obj.metadata).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {})),
        'pubsubname': obj.pubsubname,
        'routes': toJson_SubscriptionV2Alpha1SpecRoutes(obj.routes),
        'topic': obj.topic,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1SpecBulkSubscribe' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_SubscriptionV2Alpha1SpecBulkSubscribe(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'enabled': obj.enabled,
        'maxAwaitDurationMs': obj.maxAwaitDurationMs,
        'maxMessagesCount': obj.maxMessagesCount,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1SpecRoutes' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_SubscriptionV2Alpha1SpecRoutes(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'default': obj.default,
        'rules': obj.rules?.map(y => toJson_SubscriptionV2Alpha1SpecRoutesRules(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1SpecRoutesRules' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_SubscriptionV2Alpha1SpecRoutesRules(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'match': obj.match,
        'path': obj.path,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * WorkflowAccessPolicy controls which app IDs are permitted to schedule
specific workflows and activities on a target application.
 *
 * @schema WorkflowAccessPolicy
 */
class WorkflowAccessPolicy extends cdk8s_1.ApiObject {
    /**
     * Renders a Kubernetes manifest for "WorkflowAccessPolicy".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props = {}) {
        return {
            ...WorkflowAccessPolicy.GVK,
            ...toJson_WorkflowAccessPolicyProps(props),
        };
    }
    /**
     * Defines a "WorkflowAccessPolicy" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope, id, props = {}) {
        super(scope, id, {
            ...WorkflowAccessPolicy.GVK,
            ...props,
        });
    }
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson() {
        const resolved = super.toJson();
        return {
            ...WorkflowAccessPolicy.GVK,
            ...toJson_WorkflowAccessPolicyProps(resolved),
        };
    }
}
exports.WorkflowAccessPolicy = WorkflowAccessPolicy;
_h = JSII_RTTI_SYMBOL_1;
WorkflowAccessPolicy[_h] = { fqn: "iodapr.WorkflowAccessPolicy", version: "0.0.0" };
/**
 * Returns the apiVersion and kind for "WorkflowAccessPolicy"
 */
WorkflowAccessPolicy.GVK = {
    apiVersion: 'dapr.io/v1alpha1',
    kind: 'WorkflowAccessPolicy',
};
/**
 * Converts an object of type 'WorkflowAccessPolicyProps' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_WorkflowAccessPolicyProps(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'metadata': obj.metadata,
        'scopes': obj.scopes?.map(y => y),
        'spec': toJson_WorkflowAccessPolicySpec(obj.spec),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpec' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_WorkflowAccessPolicySpec(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'rules': obj.rules?.map(y => toJson_WorkflowAccessPolicySpecRules(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpecRules' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_WorkflowAccessPolicySpecRules(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'activities': obj.activities?.map(y => toJson_WorkflowAccessPolicySpecRulesActivities(y)),
        'callers': obj.callers?.map(y => toJson_WorkflowAccessPolicySpecRulesCallers(y)),
        'workflows': obj.workflows?.map(y => toJson_WorkflowAccessPolicySpecRulesWorkflows(y)),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpecRulesActivities' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_WorkflowAccessPolicySpecRulesActivities(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpecRulesCallers' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_WorkflowAccessPolicySpecRulesCallers(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'appID': obj.appId,
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpecRulesWorkflows' to JSON representation.
 */
/* eslint-disable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
function toJson_WorkflowAccessPolicySpecRulesWorkflows(obj) {
    if (obj === undefined) {
        return undefined;
    }
    const result = {
        'name': obj.name,
        'operations': obj.operations?.map(y => y),
    };
    // filter undefined values
    return Object.entries(result).reduce((r, i) => (i[1] === undefined) ? r : ({ ...r, [i[0]]: i[1] }), {});
}
/* eslint-enable max-len, @stylistic/max-len, quote-props, @stylistic/quote-props */
/**
 * WorkflowOperation is the specific workflow operation being controlled.
 *
 * @schema WorkflowAccessPolicySpecRulesWorkflowsOperations
 */
var WorkflowAccessPolicySpecRulesWorkflowsOperations;
(function (WorkflowAccessPolicySpecRulesWorkflowsOperations) {
    /** schedule */
    WorkflowAccessPolicySpecRulesWorkflowsOperations["SCHEDULE"] = "schedule";
    /** terminate */
    WorkflowAccessPolicySpecRulesWorkflowsOperations["TERMINATE"] = "terminate";
    /** raise */
    WorkflowAccessPolicySpecRulesWorkflowsOperations["RAISE"] = "raise";
    /** pause */
    WorkflowAccessPolicySpecRulesWorkflowsOperations["PAUSE"] = "pause";
    /** resume */
    WorkflowAccessPolicySpecRulesWorkflowsOperations["RESUME"] = "resume";
    /** purge */
    WorkflowAccessPolicySpecRulesWorkflowsOperations["PURGE"] = "purge";
    /** get */
    WorkflowAccessPolicySpecRulesWorkflowsOperations["GET"] = "get";
    /** rerun */
    WorkflowAccessPolicySpecRulesWorkflowsOperations["RERUN"] = "rerun";
})(WorkflowAccessPolicySpecRulesWorkflowsOperations || (exports.WorkflowAccessPolicySpecRulesWorkflowsOperations = WorkflowAccessPolicySpecRulesWorkflowsOperations = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW8uZGFwci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImlvLmRhcHIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQThGQSxzREFVQztBQW1CRCxvREFPQztBQXVDRCxvREFXQztBQTBDRCxvRUFVQztBQTRCRCw0RkFRQztBQWlGRCw4REFRQztBQXFIRCw0REFxQkM7QUE2QkQsc0ZBU0M7QUE0QkQsa0VBUUM7QUFtQkQsMEZBT0M7QUFxQkQsZ0ZBT0M7QUF3QkQsNEVBUUM7QUFtQkQsb0ZBT0M7QUFxQkQsMEVBT0M7QUE4Q0Qsd0VBV0M7QUE4Q0QsMEVBV0M7QUFnREQsb0VBWUM7QUErQkQsd0ZBU0M7QUFtQkQsMEVBT0M7QUFzQ0QsMEVBVUM7QUF1QkQsb0VBT0M7QUEyRUQsNEVBYUM7QUF1Q0Qsc0dBV0M7QUE2QkQsZ0ZBU0M7QUE2QkQsOEVBU0M7QUErQkQsMEdBU0M7QUErQkQsb0dBU0M7QUF1Q0QsOEZBU0M7QUFrQ0QsZ0ZBU0M7QUF3QkQsa0ZBUUM7QUFrQ0Qsa0ZBU0M7QUF3QkQsb0ZBUUM7QUE0QkQsa0dBUUM7QUFrQ0Qsc0ZBVUM7QUE0Q0Qsa0ZBV0M7QUFtQkQsc0ZBT0M7QUE4QkQsOEhBUUM7QUFnREQsb0hBVUM7QUE4QkQsOEhBUUM7QUE2QkQsMEhBU0M7QUFtQkQsMEhBT0M7QUFtQkQsb0hBT0M7QUF3QkQsOEZBUUM7QUF3QkQsZ0dBUUM7QUFvREQsZ0dBVUM7QUF3QkQsc0lBUUM7QUF3QkQsZ0lBUUM7QUE0QkQsd0hBUUM7QUErRkQsNERBVUM7QUFtQkQsMERBT0M7QUErQkQsMERBU0M7QUEwQ0QsNEVBVUM7QUEwQ0Qsd0VBVUM7QUE0QkQsa0dBUUM7QUE0QkQsZ0dBUUM7QUEwQ0Qsd0ZBUUM7QUE0QkQsZ0dBUUM7QUE0QkQsMEhBUUM7QUE0QkQsd0hBUUM7QUE0QkQsZ0hBUUM7QUF3RkQsc0RBU0M7QUE2Q0Qsb0RBVUM7QUE0Q0Qsa0VBV0M7QUFtQ0Qsb0VBU0M7QUFtREQsd0VBVUM7QUF3QkQsNEVBUUM7QUFtREQsMEVBV0M7QUFrQ0QsOEVBU0M7QUFxREQsZ0dBV0M7QUFrQ0Qsa0dBUUM7QUFrQ0Qsb0dBUUM7QUFrQ0Qsb0dBUUM7QUFxQkQsc0dBT0M7QUF1Q0Qsa0ZBU0M7QUEwQ0Qsd0ZBVUM7QUEwQ0Qsb0ZBVUM7QUF1Q0Qsd0dBU0M7QUEwQ0QsOEdBVUM7QUE2QkQsa0hBUUM7QUE2QkQsb0hBUUM7QUE2QkQsb0hBUUM7QUE2QkQsc0hBUUM7QUFrREQsOEZBV0M7QUFzQkQsOEZBT0M7QUE0QkQsZ0hBUUM7QUE0QkQsNEdBUUM7QUFrREQsb0hBV0M7QUFzQkQsb0hBT0M7QUE0QkQsc0lBUUM7QUE0QkQsc0hBUUM7QUFtQ0Qsb0dBU0M7QUE0QkQsNElBUUM7QUFtQ0QsMEhBU0M7QUFrRkQsd0RBU0M7QUFzQkQsc0RBUUM7QUEyQkQsc0VBU0M7QUEyQkQsb0VBU0M7QUFnQ0Qsb0dBVUM7QUF1Q0Qsb0ZBV0M7QUFxQ0QsZ0ZBV0M7QUFnQ0QsNEVBVUM7QUFzQkQsd0ZBUUM7QUE0QkQsb0dBUUM7QUEyQkQsc0dBU0M7QUEyQkQsd0dBU0M7QUFzRkQsNERBU0M7QUE4Q0QsMERBWUM7QUE2QkQsb0ZBU0M7QUFzRkQsNEVBU0M7QUF3REQsMEVBWUM7QUE2QkQsb0dBU0M7QUE0QkQsc0ZBUUM7QUFpQ0QsZ0dBUUM7QUF3RkQsNEVBU0M7QUFxQkQsMEVBT0M7QUFzQ0Qsb0ZBU0M7QUF1QkQsd0dBT0M7QUFxQkQsa0dBT0M7QUE2QkQsc0dBUUM7O0FBM3pLRCxxQkFBcUI7QUFDckIsaUNBQXVFO0FBSXZFOzs7O0dBSUc7QUFDSCxNQUFhLFNBQVUsU0FBUSxpQkFBUztJQVN0Qzs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQXdCLEVBQUU7UUFDL0MsT0FBTztZQUNMLEdBQUcsU0FBUyxDQUFDLEdBQUc7WUFDaEIsR0FBRyxxQkFBcUIsQ0FBQyxLQUFLLENBQUM7U0FDaEMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQW1CLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQXdCLEVBQUU7UUFDekUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixHQUFHLFNBQVMsQ0FBQyxHQUFHO1lBQ2hCLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNhLE1BQU07UUFDcEIsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLE9BQU87WUFDTCxHQUFHLFNBQVMsQ0FBQyxHQUFHO1lBQ2hCLEdBQUcscUJBQXFCLENBQUMsUUFBUSxDQUFDO1NBQ25DLENBQUM7SUFDSixDQUFDOztBQTlDSCw4QkErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixhQUFHLEdBQXFCO0lBQzdDLFVBQVUsRUFBRSxrQkFBa0I7SUFDOUIsSUFBSSxFQUFFLFdBQVc7Q0FDbEIsQ0FBQTtBQXlFSDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixxQkFBcUIsQ0FBQyxHQUErQjtJQUNuRSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixNQUFNLEVBQUUsb0JBQW9CLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUN0QyxRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDakMsTUFBTSxFQUFFLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDdkMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBZUQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isb0JBQW9CLENBQUMsR0FBOEI7SUFDakUsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixhQUFhLEVBQUUsR0FBRyxDQUFDLFdBQVc7S0FDL0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG9CQUFvQixDQUFDLEdBQThCO0lBQ2pFLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsY0FBYyxFQUFFLEdBQUcsQ0FBQyxZQUFZO1FBQ2hDLGFBQWEsRUFBRSxHQUFHLENBQUMsV0FBVztRQUM5QixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRSxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO0tBQ3ZCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXNDRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw0QkFBNEIsQ0FBQyxHQUFzQztJQUNqRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsY0FBYyxFQUFFLHdDQUF3QyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFDMUUsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO0tBQ25CLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQix3Q0FBd0MsQ0FBQyxHQUFrRDtJQUN6RyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCxvRkFBb0Y7QUFHcEY7Ozs7R0FJRztBQUNILE1BQWEsYUFBYyxTQUFRLGlCQUFTO0lBUzFDOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBNEIsRUFBRTtRQUNuRCxPQUFPO1lBQ0wsR0FBRyxhQUFhLENBQUMsR0FBRztZQUNwQixHQUFHLHlCQUF5QixDQUFDLEtBQUssQ0FBQztTQUNwQyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsUUFBNEIsRUFBRTtRQUM3RSxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLEdBQUcsYUFBYSxDQUFDLEdBQUc7WUFDcEIsR0FBRyxLQUFLO1NBQ1QsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ2EsTUFBTTtRQUNwQixNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFaEMsT0FBTztZQUNMLEdBQUcsYUFBYSxDQUFDLEdBQUc7WUFDcEIsR0FBRyx5QkFBeUIsQ0FBQyxRQUFRLENBQUM7U0FDdkMsQ0FBQztJQUNKLENBQUM7O0FBOUNILHNDQStDQzs7O0FBOUNDOztHQUVHO0FBQ29CLGlCQUFHLEdBQXFCO0lBQzdDLFVBQVUsRUFBRSxrQkFBa0I7SUFDOUIsSUFBSSxFQUFFLGVBQWU7Q0FDdEIsQ0FBQTtBQTZESDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQix5QkFBeUIsQ0FBQyxHQUFtQztJQUMzRSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixNQUFNLEVBQUUsd0JBQXdCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztLQUMzQyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFpSEQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isd0JBQXdCLENBQUMsR0FBa0M7SUFDekUsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixlQUFlLEVBQUUscUNBQXFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQztRQUN6RSxLQUFLLEVBQUUsMkJBQTJCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztRQUMzQyxpQkFBaUIsRUFBRSx1Q0FBdUMsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDO1FBQy9FLFlBQVksRUFBRSxrQ0FBa0MsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQ2hFLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFLGNBQWMsRUFBRSxvQ0FBb0MsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBQ3RFLFNBQVMsRUFBRSwrQkFBK0IsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO1FBQ3ZELFFBQVEsRUFBRSw4QkFBOEIsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQ3BELFNBQVMsRUFBRSwrQkFBK0IsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO1FBQ3ZELE1BQU0sRUFBRSw0QkFBNEIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQzlDLGdCQUFnQixFQUFFLHNDQUFzQyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFDNUUsU0FBUyxFQUFFLCtCQUErQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7UUFDdkQsU0FBUyxFQUFFLCtCQUErQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7UUFDdkQsTUFBTSxFQUFFLDRCQUE0QixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDOUMsVUFBVSxFQUFFLGdDQUFnQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7S0FDM0QsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBeUJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHFDQUFxQyxDQUFDLEdBQStDO0lBQ25HLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsZUFBZSxFQUFFLEdBQUcsQ0FBQyxhQUFhO1FBQ2xDLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLDZDQUE2QyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BGLGFBQWEsRUFBRSxHQUFHLENBQUMsV0FBVztLQUMvQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF3QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsMkJBQTJCLENBQUMsR0FBcUM7SUFDL0UsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2RSxRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNyRSxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFlRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQix1Q0FBdUMsQ0FBQyxHQUFpRDtJQUN2RyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLCtDQUErQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3ZGLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWlCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixrQ0FBa0MsQ0FBQyxHQUE0QztJQUM3RixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztLQUM5QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsZ0NBQWdDLENBQUMsR0FBMEM7SUFDekYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU87UUFDdEIsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWVEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG9DQUFvQyxDQUFDLEdBQThDO0lBQ2pHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsNENBQTRDLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDcEYsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBaUJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLCtCQUErQixDQUFDLEdBQXlDO0lBQ3ZGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsWUFBWSxFQUFFLHlDQUF5QyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7S0FDeEUsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMENEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDhCQUE4QixDQUFDLEdBQXdDO0lBQ3JGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO1FBQ3RCLE1BQU0sRUFBRSxrQ0FBa0MsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ3BELDRCQUE0QixFQUFFLEdBQUcsQ0FBQywwQkFBMEIsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDekUsa0JBQWtCLEVBQUUsR0FBRyxDQUFDLGdCQUFnQjtRQUN4QyxPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNyRSxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUEwQ0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsK0JBQStCLENBQUMsR0FBeUM7SUFDdkYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU87UUFDdEIsTUFBTSxFQUFFLG1DQUFtQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDckQsNEJBQTRCLEVBQUUsR0FBRyxDQUFDLDBCQUEwQixFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN6RSxrQkFBa0IsRUFBRSxHQUFHLENBQUMsZ0JBQWdCO1FBQ3hDLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLG9DQUFvQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3RFLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTRDRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw0QkFBNEIsQ0FBQyxHQUFzQztJQUNqRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxnQkFBZ0I7UUFDeEMseUJBQXlCLEVBQUUsR0FBRyxDQUFDLHVCQUF1QjtRQUN0RCxTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU87UUFDdEIsZUFBZSxFQUFFLEdBQUcsQ0FBQyxhQUFhO1FBQ2xDLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxlQUFlLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsMkNBQTJDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEcsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLGVBQWU7S0FDdkMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMkJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHNDQUFzQyxDQUFDLEdBQWdEO0lBQ3JHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLGVBQWUsRUFBRSxHQUFHLENBQUMsYUFBYTtRQUNsQyxTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU87S0FDdkIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBZUQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsK0JBQStCLENBQUMsR0FBeUM7SUFDdkYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUN6RSxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQ0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsK0JBQStCLENBQUMsR0FBeUM7SUFDdkYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsbUNBQW1DLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztRQUNyRCxjQUFjLEVBQUUsR0FBRyxDQUFDLFlBQVk7UUFDaEMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLFFBQVEsRUFBRSxxQ0FBcUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0tBQzVELENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1CRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw0QkFBNEIsQ0FBQyxHQUFzQztJQUNqRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGVBQWUsRUFBRSxHQUFHLENBQUMsYUFBYTtLQUNuQyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF1RUQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsZ0NBQWdDLENBQUMsR0FBMEM7SUFDekYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYiwyQkFBMkIsRUFBRSxHQUFHLENBQUMseUJBQXlCLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMseURBQXlELENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEksd0NBQXdDLEVBQUUsR0FBRyxDQUFDLHNDQUFzQztRQUNwRix3Q0FBd0MsRUFBRSxHQUFHLENBQUMsc0NBQXNDO1FBQ3BGLGtDQUFrQyxFQUFFLEdBQUcsQ0FBQyxnQ0FBZ0M7UUFDeEUsa0NBQWtDLEVBQUUsR0FBRyxDQUFDLGdDQUFnQztRQUN4RSxzQkFBc0IsRUFBRSxvREFBb0QsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUM7UUFDdEcsMkJBQTJCLEVBQUUsR0FBRyxDQUFDLHlCQUF5QixFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLHlEQUF5RCxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ25JLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw2Q0FBNkMsQ0FBQyxHQUF1RDtJQUNuSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztRQUNsQixlQUFlLEVBQUUsR0FBRyxDQUFDLGFBQWE7UUFDbEMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLFlBQVksRUFBRSxHQUFHLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLHVEQUF1RCxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2xHLGFBQWEsRUFBRSxHQUFHLENBQUMsV0FBVztLQUMvQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF5QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isa0NBQWtDLENBQUMsR0FBNEM7SUFDN0YsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztLQUN2QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF5QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsaUNBQWlDLENBQUMsR0FBMkM7SUFDM0YsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztLQUN2QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUEyQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsK0NBQStDLENBQUMsR0FBeUQ7SUFDdkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsVUFBVSxFQUFFLHVEQUF1RCxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDakYsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTJCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw0Q0FBNEMsQ0FBQyxHQUFzRDtJQUNqSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixVQUFVLEVBQUUsb0RBQW9ELENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztRQUM5RSxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHlDQUF5QyxDQUFDLEdBQW1EO0lBQzNHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO1FBQ3RCLGVBQWUsRUFBRSxHQUFHLENBQUMsYUFBYTtRQUNsQyxrQkFBa0IsRUFBRSxHQUFHLENBQUMsZ0JBQWdCO0tBQ3pDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQThCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixrQ0FBa0MsQ0FBQyxHQUE0QztJQUM3RixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGNBQWMsRUFBRSxHQUFHLENBQUMsWUFBWTtRQUNoQyxzQkFBc0IsRUFBRSxHQUFHLENBQUMsb0JBQW9CO1FBQ2hELGNBQWMsRUFBRSxHQUFHLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztLQUM5QyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsbUNBQW1DLENBQUMsR0FBNkM7SUFDL0YsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM1RSxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBOEJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG1DQUFtQyxDQUFDLEdBQTZDO0lBQy9GLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsY0FBYyxFQUFFLEdBQUcsQ0FBQyxZQUFZO1FBQ2hDLHNCQUFzQixFQUFFLEdBQUcsQ0FBQyxvQkFBb0I7UUFDaEQsY0FBYyxFQUFFLEdBQUcsQ0FBQyxZQUFZLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0tBQzlDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9CRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixvQ0FBb0MsQ0FBQyxHQUE4QztJQUNqRyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLDBDQUEwQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzdFLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF3QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsMkNBQTJDLENBQUMsR0FBcUQ7SUFDL0csSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO0tBQ3ZCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQThCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixxQ0FBcUMsQ0FBQyxHQUErQztJQUNuRyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGdCQUFnQixFQUFFLEdBQUcsQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2pELGVBQWUsRUFBRSxHQUFHLENBQUMsYUFBYTtRQUNsQyxlQUFlLEVBQUUsR0FBRyxDQUFDLGFBQWEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDL0MsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0tBQzNCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdDRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixtQ0FBbUMsQ0FBQyxHQUE2QztJQUMvRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxlQUFlO1FBQ3RDLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLDBDQUEwQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQy9FLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO0tBQ3ZCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWVEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHFDQUFxQyxDQUFDLEdBQStDO0lBQ25HLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLGVBQWU7S0FDdkMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMEJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHlEQUF5RCxDQUFDLEdBQW1FO0lBQzNJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsZUFBZSxFQUFFLEdBQUcsQ0FBQyxhQUFhO1FBQ2xDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE0Q0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isb0RBQW9ELENBQUMsR0FBOEQ7SUFDakksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixhQUFhLEVBQUUsR0FBRyxDQUFDLFdBQVc7UUFDOUIsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTO1FBQzFCLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixZQUFZLEVBQUUsR0FBRyxDQUFDLFVBQVU7S0FDN0IsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBMEJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHlEQUF5RCxDQUFDLEdBQW1FO0lBQzNJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsZUFBZSxFQUFFLEdBQUcsQ0FBQyxhQUFhO1FBQ2xDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF5QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsdURBQXVELENBQUMsR0FBaUU7SUFDdkksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3JDLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFlRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQix1REFBdUQsQ0FBQyxHQUFpRTtJQUN2SSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLDZEQUE2RCxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ2pHLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWVEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG9EQUFvRCxDQUFDLEdBQThEO0lBQ2pJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsMERBQTBELENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDOUYsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHlDQUF5QyxDQUFDLEdBQW1EO0lBQzNHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLE9BQU8sRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztLQUN6SixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsMENBQTBDLENBQUMsR0FBb0Q7SUFDN0csSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsT0FBTyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0tBQ3pKLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELG9GQUFvRjtBQUVwRjs7OztHQUlHO0FBQ0gsSUFBWSx3Q0FHWDtBQUhELFdBQVksd0NBQXdDO0lBQ2xELFdBQVc7SUFDWCx5REFBYSxDQUFBO0FBQ2YsQ0FBQyxFQUhXLHdDQUF3Qyx3REFBeEMsd0NBQXdDLFFBR25EO0FBcUNEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDBDQUEwQyxDQUFDLEdBQW9EO0lBQzdHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixjQUFjLEVBQUUsc0RBQXNELENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQztRQUN4RixPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7S0FDbkIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBb0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDZEQUE2RCxDQUFDLEdBQXVFO0lBQ25KLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO1FBQ2xCLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztLQUNuQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFvQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsMERBQTBELENBQUMsR0FBb0U7SUFDN0ksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7UUFDbEIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO0tBQ25CLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixzREFBc0QsQ0FBQyxHQUFnRTtJQUNySSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCxvRkFBb0Y7QUFHcEY7Ozs7O0dBS0c7QUFDSCxNQUFhLFlBQWEsU0FBUSxpQkFBUztJQVN6Qzs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQTJCLEVBQUU7UUFDbEQsT0FBTztZQUNMLEdBQUcsWUFBWSxDQUFDLEdBQUc7WUFDbkIsR0FBRyx3QkFBd0IsQ0FBQyxLQUFLLENBQUM7U0FDbkMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQW1CLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQTJCLEVBQUU7UUFDNUUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixHQUFHLFlBQVksQ0FBQyxHQUFHO1lBQ25CLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNhLE1BQU07UUFDcEIsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLE9BQU87WUFDTCxHQUFHLFlBQVksQ0FBQyxHQUFHO1lBQ25CLEdBQUcsd0JBQXdCLENBQUMsUUFBUSxDQUFDO1NBQ3RDLENBQUM7SUFDSixDQUFDOztBQTlDSCxvQ0ErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixnQkFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUsa0JBQWtCO0lBQzlCLElBQUksRUFBRSxjQUFjO0NBQ3JCLENBQUE7QUEwRUg7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isd0JBQXdCLENBQUMsR0FBa0M7SUFDekUsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsTUFBTSxFQUFFLHVCQUF1QixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDekMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLE1BQU0sRUFBRSx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0tBQzFDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWVEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHVCQUF1QixDQUFDLEdBQWlDO0lBQ3ZFLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsYUFBYSxFQUFFLEdBQUcsQ0FBQyxXQUFXO0tBQy9CLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTJCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQix1QkFBdUIsQ0FBQyxHQUFpQztJQUN2RSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztRQUN0QixXQUFXLEVBQUUsZ0NBQWdDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUM1RCxTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNwRSxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFzQ0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsZ0NBQWdDLENBQUMsR0FBMEM7SUFDekYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixhQUFhLEVBQUUsMkNBQTJDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUMzRSxZQUFZLEVBQUUsMENBQTBDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUN4RSxlQUFlLEVBQUUsR0FBRyxDQUFDLGFBQWE7UUFDbEMsUUFBUSxFQUFFLHNDQUFzQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7S0FDN0QsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBc0NEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDhCQUE4QixDQUFDLEdBQXdDO0lBQ3JGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixjQUFjLEVBQUUsMENBQTBDLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQztRQUM1RSxPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7S0FDbkIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBd0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDJDQUEyQyxDQUFDLEdBQXFEO0lBQy9HLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsY0FBYyxFQUFFLHVEQUF1RCxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFDekYsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO0tBQ25CLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiwwQ0FBMEMsQ0FBQyxHQUFvRDtJQUM3RyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGNBQWMsRUFBRSxzREFBc0QsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBQ3hGLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztLQUNuQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCxvRkFBb0Y7QUFFcEY7Ozs7R0FJRztBQUNILElBQVksc0NBT1g7QUFQRCxXQUFZLHNDQUFzQztJQUNoRCxZQUFZO0lBQ1oseURBQWUsQ0FBQTtJQUNmLG1CQUFtQjtJQUNuQix5RUFBK0IsQ0FBQTtJQUMvQixxQkFBcUI7SUFDckIsNkVBQW1DLENBQUE7QUFDckMsQ0FBQyxFQVBXLHNDQUFzQyxzREFBdEMsc0NBQXNDLFFBT2pEO0FBdUJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHNDQUFzQyxDQUFDLEdBQWdEO0lBQ3JHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsY0FBYyxFQUFFLGtEQUFrRCxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFDcEYsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO0tBQ25CLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiwwQ0FBMEMsQ0FBQyxHQUFvRDtJQUM3RyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF3QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsdURBQXVELENBQUMsR0FBaUU7SUFDdkksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsR0FBRyxDQUFDLEdBQUc7UUFDZCxNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBd0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHNEQUFzRCxDQUFDLEdBQWdFO0lBQ3JJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixrREFBa0QsQ0FBQyxHQUE0RDtJQUM3SCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCxvRkFBb0Y7QUFHcEY7Ozs7O0dBS0c7QUFDSCxNQUFhLFNBQVUsU0FBUSxpQkFBUztJQVN0Qzs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQXdCLEVBQUU7UUFDL0MsT0FBTztZQUNMLEdBQUcsU0FBUyxDQUFDLEdBQUc7WUFDaEIsR0FBRyxxQkFBcUIsQ0FBQyxLQUFLLENBQUM7U0FDaEMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQW1CLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQXdCLEVBQUU7UUFDekUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixHQUFHLFNBQVMsQ0FBQyxHQUFHO1lBQ2hCLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNhLE1BQU07UUFDcEIsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLE9BQU87WUFDTCxHQUFHLFNBQVMsQ0FBQyxHQUFHO1lBQ2hCLEdBQUcscUJBQXFCLENBQUMsUUFBUSxDQUFDO1NBQ25DLENBQUM7SUFDSixDQUFDOztBQTlDSCw4QkErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixhQUFHLEdBQXFCO0lBQzdDLFVBQVUsRUFBRSxrQkFBa0I7SUFDOUIsSUFBSSxFQUFFLFdBQVc7Q0FDbEIsQ0FBQTtBQW1FSDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixxQkFBcUIsQ0FBQyxHQUErQjtJQUNuRSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDakMsTUFBTSxFQUFFLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDdkMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBeUNEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG9CQUFvQixDQUFDLEdBQThCO0lBQ2pFLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsU0FBUyxFQUFFLDJCQUEyQixDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7UUFDbkQsVUFBVSxFQUFFLDRCQUE0QixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDdEQsY0FBYyxFQUFFLEdBQUcsQ0FBQyxZQUFZO1FBQ2hDLFlBQVksRUFBRSw4QkFBOEIsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO0tBQzdELENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdDRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiwyQkFBMkIsQ0FBQyxHQUFxQztJQUMvRSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGFBQWEsRUFBRSxHQUFHLENBQUMsV0FBVztRQUM5QixhQUFhLEVBQUUsR0FBRyxDQUFDLFdBQVc7UUFDOUIsT0FBTyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3hKLE9BQU8sRUFBRSxnQ0FBZ0MsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQ3BELE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztLQUM5QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUErQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNEJBQTRCLENBQUMsR0FBc0M7SUFDakYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixLQUFLLEVBQUUsK0JBQStCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztRQUMvQyxPQUFPLEVBQUUsaUNBQWlDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztRQUNyRCxnQkFBZ0IsRUFBRSwwQ0FBMEMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO0tBQ2pGLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQStDRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw4QkFBOEIsQ0FBQyxHQUF3QztJQUNyRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGVBQWUsRUFBRSxHQUFHLENBQUMsYUFBYSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLDJDQUEyQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQzVGLGdCQUFnQixFQUFFLEdBQUcsQ0FBQyxjQUFjLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsNENBQTRDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDL0YsZ0JBQWdCLEVBQUUsR0FBRyxDQUFDLGNBQWMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMvRixpQkFBaUIsRUFBRSxHQUFHLENBQUMsZUFBZSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLDZDQUE2QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ25HLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9CRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixnQ0FBZ0MsQ0FBQyxHQUEwQztJQUN6RixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztRQUN0QixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBK0NEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLCtCQUErQixDQUFDLEdBQXlDO0lBQ3ZGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLG1DQUFtQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDckQsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsc0NBQXNDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0UsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLGVBQWU7UUFDdEMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO1FBQ3RCLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztLQUNmLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQThCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixpQ0FBaUMsQ0FBQyxHQUEyQztJQUMzRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUM3QixTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU87UUFDdEIsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsb0NBQW9DLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDbEUsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBaUREOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDBDQUEwQyxDQUFDLEdBQW9EO0lBQzdHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLDhDQUE4QyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDaEUsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsaURBQWlELENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDdEYsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLGVBQWU7UUFDdEMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO1FBQ3RCLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztLQUNmLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQThCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiwyQ0FBMkMsQ0FBQyxHQUFxRDtJQUMvRyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixVQUFVLEVBQUUsbURBQW1ELENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztLQUM5RSxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE4QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNENBQTRDLENBQUMsR0FBc0Q7SUFDakgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsVUFBVSxFQUFFLG9EQUFvRCxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7S0FDL0UsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBOEJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDRDQUE0QyxDQUFDLEdBQXNEO0lBQ2pILElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLFVBQVUsRUFBRSxvREFBb0QsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0tBQy9FLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWlCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw2Q0FBNkMsQ0FBQyxHQUF1RDtJQUNuSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxxREFBcUQsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0tBQ2hGLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW1DRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixtQ0FBbUMsQ0FBQyxHQUE2QztJQUMvRixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFFBQVEsRUFBRSx5Q0FBeUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQy9ELGFBQWEsRUFBRSxHQUFHLENBQUMsV0FBVztRQUM5QixRQUFRLEVBQUUseUNBQXlDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztLQUNoRSxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFzQ0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isc0NBQXNDLENBQUMsR0FBZ0Q7SUFDckcsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLGNBQWMsRUFBRSxrREFBa0QsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBQ3BGLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztLQUNuQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFzQ0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isb0NBQW9DLENBQUMsR0FBOEM7SUFDakcsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO1FBQ2hCLGNBQWMsRUFBRSxnREFBZ0QsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBQ2xGLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztLQUNuQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFtQ0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsOENBQThDLENBQUMsR0FBd0Q7SUFDckgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixRQUFRLEVBQUUsb0RBQW9ELENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztRQUMxRSxhQUFhLEVBQUUsR0FBRyxDQUFDLFdBQVc7UUFDOUIsUUFBUSxFQUFFLG9EQUFvRCxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7S0FDM0UsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBc0NEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLGlEQUFpRCxDQUFDLEdBQTJEO0lBQzNILElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtRQUNoQixjQUFjLEVBQUUsNkRBQTZELENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQztRQUMvRixPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7S0FDbkIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBeUJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG1EQUFtRCxDQUFDLEdBQTZEO0lBQy9ILElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO1FBQ2xCLGNBQWMsRUFBRSxHQUFHLENBQUMsWUFBWTtLQUNqQyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF5QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isb0RBQW9ELENBQUMsR0FBOEQ7SUFDakksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7UUFDbEIsY0FBYyxFQUFFLEdBQUcsQ0FBQyxZQUFZO0tBQ2pDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXlCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixvREFBb0QsQ0FBQyxHQUE4RDtJQUNqSSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztRQUNsQixjQUFjLEVBQUUsR0FBRyxDQUFDLFlBQVk7S0FDakMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBeUJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHFEQUFxRCxDQUFDLEdBQStEO0lBQ25JLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO1FBQ2xCLGNBQWMsRUFBRSxHQUFHLENBQUMsWUFBWTtLQUNqQyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE4Q0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IseUNBQXlDLENBQUMsR0FBbUQ7SUFDM0csSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDakMsY0FBYyxFQUFFLHFEQUFxRCxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7S0FDeEYsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHlDQUF5QyxDQUFDLEdBQW1EO0lBQzNHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLDRDQUE0QyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7S0FDN0QsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBd0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLGtEQUFrRCxDQUFDLEdBQTREO0lBQzdILElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixnREFBZ0QsQ0FBQyxHQUEwRDtJQUN6SCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE4Q0Q7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isb0RBQW9ELENBQUMsR0FBOEQ7SUFDakksSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTTtRQUNwQixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDakMsY0FBYyxFQUFFLGdFQUFnRSxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7S0FDbkcsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG9EQUFvRCxDQUFDLEdBQThEO0lBQ2pJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLHVEQUF1RCxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7S0FDeEUsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBd0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDZEQUE2RCxDQUFDLEdBQXVFO0lBQ25KLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXdCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixxREFBcUQsQ0FBQyxHQUErRDtJQUNuSSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLEtBQUssRUFBRSxHQUFHLENBQUMsR0FBRztRQUNkLE1BQU0sRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNqQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUErQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNENBQTRDLENBQUMsR0FBc0Q7SUFDakgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1FBQ3BCLG1CQUFtQixFQUFFLEdBQUcsQ0FBQyxpQkFBaUI7S0FDM0MsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBd0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLGdFQUFnRSxDQUFDLEdBQTBFO0lBQ3pKLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsS0FBSyxFQUFFLEdBQUcsQ0FBQyxHQUFHO1FBQ2QsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQStCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQix1REFBdUQsQ0FBQyxHQUFpRTtJQUN2SSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU07UUFDcEIsbUJBQW1CLEVBQUUsR0FBRyxDQUFDLGlCQUFpQjtLQUMzQyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFDRCxvRkFBb0Y7QUFHcEY7Ozs7R0FJRztBQUNILE1BQWEsVUFBVyxTQUFRLGlCQUFTO0lBU3ZDOzs7Ozs7T0FNRztJQUNJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBeUIsRUFBRTtRQUNoRCxPQUFPO1lBQ0wsR0FBRyxVQUFVLENBQUMsR0FBRztZQUNqQixHQUFHLHNCQUFzQixDQUFDLEtBQUssQ0FBQztTQUNqQyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsUUFBeUIsRUFBRTtRQUMxRSxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLEdBQUcsVUFBVSxDQUFDLEdBQUc7WUFDakIsR0FBRyxLQUFLO1NBQ1QsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ2EsTUFBTTtRQUNwQixNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFaEMsT0FBTztZQUNMLEdBQUcsVUFBVSxDQUFDLEdBQUc7WUFDakIsR0FBRyxzQkFBc0IsQ0FBQyxRQUFRLENBQUM7U0FDcEMsQ0FBQztJQUNKLENBQUM7O0FBOUNILGdDQStDQzs7O0FBOUNDOztHQUVHO0FBQ29CLGNBQUcsR0FBcUI7SUFDN0MsVUFBVSxFQUFFLGtCQUFrQjtJQUM5QixJQUFJLEVBQUUsWUFBWTtDQUNuQixDQUFBO0FBOERIOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHNCQUFzQixDQUFDLEdBQWdDO0lBQ3JFLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLFFBQVEsRUFBRSxHQUFHLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNqQyxNQUFNLEVBQUUscUJBQXFCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztLQUN4QyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IscUJBQXFCLENBQUMsR0FBK0I7SUFDbkUsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsNkJBQTZCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztRQUN2RCxTQUFTLEVBQUUsNEJBQTRCLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztLQUNyRCxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF1QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNkJBQTZCLENBQUMsR0FBdUM7SUFDbkYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixpQkFBaUIsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsNENBQTRDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3BPLFNBQVMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsb0NBQW9DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ3BNLFVBQVUsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztLQUNsSyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF1QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNEJBQTRCLENBQUMsR0FBc0M7SUFDakYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixRQUFRLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLGtDQUFrQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUMvTCxNQUFNLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN2TCxZQUFZLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLHNDQUFzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztLQUNoTixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUE0QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNENBQTRDLENBQUMsR0FBc0Q7SUFDakgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsYUFBYSxFQUFFLEdBQUcsQ0FBQyxXQUFXO1FBQzlCLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztRQUN0QixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUNEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG9DQUFvQyxDQUFDLEdBQThDO0lBQ2pHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsVUFBVSxFQUFFLEdBQUcsQ0FBQyxRQUFRO1FBQ3hCLFVBQVUsRUFBRSw0Q0FBNEMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO1FBQ3RFLGFBQWEsRUFBRSxHQUFHLENBQUMsV0FBVztRQUM5QixZQUFZLEVBQUUsR0FBRyxDQUFDLFVBQVU7UUFDNUIsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNO0tBQ3JCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWlDRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixrQ0FBa0MsQ0FBQyxHQUE0QztJQUM3RixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGdCQUFnQixFQUFFLEdBQUcsQ0FBQyxjQUFjO1FBQ3BDLHlCQUF5QixFQUFFLEdBQUcsQ0FBQyx1QkFBdUI7UUFDdEQscUJBQXFCLEVBQUUsR0FBRyxDQUFDLG1CQUFtQjtRQUM5QyxPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7UUFDbEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO0tBQ3ZCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTRCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixnQ0FBZ0MsQ0FBQyxHQUEwQztJQUN6RixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGdCQUFnQixFQUFFLEdBQUcsQ0FBQyxjQUFjO1FBQ3BDLHlCQUF5QixFQUFFLEdBQUcsQ0FBQyx1QkFBdUI7UUFDdEQsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO1FBQ2xCLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztLQUN2QixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUFrQkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isc0NBQXNDLENBQUMsR0FBZ0Q7SUFDckcsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixTQUFTLEVBQUUsNkNBQTZDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztRQUNyRSxVQUFVLEVBQUUsOENBQThDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztLQUN6RSxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF3QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNENBQTRDLENBQUMsR0FBc0Q7SUFDakgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixpQkFBaUIsRUFBRSxHQUFHLENBQUMsZUFBZTtRQUN0QyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsZUFBZTtLQUN2QyxDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF1QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNkNBQTZDLENBQUMsR0FBdUQ7SUFDbkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixnQkFBZ0IsRUFBRSxHQUFHLENBQUMsY0FBYztRQUNwQyxPQUFPLEVBQUUsR0FBRyxDQUFDLEtBQUs7UUFDbEIsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO0tBQ3ZCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXVCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw4Q0FBOEMsQ0FBQyxHQUF3RDtJQUNySCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGdCQUFnQixFQUFFLEdBQUcsQ0FBQyxjQUFjO1FBQ3BDLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztRQUNsQixTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU87S0FDdkIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBQ0Qsb0ZBQW9GO0FBR3BGOzs7O0dBSUc7QUFDSCxNQUFhLFlBQWEsU0FBUSxpQkFBUztJQVN6Qzs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQTJCLEVBQUU7UUFDbEQsT0FBTztZQUNMLEdBQUcsWUFBWSxDQUFDLEdBQUc7WUFDbkIsR0FBRyx3QkFBd0IsQ0FBQyxLQUFLLENBQUM7U0FDbkMsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNILFlBQW1CLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQTJCLEVBQUU7UUFDNUUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLEVBQUU7WUFDZixHQUFHLFlBQVksQ0FBQyxHQUFHO1lBQ25CLEdBQUcsS0FBSztTQUNULENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNhLE1BQU07UUFDcEIsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBRWhDLE9BQU87WUFDTCxHQUFHLFlBQVksQ0FBQyxHQUFHO1lBQ25CLEdBQUcsd0JBQXdCLENBQUMsUUFBUSxDQUFDO1NBQ3RDLENBQUM7SUFDSixDQUFDOztBQTlDSCxvQ0ErQ0M7OztBQTlDQzs7R0FFRztBQUNvQixnQkFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUsa0JBQWtCO0lBQzlCLElBQUksRUFBRSxjQUFjO0NBQ3JCLENBQUE7QUFrRUg7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isd0JBQXdCLENBQUMsR0FBa0M7SUFDekUsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLE1BQU0sRUFBRSx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0tBQzFDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTBDRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQix1QkFBdUIsQ0FBQyxHQUFpQztJQUN2RSxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGVBQWUsRUFBRSxvQ0FBb0MsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDO1FBQ3hFLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxlQUFlO1FBQ3RDLFVBQVUsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNqSyxZQUFZLEVBQUUsR0FBRyxDQUFDLFVBQVU7UUFDNUIsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO1FBQ2xCLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztLQUNuQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF5QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0Isb0NBQW9DLENBQUMsR0FBOEM7SUFDakcsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixTQUFTLEVBQUUsR0FBRyxDQUFDLE9BQU87UUFDdEIsb0JBQW9CLEVBQUUsR0FBRyxDQUFDLGtCQUFrQjtRQUM1QyxrQkFBa0IsRUFBRSxHQUFHLENBQUMsZ0JBQWdCO0tBQ3pDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELG9GQUFvRjtBQUdwRjs7OztHQUlHO0FBQ0gsTUFBYSxvQkFBcUIsU0FBUSxpQkFBUztJQVNqRDs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQW1DLEVBQUU7UUFDMUQsT0FBTztZQUNMLEdBQUcsb0JBQW9CLENBQUMsR0FBRztZQUMzQixHQUFHLGdDQUFnQyxDQUFDLEtBQUssQ0FBQztTQUMzQyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsUUFBbUMsRUFBRTtRQUNwRixLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLEdBQUcsb0JBQW9CLENBQUMsR0FBRztZQUMzQixHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDYSxNQUFNO1FBQ3BCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVoQyxPQUFPO1lBQ0wsR0FBRyxvQkFBb0IsQ0FBQyxHQUFHO1lBQzNCLEdBQUcsZ0NBQWdDLENBQUMsUUFBUSxDQUFDO1NBQzlDLENBQUM7SUFDSixDQUFDOztBQTlDSCxvREErQ0M7OztBQTlDQzs7R0FFRztBQUNvQix3QkFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUsa0JBQWtCO0lBQzlCLElBQUksRUFBRSxjQUFjO0NBQ3JCLENBQUE7QUFrRUg7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsZ0NBQWdDLENBQUMsR0FBMEM7SUFDekYsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixVQUFVLEVBQUUsR0FBRyxDQUFDLFFBQVE7UUFDeEIsUUFBUSxFQUFFLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLE1BQU0sRUFBRSwrQkFBK0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0tBQ2xELENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQW9ERDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiwrQkFBK0IsQ0FBQyxHQUF5QztJQUN2RixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLGVBQWUsRUFBRSw0Q0FBNEMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDO1FBQ2hGLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxlQUFlO1FBQ3RDLFVBQVUsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNqSyxZQUFZLEVBQUUsR0FBRyxDQUFDLFVBQVU7UUFDNUIsUUFBUSxFQUFFLHFDQUFxQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7UUFDM0QsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLO0tBQ25CLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQXlCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiw0Q0FBNEMsQ0FBQyxHQUFzRDtJQUNqSCxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFNBQVMsRUFBRSxHQUFHLENBQUMsT0FBTztRQUN0QixvQkFBb0IsRUFBRSxHQUFHLENBQUMsa0JBQWtCO1FBQzVDLGtCQUFrQixFQUFFLEdBQUcsQ0FBQyxnQkFBZ0I7S0FDekMsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBd0JEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLHFDQUFxQyxDQUFDLEdBQStDO0lBQ25HLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPO1FBQ3RCLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLDBDQUEwQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQzVFLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQTZCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiwwQ0FBMEMsQ0FBQyxHQUFvRDtJQUM3RyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztRQUNsQixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7S0FDakIsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBQ0Qsb0ZBQW9GO0FBR3BGOzs7OztHQUtHO0FBQ0gsTUFBYSxvQkFBcUIsU0FBUSxpQkFBUztJQVNqRDs7Ozs7O09BTUc7SUFDSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQW1DLEVBQUU7UUFDMUQsT0FBTztZQUNMLEdBQUcsb0JBQW9CLENBQUMsR0FBRztZQUMzQixHQUFHLGdDQUFnQyxDQUFDLEtBQUssQ0FBQztTQUMzQyxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0gsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsUUFBbUMsRUFBRTtRQUNwRixLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLEdBQUcsb0JBQW9CLENBQUMsR0FBRztZQUMzQixHQUFHLEtBQUs7U0FDVCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDYSxNQUFNO1FBQ3BCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUVoQyxPQUFPO1lBQ0wsR0FBRyxvQkFBb0IsQ0FBQyxHQUFHO1lBQzNCLEdBQUcsZ0NBQWdDLENBQUMsUUFBUSxDQUFDO1NBQzlDLENBQUM7SUFDSixDQUFDOztBQTlDSCxvREErQ0M7OztBQTlDQzs7R0FFRztBQUNvQix3QkFBRyxHQUFxQjtJQUM3QyxVQUFVLEVBQUUsa0JBQWtCO0lBQzlCLElBQUksRUFBRSxzQkFBc0I7Q0FDN0IsQ0FBQTtBQW1FSDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQixnQ0FBZ0MsQ0FBQyxHQUEwQztJQUN6RixJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLFVBQVUsRUFBRSxHQUFHLENBQUMsUUFBUTtRQUN4QixRQUFRLEVBQUUsR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDakMsTUFBTSxFQUFFLCtCQUErQixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7S0FDbEQsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBaUJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLCtCQUErQixDQUFDLEdBQXlDO0lBQ3ZGLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsT0FBTyxFQUFFLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsb0NBQW9DLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDdEUsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBa0NEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLG9DQUFvQyxDQUFDLEdBQThDO0lBQ2pHLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsWUFBWSxFQUFFLEdBQUcsQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsOENBQThDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDekYsU0FBUyxFQUFFLEdBQUcsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsMkNBQTJDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEYsV0FBVyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsNkNBQTZDLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDdkYsQ0FBQztJQUNGLDBCQUEwQjtJQUMxQixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUMxRyxDQUFDO0FBbUJEOztHQUVHO0FBQ0gscUZBQXFGO0FBQ3JGLFNBQWdCLDhDQUE4QyxDQUFDLEdBQXdEO0lBQ3JILElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRSxDQUFDO1FBQUMsT0FBTyxTQUFTLENBQUM7SUFBQyxDQUFDO0lBQzVDLE1BQU0sTUFBTSxHQUFHO1FBQ2IsTUFBTSxFQUFFLEdBQUcsQ0FBQyxJQUFJO0tBQ2pCLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQWlCRDs7R0FFRztBQUNILHFGQUFxRjtBQUNyRixTQUFnQiwyQ0FBMkMsQ0FBQyxHQUFxRDtJQUMvRyxJQUFJLEdBQUcsS0FBSyxTQUFTLEVBQUUsQ0FBQztRQUFDLE9BQU8sU0FBUyxDQUFDO0lBQUMsQ0FBQztJQUM1QyxNQUFNLE1BQU0sR0FBRztRQUNiLE9BQU8sRUFBRSxHQUFHLENBQUMsS0FBSztLQUNuQixDQUFDO0lBQ0YsMEJBQTBCO0lBQzFCLE9BQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzFHLENBQUM7QUF5QkQ7O0dBRUc7QUFDSCxxRkFBcUY7QUFDckYsU0FBZ0IsNkNBQTZDLENBQUMsR0FBdUQ7SUFDbkgsSUFBSSxHQUFHLEtBQUssU0FBUyxFQUFFLENBQUM7UUFBQyxPQUFPLFNBQVMsQ0FBQztJQUFDLENBQUM7SUFDNUMsTUFBTSxNQUFNLEdBQUc7UUFDYixNQUFNLEVBQUUsR0FBRyxDQUFDLElBQUk7UUFDaEIsWUFBWSxFQUFFLEdBQUcsQ0FBQyxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0tBQzFDLENBQUM7SUFDRiwwQkFBMEI7SUFDMUIsT0FBTyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDMUcsQ0FBQztBQUNELG9GQUFvRjtBQUVwRjs7OztHQUlHO0FBQ0gsSUFBWSxnREFpQlg7QUFqQkQsV0FBWSxnREFBZ0Q7SUFDMUQsZUFBZTtJQUNmLHlFQUFxQixDQUFBO0lBQ3JCLGdCQUFnQjtJQUNoQiwyRUFBdUIsQ0FBQTtJQUN2QixZQUFZO0lBQ1osbUVBQWUsQ0FBQTtJQUNmLFlBQVk7SUFDWixtRUFBZSxDQUFBO0lBQ2YsYUFBYTtJQUNiLHFFQUFpQixDQUFBO0lBQ2pCLFlBQVk7SUFDWixtRUFBZSxDQUFBO0lBQ2YsVUFBVTtJQUNWLCtEQUFXLENBQUE7SUFDWCxZQUFZO0lBQ1osbUVBQWUsQ0FBQTtBQUNqQixDQUFDLEVBakJXLGdEQUFnRCxnRUFBaEQsZ0RBQWdELFFBaUIzRCIsInNvdXJjZXNDb250ZW50IjpbIi8vIGdlbmVyYXRlZCBieSBjZGs4c1xuaW1wb3J0IHsgQXBpT2JqZWN0LCBBcGlPYmplY3RNZXRhZGF0YSwgR3JvdXBWZXJzaW9uS2luZCB9IGZyb20gJ2NkazhzJztcbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuXG5cbi8qKlxuICogQ29tcG9uZW50IGRlc2NyaWJlcyBhbiBEYXByIGNvbXBvbmVudCB0eXBlLlxuICpcbiAqIEBzY2hlbWEgQ29tcG9uZW50XG4gKi9cbmV4cG9ydCBjbGFzcyBDb21wb25lbnQgZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJDb21wb25lbnRcIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2RhcHIuaW8vdjFhbHBoYTEnLFxuICAgIGtpbmQ6ICdDb21wb25lbnQnLFxuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgYSBLdWJlcm5ldGVzIG1hbmlmZXN0IGZvciBcIkNvbXBvbmVudFwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBDb21wb25lbnRQcm9wcyA9IHt9KTogYW55IHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uQ29tcG9uZW50LkdWSyxcbiAgICAgIC4uLnRvSnNvbl9Db21wb25lbnRQcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJDb21wb25lbnRcIiBBUEkgb2JqZWN0XG4gICAqIEBwYXJhbSBzY29wZSB0aGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgb2JqZWN0XG4gICAqIEBwYXJhbSBpZCBhIHNjb3BlLWxvY2FsIG5hbWUgZm9yIHRoZSBvYmplY3RcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IENvbXBvbmVudFByb3BzID0ge30pIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIC4uLkNvbXBvbmVudC5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIG92ZXJyaWRlIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uQ29tcG9uZW50LkdWSyxcbiAgICAgIC4uLnRvSnNvbl9Db21wb25lbnRQcm9wcyhyZXNvbHZlZCksXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIENvbXBvbmVudCBkZXNjcmliZXMgYW4gRGFwciBjb21wb25lbnQgdHlwZS5cbiAqXG4gKiBAc2NoZW1hIENvbXBvbmVudFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbXBvbmVudFByb3BzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29tcG9uZW50I21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IEFwaU9iamVjdE1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBBdXRoIHJlcHJlc2VudHMgYXV0aGVudGljYXRpb24gZGV0YWlscyBmb3IgdGhlIGNvbXBvbmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDb21wb25lbnQjYXV0aFxuICAgKi9cbiAgcmVhZG9ubHkgYXV0aD86IENvbXBvbmVudEF1dGg7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29tcG9uZW50I3Njb3Blc1xuICAgKi9cbiAgcmVhZG9ubHkgc2NvcGVzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIENvbXBvbmVudFNwZWMgaXMgdGhlIHNwZWMgZm9yIGEgY29tcG9uZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIENvbXBvbmVudCNzcGVjXG4gICAqL1xuICByZWFkb25seSBzcGVjPzogQ29tcG9uZW50U3BlYztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29tcG9uZW50UHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29tcG9uZW50UHJvcHMob2JqOiBDb21wb25lbnRQcm9wcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhLFxuICAgICdhdXRoJzogdG9Kc29uX0NvbXBvbmVudEF1dGgob2JqLmF1dGgpLFxuICAgICdzY29wZXMnOiBvYmouc2NvcGVzPy5tYXAoeSA9PiB5KSxcbiAgICAnc3BlYyc6IHRvSnNvbl9Db21wb25lbnRTcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEF1dGggcmVwcmVzZW50cyBhdXRoZW50aWNhdGlvbiBkZXRhaWxzIGZvciB0aGUgY29tcG9uZW50LlxuICpcbiAqIEBzY2hlbWEgQ29tcG9uZW50QXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbXBvbmVudEF1dGgge1xuICAvKipcbiAgICogQHNjaGVtYSBDb21wb25lbnRBdXRoI3NlY3JldFN0b3JlXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRTdG9yZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb21wb25lbnRBdXRoJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NvbXBvbmVudEF1dGgob2JqOiBDb21wb25lbnRBdXRoIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VjcmV0U3RvcmUnOiBvYmouc2VjcmV0U3RvcmUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBDb21wb25lbnRTcGVjIGlzIHRoZSBzcGVjIGZvciBhIGNvbXBvbmVudC5cbiAqXG4gKiBAc2NoZW1hIENvbXBvbmVudFNwZWNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21wb25lbnRTcGVjIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29tcG9uZW50U3BlYyNpZ25vcmVFcnJvcnNcbiAgICovXG4gIHJlYWRvbmx5IGlnbm9yZUVycm9ycz86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29tcG9uZW50U3BlYyNpbml0VGltZW91dFxuICAgKi9cbiAgcmVhZG9ubHkgaW5pdFRpbWVvdXQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29tcG9uZW50U3BlYyNtZXRhZGF0YVxuICAgKi9cbiAgcmVhZG9ubHkgbWV0YWRhdGE6IENvbXBvbmVudFNwZWNNZXRhZGF0YVtdO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbXBvbmVudFNwZWMjdHlwZVxuICAgKi9cbiAgcmVhZG9ubHkgdHlwZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbXBvbmVudFNwZWMjdmVyc2lvblxuICAgKi9cbiAgcmVhZG9ubHkgdmVyc2lvbjogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb21wb25lbnRTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NvbXBvbmVudFNwZWMob2JqOiBDb21wb25lbnRTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnaWdub3JlRXJyb3JzJzogb2JqLmlnbm9yZUVycm9ycyxcbiAgICAnaW5pdFRpbWVvdXQnOiBvYmouaW5pdFRpbWVvdXQsXG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhPy5tYXAoeSA9PiB0b0pzb25fQ29tcG9uZW50U3BlY01ldGFkYXRhKHkpKSxcbiAgICAndHlwZSc6IG9iai50eXBlLFxuICAgICd2ZXJzaW9uJzogb2JqLnZlcnNpb24sXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBOYW1lVmFsdWVQYWlyIGlzIGEgbmFtZS92YWx1ZSBwYWlyLlxuICpcbiAqIEBzY2hlbWEgQ29tcG9uZW50U3BlY01ldGFkYXRhXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29tcG9uZW50U3BlY01ldGFkYXRhIHtcbiAgLyoqXG4gICAqIEVudlJlZiBpcyB0aGUgbmFtZSBvZiBhbiBlbnZpcm9ubWVudGFsIHZhcmlhYmxlIHRvIHJlYWQgdGhlIHZhbHVlIGZyb20uXG4gICAqXG4gICAqIEBzY2hlbWEgQ29tcG9uZW50U3BlY01ldGFkYXRhI2VudlJlZlxuICAgKi9cbiAgcmVhZG9ubHkgZW52UmVmPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOYW1lIG9mIHRoZSBwcm9wZXJ0eS5cbiAgICpcbiAgICogQHNjaGVtYSBDb21wb25lbnRTcGVjTWV0YWRhdGEjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZWNyZXRLZXlSZWYgaXMgdGhlIHJlZmVyZW5jZSBvZiBhIHZhbHVlIGluIGEgc2VjcmV0IHN0b3JlIGNvbXBvbmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBDb21wb25lbnRTcGVjTWV0YWRhdGEjc2VjcmV0S2V5UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRLZXlSZWY/OiBDb21wb25lbnRTcGVjTWV0YWRhdGFTZWNyZXRLZXlSZWY7XG5cbiAgLyoqXG4gICAqIFZhbHVlIG9mIHRoZSBwcm9wZXJ0eSwgaW4gcGxhaW50ZXh0LlxuICAgKlxuICAgKiBAc2NoZW1hIENvbXBvbmVudFNwZWNNZXRhZGF0YSN2YWx1ZVxuICAgKi9cbiAgcmVhZG9ubHkgdmFsdWU/OiBhbnk7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbXBvbmVudFNwZWNNZXRhZGF0YScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db21wb25lbnRTcGVjTWV0YWRhdGEob2JqOiBDb21wb25lbnRTcGVjTWV0YWRhdGEgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdlbnZSZWYnOiBvYmouZW52UmVmLFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ3NlY3JldEtleVJlZic6IHRvSnNvbl9Db21wb25lbnRTcGVjTWV0YWRhdGFTZWNyZXRLZXlSZWYob2JqLnNlY3JldEtleVJlZiksXG4gICAgJ3ZhbHVlJzogb2JqLnZhbHVlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gKlxuICogQHNjaGVtYSBDb21wb25lbnRTcGVjTWV0YWRhdGFTZWNyZXRLZXlSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb21wb25lbnRTcGVjTWV0YWRhdGFTZWNyZXRLZXlSZWYge1xuICAvKipcbiAgICogRmllbGQgaW4gdGhlIHNlY3JldC5cbiAgICpcbiAgICogQHNjaGVtYSBDb21wb25lbnRTcGVjTWV0YWRhdGFTZWNyZXRLZXlSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldCBuYW1lLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbXBvbmVudFNwZWNNZXRhZGF0YVNlY3JldEtleVJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbXBvbmVudFNwZWNNZXRhZGF0YVNlY3JldEtleVJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db21wb25lbnRTcGVjTWV0YWRhdGFTZWNyZXRLZXlSZWYob2JqOiBDb21wb25lbnRTcGVjTWV0YWRhdGFTZWNyZXRLZXlSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZGVzY3JpYmVzIGFuIERhcHIgY29uZmlndXJhdGlvbiBzZXR0aW5nLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblxuICovXG5leHBvcnQgY2xhc3MgQ29uZmlndXJhdGlvbiBleHRlbmRzIEFwaU9iamVjdCB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBhcGlWZXJzaW9uIGFuZCBraW5kIGZvciBcIkNvbmZpZ3VyYXRpb25cIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2RhcHIuaW8vdjFhbHBoYTEnLFxuICAgIGtpbmQ6ICdDb25maWd1cmF0aW9uJyxcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIGEgS3ViZXJuZXRlcyBtYW5pZmVzdCBmb3IgXCJDb25maWd1cmF0aW9uXCIuXG4gICAqXG4gICAqIFRoaXMgY2FuIGJlIHVzZWQgdG8gaW5saW5lIHJlc291cmNlIG1hbmlmZXN0cyBpbnNpZGUgb3RoZXIgb2JqZWN0cyAoZS5nLiBhcyB0ZW1wbGF0ZXMpLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgbWFuaWZlc3QocHJvcHM6IENvbmZpZ3VyYXRpb25Qcm9wcyA9IHt9KTogYW55IHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uQ29uZmlndXJhdGlvbi5HVkssXG4gICAgICAuLi50b0pzb25fQ29uZmlndXJhdGlvblByb3BzKHByb3BzKSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmluZXMgYSBcIkNvbmZpZ3VyYXRpb25cIiBBUEkgb2JqZWN0XG4gICAqIEBwYXJhbSBzY29wZSB0aGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgb2JqZWN0XG4gICAqIEBwYXJhbSBpZCBhIHNjb3BlLWxvY2FsIG5hbWUgZm9yIHRoZSBvYmplY3RcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IENvbmZpZ3VyYXRpb25Qcm9wcyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICAuLi5Db25maWd1cmF0aW9uLkdWSyxcbiAgICAgIC4uLnByb3BzLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgdGhlIG9iamVjdCB0byBLdWJlcm5ldGVzIEpTT04uXG4gICAqL1xuICBwdWJsaWMgb3ZlcnJpZGUgdG9Kc29uKCk6IGFueSB7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSBzdXBlci50b0pzb24oKTtcblxuICAgIHJldHVybiB7XG4gICAgICAuLi5Db25maWd1cmF0aW9uLkdWSyxcbiAgICAgIC4uLnRvSnNvbl9Db25maWd1cmF0aW9uUHJvcHMocmVzb2x2ZWQpLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBDb25maWd1cmF0aW9uIGRlc2NyaWJlcyBhbiBEYXByIGNvbmZpZ3VyYXRpb24gc2V0dGluZy5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uUHJvcHMge1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uI21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IEFwaU9iamVjdE1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBDb25maWd1cmF0aW9uU3BlYyBpcyB0aGUgc3BlYyBmb3IgYSBjb25maWd1cmF0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb24jc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IENvbmZpZ3VyYXRpb25TcGVjO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uUHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblByb3BzKG9iajogQ29uZmlndXJhdGlvblByb3BzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbWV0YWRhdGEnOiBvYmoubWV0YWRhdGEsXG4gICAgJ3NwZWMnOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWMob2JqLnNwZWMpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogQ29uZmlndXJhdGlvblNwZWMgaXMgdGhlIHNwZWMgZm9yIGEgY29uZmlndXJhdGlvbi5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWMge1xuICAvKipcbiAgICogQWNjZXNzQ29udHJvbFNwZWMgaXMgdGhlIHNwZWMgb2JqZWN0IGluIENvbmZpZ3VyYXRpb25TcGVjLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjI2FjY2Vzc0NvbnRyb2xcbiAgICovXG4gIHJlYWRvbmx5IGFjY2Vzc0NvbnRyb2w/OiBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2w7XG5cbiAgLyoqXG4gICAqIEFQSVNwZWMgZGVzY3JpYmVzIHRoZSBjb25maWd1cmF0aW9uIGZvciBEYXByIEFQSXMuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWMjYXBpXG4gICAqL1xuICByZWFkb25seSBhcGk/OiBDb25maWd1cmF0aW9uU3BlY0FwaTtcblxuICAvKipcbiAgICogUGlwZWxpbmVTcGVjIGRlZmluZXMgdGhlIG1pZGRsZXdhcmUgcGlwZWxpbmUuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWMjYXBwSHR0cFBpcGVsaW5lXG4gICAqL1xuICByZWFkb25seSBhcHBIdHRwUGlwZWxpbmU/OiBDb25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZTtcblxuICAvKipcbiAgICogQ29tcG9uZW50c1NwZWMgZGVzY3JpYmVzIHRoZSBjb25maWd1cmF0aW9uIGZvciBEYXByIGNvbXBvbmVudHNcbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlYyNjb21wb25lbnRzXG4gICAqL1xuICByZWFkb25seSBjb21wb25lbnRzPzogQ29uZmlndXJhdGlvblNwZWNDb21wb25lbnRzO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjI2ZlYXR1cmVzXG4gICAqL1xuICByZWFkb25seSBmZWF0dXJlcz86IENvbmZpZ3VyYXRpb25TcGVjRmVhdHVyZXNbXTtcblxuICAvKipcbiAgICogUGlwZWxpbmVTcGVjIGRlZmluZXMgdGhlIG1pZGRsZXdhcmUgcGlwZWxpbmUuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWMjaHR0cFBpcGVsaW5lXG4gICAqL1xuICByZWFkb25seSBodHRwUGlwZWxpbmU/OiBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZTtcblxuICAvKipcbiAgICogTG9nZ2luZ1NwZWMgZGVmaW5lcyB0aGUgY29uZmlndXJhdGlvbiBmb3IgbG9nZ2luZy5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlYyNsb2dnaW5nXG4gICAqL1xuICByZWFkb25seSBsb2dnaW5nPzogQ29uZmlndXJhdGlvblNwZWNMb2dnaW5nO1xuXG4gIC8qKlxuICAgKiBNZXRyaWNTcGVjIGRlZmluZXMgbWV0cmljcyBjb25maWd1cmF0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjI21ldHJpY1xuICAgKi9cbiAgcmVhZG9ubHkgbWV0cmljPzogQ29uZmlndXJhdGlvblNwZWNNZXRyaWM7XG5cbiAgLyoqXG4gICAqIE1ldHJpY1NwZWMgZGVmaW5lcyBtZXRyaWNzIGNvbmZpZ3VyYXRpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWMjbWV0cmljc1xuICAgKi9cbiAgcmVhZG9ubHkgbWV0cmljcz86IENvbmZpZ3VyYXRpb25TcGVjTWV0cmljcztcblxuICAvKipcbiAgICogTVRMU1NwZWMgZGVmaW5lcyBtVExTIGNvbmZpZ3VyYXRpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWMjbXRsc1xuICAgKi9cbiAgcmVhZG9ubHkgbXRscz86IENvbmZpZ3VyYXRpb25TcGVjTXRscztcblxuICAvKipcbiAgICogTmFtZVJlc29sdXRpb25TcGVjIGlzIHRoZSBzcGVjIGZvciBuYW1lIHJlc29sdXRpb24gY29uZmlndXJhdGlvbi5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlYyNuYW1lUmVzb2x1dGlvblxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZVJlc29sdXRpb24/OiBDb25maWd1cmF0aW9uU3BlY05hbWVSZXNvbHV0aW9uO1xuXG4gIC8qKlxuICAgKiBTZWNyZXRzU3BlYyBpcyB0aGUgc3BlYyBmb3Igc2VjcmV0cyBjb25maWd1cmF0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjI3NlY3JldHNcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldHM/OiBDb25maWd1cmF0aW9uU3BlY1NlY3JldHM7XG5cbiAgLyoqXG4gICAqIFRyYWNpbmdTcGVjIGRlZmluZXMgZGlzdHJpYnV0ZWQgdHJhY2luZyBjb25maWd1cmF0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjI3RyYWNpbmdcbiAgICovXG4gIHJlYWRvbmx5IHRyYWNpbmc/OiBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmc7XG5cbiAgLyoqXG4gICAqIFdhc21TcGVjIGRlc2NyaWJlcyB0aGUgc2VjdXJpdHkgcHJvZmlsZSBmb3IgYWxsIERhcHIgV2FzbSBjb21wb25lbnRzLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjI3dhc21cbiAgICovXG4gIHJlYWRvbmx5IHdhc20/OiBDb25maWd1cmF0aW9uU3BlY1dhc207XG5cbiAgLyoqXG4gICAqIFdvcmtmbG93U3BlYyBkZWZpbmVzIHRoZSBjb25maWd1cmF0aW9uIGZvciBEYXByIHdvcmtmbG93cy5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlYyN3b3JrZmxvd1xuICAgKi9cbiAgcmVhZG9ubHkgd29ya2Zsb3c/OiBDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93O1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlYycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlYyhvYmo6IENvbmZpZ3VyYXRpb25TcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYWNjZXNzQ29udHJvbCc6IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2wob2JqLmFjY2Vzc0NvbnRyb2wpLFxuICAgICdhcGknOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNBcGkob2JqLmFwaSksXG4gICAgJ2FwcEh0dHBQaXBlbGluZSc6IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZShvYmouYXBwSHR0cFBpcGVsaW5lKSxcbiAgICAnY29tcG9uZW50cyc6IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0NvbXBvbmVudHMob2JqLmNvbXBvbmVudHMpLFxuICAgICdmZWF0dXJlcyc6IG9iai5mZWF0dXJlcz8ubWFwKHkgPT4gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjRmVhdHVyZXMoeSkpLFxuICAgICdodHRwUGlwZWxpbmUnOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmUob2JqLmh0dHBQaXBlbGluZSksXG4gICAgJ2xvZ2dpbmcnOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNMb2dnaW5nKG9iai5sb2dnaW5nKSxcbiAgICAnbWV0cmljJzogdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjTWV0cmljKG9iai5tZXRyaWMpLFxuICAgICdtZXRyaWNzJzogdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjTWV0cmljcyhvYmoubWV0cmljcyksXG4gICAgJ210bHMnOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNdGxzKG9iai5tdGxzKSxcbiAgICAnbmFtZVJlc29sdXRpb24nOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNOYW1lUmVzb2x1dGlvbihvYmoubmFtZVJlc29sdXRpb24pLFxuICAgICdzZWNyZXRzJzogdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjU2VjcmV0cyhvYmouc2VjcmV0cyksXG4gICAgJ3RyYWNpbmcnOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nKG9iai50cmFjaW5nKSxcbiAgICAnd2FzbSc6IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1dhc20ob2JqLndhc20pLFxuICAgICd3b3JrZmxvdyc6IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1dvcmtmbG93KG9iai53b3JrZmxvdyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBY2Nlc3NDb250cm9sU3BlYyBpcyB0aGUgc3BlYyBvYmplY3QgaW4gQ29uZmlndXJhdGlvblNwZWMuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2xcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2wge1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2wjZGVmYXVsdEFjdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgZGVmYXVsdEFjdGlvbj86IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2wjcG9saWNpZXNcbiAgICovXG4gIHJlYWRvbmx5IHBvbGljaWVzPzogQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXNbXTtcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2wjdHJ1c3REb21haW5cbiAgICovXG4gIHJlYWRvbmx5IHRydXN0RG9tYWluPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2wnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sKG9iajogQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZGVmYXVsdEFjdGlvbic6IG9iai5kZWZhdWx0QWN0aW9uLFxuICAgICdwb2xpY2llcyc6IG9iai5wb2xpY2llcz8ubWFwKHkgPT4gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjQWNjZXNzQ29udHJvbFBvbGljaWVzKHkpKSxcbiAgICAndHJ1c3REb21haW4nOiBvYmoudHJ1c3REb21haW4sXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBUElTcGVjIGRlc2NyaWJlcyB0aGUgY29uZmlndXJhdGlvbiBmb3IgRGFwciBBUElzLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcGlcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY0FwaSB7XG4gIC8qKlxuICAgKiBMaXN0IG9mIGFsbG93ZWQgQVBJcy4gQ2FuIGJlIHVzZWQgaW4gY29uanVuY3Rpb24gd2l0aCBkZW5pZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcGkjYWxsb3dlZFxuICAgKi9cbiAgcmVhZG9ubHkgYWxsb3dlZD86IENvbmZpZ3VyYXRpb25TcGVjQXBpQWxsb3dlZFtdO1xuXG4gIC8qKlxuICAgKiBMaXN0IG9mIGRlbmllZCBBUElzLiBDYW4gYmUgdXNlZCBpbiBjb25qdW5jdGlvbiB3aXRoIGFsbG93ZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcGkjZGVuaWVkXG4gICAqL1xuICByZWFkb25seSBkZW5pZWQ/OiBDb25maWd1cmF0aW9uU3BlY0FwaURlbmllZFtdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY0FwaScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FwaShvYmo6IENvbmZpZ3VyYXRpb25TcGVjQXBpIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYWxsb3dlZCc6IG9iai5hbGxvd2VkPy5tYXAoeSA9PiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNBcGlBbGxvd2VkKHkpKSxcbiAgICAnZGVuaWVkJzogb2JqLmRlbmllZD8ubWFwKHkgPT4gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjQXBpRGVuaWVkKHkpKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFBpcGVsaW5lU3BlYyBkZWZpbmVzIHRoZSBtaWRkbGV3YXJlIHBpcGVsaW5lLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZSB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lI2hhbmRsZXJzXG4gICAqL1xuICByZWFkb25seSBoYW5kbGVyczogQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZShvYmo6IENvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnaGFuZGxlcnMnOiBvYmouaGFuZGxlcnM/Lm1hcCh5ID0+IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZUhhbmRsZXJzKHkpKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIENvbXBvbmVudHNTcGVjIGRlc2NyaWJlcyB0aGUgY29uZmlndXJhdGlvbiBmb3IgRGFwciBjb21wb25lbnRzXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0NvbXBvbmVudHNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY0NvbXBvbmVudHMge1xuICAvKipcbiAgICogRGVueWxpc3Qgb2YgY29tcG9uZW50IHR5cGVzIHRoYXQgY2Fubm90IGJlIGluc3RhbnRpYXRlZFxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjQ29tcG9uZW50cyNkZW55XG4gICAqL1xuICByZWFkb25seSBkZW55Pzogc3RyaW5nW107XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjQ29tcG9uZW50cycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0NvbXBvbmVudHMob2JqOiBDb25maWd1cmF0aW9uU3BlY0NvbXBvbmVudHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdkZW55Jzogb2JqLmRlbnk/Lm1hcCh5ID0+IHkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogRmVhdHVyZVNwZWMgZGVmaW5lcyB0aGUgZmVhdHVyZXMgdGhhdCBhcmUgZW5hYmxlZC9kaXNhYmxlZC5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjRmVhdHVyZXNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY0ZlYXR1cmVzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNGZWF0dXJlcyNlbmFibGVkXG4gICAqL1xuICByZWFkb25seSBlbmFibGVkOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjRmVhdHVyZXMjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY0ZlYXR1cmVzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjRmVhdHVyZXMob2JqOiBDb25maWd1cmF0aW9uU3BlY0ZlYXR1cmVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZW5hYmxlZCc6IG9iai5lbmFibGVkLFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBQaXBlbGluZVNwZWMgZGVmaW5lcyB0aGUgbWlkZGxld2FyZSBwaXBlbGluZS5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmUge1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZSNoYW5kbGVyc1xuICAgKi9cbiAgcmVhZG9ubHkgaGFuZGxlcnM6IENvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnNbXTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmUnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmUob2JqOiBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZSB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2hhbmRsZXJzJzogb2JqLmhhbmRsZXJzPy5tYXAoeSA9PiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmVIYW5kbGVycyh5KSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBMb2dnaW5nU3BlYyBkZWZpbmVzIHRoZSBjb25maWd1cmF0aW9uIGZvciBsb2dnaW5nLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNMb2dnaW5nXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNMb2dnaW5nIHtcbiAgLyoqXG4gICAqIENvbmZpZ3VyZSBBUEkgbG9nZ2luZy5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0xvZ2dpbmcjYXBpTG9nZ2luZ1xuICAgKi9cbiAgcmVhZG9ubHkgYXBpTG9nZ2luZz86IENvbmZpZ3VyYXRpb25TcGVjTG9nZ2luZ0FwaUxvZ2dpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjTG9nZ2luZycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0xvZ2dpbmcob2JqOiBDb25maWd1cmF0aW9uU3BlY0xvZ2dpbmcgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhcGlMb2dnaW5nJzogdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjTG9nZ2luZ0FwaUxvZ2dpbmcob2JqLmFwaUxvZ2dpbmcpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTWV0cmljU3BlYyBkZWZpbmVzIG1ldHJpY3MgY29uZmlndXJhdGlvbi5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNNZXRyaWMge1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpYyNlbmFibGVkXG4gICAqL1xuICByZWFkb25seSBlbmFibGVkOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBNZXRyaWNIVFRQIGRlZmluZXMgY29uZmlndXJhdGlvbiBmb3IgbWV0cmljcyBmb3IgdGhlIEhUVFAgc2VydmVyXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWMjaHR0cFxuICAgKi9cbiAgcmVhZG9ubHkgaHR0cD86IENvbmZpZ3VyYXRpb25TcGVjTWV0cmljSHR0cDtcblxuICAvKipcbiAgICogVGhlIExhdGVuY3lEaXN0cmlidXRpb25CdWNrZXRzIHZhcmlhYmxlIHNwZWNpZmllcyB0aGUgbGF0ZW5jeSBkaXN0cmlidXRpb24gYnVja2V0cyAoaW4gbWlsbGlzZWNvbmRzKSB1c2VkIGZvclxuICAgKiBoaXN0b2dyYW1zIGluIHRoZSBhcHBsaWNhdGlvbi4gSWYgdGhpcyB2YXJpYWJsZSBpcyBub3Qgc2V0IG9yIGxlZnQgZW1wdHksIHRoZSBhcHBsaWNhdGlvbiB3aWxsIGRlZmF1bHQgdG8gdXNpbmcgdGhlIHN0YW5kYXJkIGhpc3RvZ3JhbSBidWNrZXRzLlxuICAgKiBUaGUgZGVmYXVsdCBoaXN0b2dyYW0gbGF0ZW5jeSBidWNrZXRzIChpbiBtaWxsaXNlY29uZHMpIGFyZSBhcyBmb2xsb3dzOlxuICAgKiAxLCAyLCAzLCA0LCA1LCA2LCA4LCAxMCwgMTMsIDE2LCAyMCwgMjUsIDMwLCA0MCwgNTAsIDY1LCA4MCwgMTAwLCAxMzAsIDE2MCwgMjAwLCAyNTAsIDMwMCwgNDAwLCA1MDAsIDY1MCwgODAwLCAxLDAwMCwgMiwwMDAsIDUsMDAwLCAxMCwwMDAsIDIwLDAwMCwgNTAsMDAwLCAxMDAsMDAwLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljI2xhdGVuY3lEaXN0cmlidXRpb25CdWNrZXRzXG4gICAqL1xuICByZWFkb25seSBsYXRlbmN5RGlzdHJpYnV0aW9uQnVja2V0cz86IG51bWJlcltdO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljI3JlY29yZEVycm9yQ29kZXNcbiAgICovXG4gIHJlYWRvbmx5IHJlY29yZEVycm9yQ29kZXM/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljI3J1bGVzXG4gICAqL1xuICByZWFkb25seSBydWxlcz86IENvbmZpZ3VyYXRpb25TcGVjTWV0cmljUnVsZXNbXTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNNZXRyaWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNZXRyaWMob2JqOiBDb25maWd1cmF0aW9uU3BlY01ldHJpYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2VuYWJsZWQnOiBvYmouZW5hYmxlZCxcbiAgICAnaHR0cCc6IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY01ldHJpY0h0dHAob2JqLmh0dHApLFxuICAgICdsYXRlbmN5RGlzdHJpYnV0aW9uQnVja2V0cyc6IG9iai5sYXRlbmN5RGlzdHJpYnV0aW9uQnVja2V0cz8ubWFwKHkgPT4geSksXG4gICAgJ3JlY29yZEVycm9yQ29kZXMnOiBvYmoucmVjb3JkRXJyb3JDb2RlcyxcbiAgICAncnVsZXMnOiBvYmoucnVsZXM/Lm1hcCh5ID0+IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY01ldHJpY1J1bGVzKHkpKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE1ldHJpY1NwZWMgZGVmaW5lcyBtZXRyaWNzIGNvbmZpZ3VyYXRpb24uXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY01ldHJpY3Mge1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpY3MjZW5hYmxlZFxuICAgKi9cbiAgcmVhZG9ubHkgZW5hYmxlZDogYm9vbGVhbjtcblxuICAvKipcbiAgICogTWV0cmljSFRUUCBkZWZpbmVzIGNvbmZpZ3VyYXRpb24gZm9yIG1ldHJpY3MgZm9yIHRoZSBIVFRQIHNlcnZlclxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljcyNodHRwXG4gICAqL1xuICByZWFkb25seSBodHRwPzogQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzSHR0cDtcblxuICAvKipcbiAgICogVGhlIExhdGVuY3lEaXN0cmlidXRpb25CdWNrZXRzIHZhcmlhYmxlIHNwZWNpZmllcyB0aGUgbGF0ZW5jeSBkaXN0cmlidXRpb24gYnVja2V0cyAoaW4gbWlsbGlzZWNvbmRzKSB1c2VkIGZvclxuICAgKiBoaXN0b2dyYW1zIGluIHRoZSBhcHBsaWNhdGlvbi4gSWYgdGhpcyB2YXJpYWJsZSBpcyBub3Qgc2V0IG9yIGxlZnQgZW1wdHksIHRoZSBhcHBsaWNhdGlvbiB3aWxsIGRlZmF1bHQgdG8gdXNpbmcgdGhlIHN0YW5kYXJkIGhpc3RvZ3JhbSBidWNrZXRzLlxuICAgKiBUaGUgZGVmYXVsdCBoaXN0b2dyYW0gbGF0ZW5jeSBidWNrZXRzIChpbiBtaWxsaXNlY29uZHMpIGFyZSBhcyBmb2xsb3dzOlxuICAgKiAxLCAyLCAzLCA0LCA1LCA2LCA4LCAxMCwgMTMsIDE2LCAyMCwgMjUsIDMwLCA0MCwgNTAsIDY1LCA4MCwgMTAwLCAxMzAsIDE2MCwgMjAwLCAyNTAsIDMwMCwgNDAwLCA1MDAsIDY1MCwgODAwLCAxLDAwMCwgMiwwMDAsIDUsMDAwLCAxMCwwMDAsIDIwLDAwMCwgNTAsMDAwLCAxMDAsMDAwLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljcyNsYXRlbmN5RGlzdHJpYnV0aW9uQnVja2V0c1xuICAgKi9cbiAgcmVhZG9ubHkgbGF0ZW5jeURpc3RyaWJ1dGlvbkJ1Y2tldHM/OiBudW1iZXJbXTtcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpY3MjcmVjb3JkRXJyb3JDb2Rlc1xuICAgKi9cbiAgcmVhZG9ubHkgcmVjb3JkRXJyb3JDb2Rlcz86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzI3J1bGVzXG4gICAqL1xuICByZWFkb25seSBydWxlcz86IENvbmZpZ3VyYXRpb25TcGVjTWV0cmljc1J1bGVzW107XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjTWV0cmljcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY01ldHJpY3Mob2JqOiBDb25maWd1cmF0aW9uU3BlY01ldHJpY3MgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdlbmFibGVkJzogb2JqLmVuYWJsZWQsXG4gICAgJ2h0dHAnOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzSHR0cChvYmouaHR0cCksXG4gICAgJ2xhdGVuY3lEaXN0cmlidXRpb25CdWNrZXRzJzogb2JqLmxhdGVuY3lEaXN0cmlidXRpb25CdWNrZXRzPy5tYXAoeSA9PiB5KSxcbiAgICAncmVjb3JkRXJyb3JDb2Rlcyc6IG9iai5yZWNvcmRFcnJvckNvZGVzLFxuICAgICdydWxlcyc6IG9iai5ydWxlcz8ubWFwKHkgPT4gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjTWV0cmljc1J1bGVzKHkpKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE1UTFNTcGVjIGRlZmluZXMgbVRMUyBjb25maWd1cmF0aW9uLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNdGxzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNNdGxzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNdGxzI2FsbG93ZWRDbG9ja1NrZXdcbiAgICovXG4gIHJlYWRvbmx5IGFsbG93ZWRDbG9ja1NrZXc/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNdGxzI2NvbnRyb2xQbGFuZVRydXN0RG9tYWluXG4gICAqL1xuICByZWFkb25seSBjb250cm9sUGxhbmVUcnVzdERvbWFpbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTXRscyNlbmFibGVkXG4gICAqL1xuICByZWFkb25seSBlbmFibGVkOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTXRscyNzZW50cnlBZGRyZXNzXG4gICAqL1xuICByZWFkb25seSBzZW50cnlBZGRyZXNzOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEFkZGl0aW9uYWwgdG9rZW4gdmFsaWRhdG9ycyB0byB1c2UuXG4gICAqIFdoZW4gRGFwciBpcyBydW5uaW5nIGluIEt1YmVybmV0ZXMgbW9kZSwgdGhpcyBpcyBpbiBhZGRpdGlvbiB0byB0aGUgYnVpbHQtaW4gXCJrdWJlcm5ldGVzXCIgdmFsaWRhdG9yLlxuICAgKiBJbiBzZWxmLWhvc3RlZCBtb2RlLCBlbmFibGluZyBhIGN1c3RvbSB2YWxpZGF0b3Igd2lsbCBkaXNhYmxlIHRoZSBidWlsdC1pbiBcImluc2VjdXJlXCIgdmFsaWRhdG9yLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTXRscyN0b2tlblZhbGlkYXRvcnNcbiAgICovXG4gIHJlYWRvbmx5IHRva2VuVmFsaWRhdG9ycz86IENvbmZpZ3VyYXRpb25TcGVjTXRsc1Rva2VuVmFsaWRhdG9yc1tdO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTXRscyN3b3JrbG9hZENlcnRUVExcbiAgICovXG4gIHJlYWRvbmx5IHdvcmtsb2FkQ2VydFR0bD86IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNNdGxzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjTXRscyhvYmo6IENvbmZpZ3VyYXRpb25TcGVjTXRscyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FsbG93ZWRDbG9ja1NrZXcnOiBvYmouYWxsb3dlZENsb2NrU2tldyxcbiAgICAnY29udHJvbFBsYW5lVHJ1c3REb21haW4nOiBvYmouY29udHJvbFBsYW5lVHJ1c3REb21haW4sXG4gICAgJ2VuYWJsZWQnOiBvYmouZW5hYmxlZCxcbiAgICAnc2VudHJ5QWRkcmVzcyc6IG9iai5zZW50cnlBZGRyZXNzLFxuICAgICd0b2tlblZhbGlkYXRvcnMnOiBvYmoudG9rZW5WYWxpZGF0b3JzPy5tYXAoeSA9PiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNdGxzVG9rZW5WYWxpZGF0b3JzKHkpKSxcbiAgICAnd29ya2xvYWRDZXJ0VFRMJzogb2JqLndvcmtsb2FkQ2VydFR0bCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE5hbWVSZXNvbHV0aW9uU3BlYyBpcyB0aGUgc3BlYyBmb3IgbmFtZSByZXNvbHV0aW9uIGNvbmZpZ3VyYXRpb24uXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY05hbWVSZXNvbHV0aW9uXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNOYW1lUmVzb2x1dGlvbiB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTmFtZVJlc29sdXRpb24jY29tcG9uZW50XG4gICAqL1xuICByZWFkb25seSBjb21wb25lbnQ6IHN0cmluZztcblxuICAvKipcbiAgICogRHluYW1pY1ZhbHVlIGlzIGEgZHluYW1pYyB2YWx1ZSBzdHJ1Y3QgZm9yIHRoZSBjb21wb25lbnQubWV0YWRhdGEgcGFpciB2YWx1ZS5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY05hbWVSZXNvbHV0aW9uI2NvbmZpZ3VyYXRpb25cbiAgICovXG4gIHJlYWRvbmx5IGNvbmZpZ3VyYXRpb246IGFueTtcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY05hbWVSZXNvbHV0aW9uI3ZlcnNpb25cbiAgICovXG4gIHJlYWRvbmx5IHZlcnNpb246IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNOYW1lUmVzb2x1dGlvbicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY05hbWVSZXNvbHV0aW9uKG9iajogQ29uZmlndXJhdGlvblNwZWNOYW1lUmVzb2x1dGlvbiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2NvbXBvbmVudCc6IG9iai5jb21wb25lbnQsXG4gICAgJ2NvbmZpZ3VyYXRpb24nOiBvYmouY29uZmlndXJhdGlvbixcbiAgICAndmVyc2lvbic6IG9iai52ZXJzaW9uLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0c1NwZWMgaXMgdGhlIHNwZWMgZm9yIHNlY3JldHMgY29uZmlndXJhdGlvbi5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjU2VjcmV0c1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjU2VjcmV0cyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjU2VjcmV0cyNzY29wZXNcbiAgICovXG4gIHJlYWRvbmx5IHNjb3BlczogQ29uZmlndXJhdGlvblNwZWNTZWNyZXRzU2NvcGVzW107XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjU2VjcmV0cycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1NlY3JldHMob2JqOiBDb25maWd1cmF0aW9uU3BlY1NlY3JldHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdzY29wZXMnOiBvYmouc2NvcGVzPy5tYXAoeSA9PiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNTZWNyZXRzU2NvcGVzKHkpKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRyYWNpbmdTcGVjIGRlZmluZXMgZGlzdHJpYnV0ZWQgdHJhY2luZyBjb25maWd1cmF0aW9uLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nIHtcbiAgLyoqXG4gICAqIE90ZWxTcGVjIGRlZmluZXMgT3RlbCBleHBvcnRlciBjb25maWd1cmF0aW9ucy5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmcjb3RlbFxuICAgKi9cbiAgcmVhZG9ubHkgb3RlbD86IENvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWw7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nI3NhbXBsaW5nUmF0ZVxuICAgKi9cbiAgcmVhZG9ubHkgc2FtcGxpbmdSYXRlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nI3N0ZG91dFxuICAgKi9cbiAgcmVhZG9ubHkgc3Rkb3V0PzogYm9vbGVhbjtcblxuICAvKipcbiAgICogWmlwa2luU3BlYyBkZWZpbmVzIFppcGtpbiB0cmFjZSBjb25maWd1cmF0aW9ucy5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmcjemlwa2luXG4gICAqL1xuICByZWFkb25seSB6aXBraW4/OiBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdaaXBraW47XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjVHJhY2luZycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1RyYWNpbmcob2JqOiBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmcgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdvdGVsJzogdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWwob2JqLm90ZWwpLFxuICAgICdzYW1wbGluZ1JhdGUnOiBvYmouc2FtcGxpbmdSYXRlLFxuICAgICdzdGRvdXQnOiBvYmouc3Rkb3V0LFxuICAgICd6aXBraW4nOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nWmlwa2luKG9iai56aXBraW4pLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogV2FzbVNwZWMgZGVzY3JpYmVzIHRoZSBzZWN1cml0eSBwcm9maWxlIGZvciBhbGwgRGFwciBXYXNtIGNvbXBvbmVudHMuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1dhc21cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY1dhc20ge1xuICAvKipcbiAgICogRm9yY2UgZW5hYmxpbmcgc3RyaWN0IHNhbmRib3ggbW9kZSBmb3IgYWxsIFdBU00gY29tcG9uZW50cy5cbiAgICogV2hlbiB0aGlzIGlzIGVuYWJsZWQsIFdBU00gY29tcG9uZW50cyBhbHdheXMgcnVuIGluIHN0cmljdCBtb2RlIHJlZ2FyZGxlc3Mgb2YgdGhlaXIgY29uZmlndXJhdGlvbi5cbiAgICogU3RyaWN0IG1vZGUgZW5oYW5jZXMgc2VjdXJpdHkgb2YgdGhlIFdBU00gc2FuZGJveCBieSBsaW1pdGluZyBhY2Nlc3MgdG8gY2VydGFpbiBjYXBhYmlsaXRpZXMgc3VjaCBhcyByZWFsLXRpbWUgY2xvY2tzIGFuZCByYW5kb20gbnVtYmVyIGdlbmVyYXRvcnMuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNXYXNtI3N0cmljdFNhbmRib3hcbiAgICovXG4gIHJlYWRvbmx5IHN0cmljdFNhbmRib3g/OiBib29sZWFuO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY1dhc20nIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNXYXNtKG9iajogQ29uZmlndXJhdGlvblNwZWNXYXNtIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc3RyaWN0U2FuZGJveCc6IG9iai5zdHJpY3RTYW5kYm94LFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogV29ya2Zsb3dTcGVjIGRlZmluZXMgdGhlIGNvbmZpZ3VyYXRpb24gZm9yIERhcHIgd29ya2Zsb3dzLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3cge1xuICAvKipcbiAgICogYWN0aXZpdHlDb25jdXJyZW5jeUxpbWl0cyBkZWZpbmVzIHBlci1hY3Rpdml0eS1uYW1lIGNvbmN1cnJlbmN5IGxpbWl0c1xuICAgKiBlbmZvcmNlZCBnbG9iYWxseSBhY3Jvc3MgYWxsIHJlcGxpY2FzIGJ5IHRoZSBzY2hlZHVsZXIuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvdyNhY3Rpdml0eUNvbmN1cnJlbmN5TGltaXRzXG4gICAqL1xuICByZWFkb25seSBhY3Rpdml0eUNvbmN1cnJlbmN5TGltaXRzPzogQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd0FjdGl2aXR5Q29uY3VycmVuY3lMaW1pdHNbXTtcblxuICAvKipcbiAgICogZ2xvYmFsTWF4Q29uY3VycmVudEFjdGl2aXR5SW52b2NhdGlvbnMgaXMgdGhlIG1heGltdW0gbnVtYmVyIG9mIGNvbmN1cnJlbnRcbiAgICogYWN0aXZpdHkgaW52b2NhdGlvbnMgYWNyb3NzIGFsbCByZXBsaWNhcywgZW5mb3JjZWQgYnkgdGhlIHNjaGVkdWxlci5cbiAgICogSWYgb21pdHRlZCwgbm8gZ2xvYmFsIG1heGltdW0gd2lsbCBiZSBlbmZvcmNlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93I2dsb2JhbE1heENvbmN1cnJlbnRBY3Rpdml0eUludm9jYXRpb25zXG4gICAqL1xuICByZWFkb25seSBnbG9iYWxNYXhDb25jdXJyZW50QWN0aXZpdHlJbnZvY2F0aW9ucz86IG51bWJlcjtcblxuICAvKipcbiAgICogZ2xvYmFsTWF4Q29uY3VycmVudFdvcmtmbG93SW52b2NhdGlvbnMgaXMgdGhlIG1heGltdW0gbnVtYmVyIG9mIGNvbmN1cnJlbnRcbiAgICogd29ya2Zsb3cgaW52b2NhdGlvbnMgYWNyb3NzIGFsbCByZXBsaWNhcywgZW5mb3JjZWQgYnkgdGhlIHNjaGVkdWxlci5cbiAgICogSWYgb21pdHRlZCwgbm8gZ2xvYmFsIG1heGltdW0gd2lsbCBiZSBlbmZvcmNlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93I2dsb2JhbE1heENvbmN1cnJlbnRXb3JrZmxvd0ludm9jYXRpb25zXG4gICAqL1xuICByZWFkb25seSBnbG9iYWxNYXhDb25jdXJyZW50V29ya2Zsb3dJbnZvY2F0aW9ucz86IG51bWJlcjtcblxuICAvKipcbiAgICogbWF4Q29uY3VycmVudEFjdGl2aXR5SW52b2NhdGlvbnMgaXMgdGhlIG1heGltdW0gbnVtYmVyIG9mIGNvbmN1cnJlbnQgYWN0aXZpdGllcyB0aGF0IGNhbiBiZSBwcm9jZXNzZWQgYnkgYSBzaW5nbGUgRGFwciBpbnN0YW5jZS5cbiAgICogQXR0ZW1wdGVkIGludm9jYXRpb25zIGJleW9uZCB0aGlzIHdpbGwgYmUgcXVldWVkIHVudGlsIHRoZSBudW1iZXIgb2YgY29uY3VycmVudCBpbnZvY2F0aW9ucyBkcm9wcyBiZWxvdyB0aGlzIHZhbHVlLlxuICAgKiBJZiBvbWl0dGVkLCBubyBtYXhpbXVtIHdpbGwgYmUgZW5mb3JjZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvdyNtYXhDb25jdXJyZW50QWN0aXZpdHlJbnZvY2F0aW9uc1xuICAgKi9cbiAgcmVhZG9ubHkgbWF4Q29uY3VycmVudEFjdGl2aXR5SW52b2NhdGlvbnM/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIG1heENvbmN1cnJlbnRXb3JrZmxvd0ludm9jYXRpb25zIGlzIHRoZSBtYXhpbXVtIG51bWJlciBvZiBjb25jdXJyZW50IHdvcmtmbG93IGludm9jYXRpb25zIHRoYXQgY2FuIGJlIHNjaGVkdWxlZCBieSBhIHNpbmdsZSBEYXByIGluc3RhbmNlLlxuICAgKiBBdHRlbXB0ZWQgaW52b2NhdGlvbnMgYmV5b25kIHRoaXMgd2lsbCBiZSBxdWV1ZWQgdW50aWwgdGhlIG51bWJlciBvZiBjb25jdXJyZW50IGludm9jYXRpb25zIGRyb3BzIGJlbG93IHRoaXMgdmFsdWUuXG4gICAqIElmIG9taXR0ZWQsIG5vIG1heGltdW0gd2lsbCBiZSBlbmZvcmNlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93I21heENvbmN1cnJlbnRXb3JrZmxvd0ludm9jYXRpb25zXG4gICAqL1xuICByZWFkb25seSBtYXhDb25jdXJyZW50V29ya2Zsb3dJbnZvY2F0aW9ucz86IG51bWJlcjtcblxuICAvKipcbiAgICogU3RhdGVSZXRlbnRpb25Qb2xpY3kgZGVmaW5lcyB0aGUgcmV0ZW50aW9uIGNvbmZpZ3VyYXRpb24gZm9yIHdvcmtmbG93XG4gICAqIHN0YXRlIG9uY2UgYSB3b3JrZmxvdyByZWFjaGVzIGEgdGVybWluYWwgc3RhdGUuIElmIG5vdCBzZXQsIHdvcmtmbG93XG4gICAqIGluc3RhbmNlcyB3aWxsIG5vdCBiZSBhdXRvbWF0aWNhbGx5IHB1cmdlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93I3N0YXRlUmV0ZW50aW9uUG9saWN5XG4gICAqL1xuICByZWFkb25seSBzdGF0ZVJldGVudGlvblBvbGljeT86IENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dTdGF0ZVJldGVudGlvblBvbGljeTtcblxuICAvKipcbiAgICogd29ya2Zsb3dDb25jdXJyZW5jeUxpbWl0cyBkZWZpbmVzIHBlci13b3JrZmxvdy1uYW1lIGNvbmN1cnJlbmN5IGxpbWl0c1xuICAgKiBlbmZvcmNlZCBnbG9iYWxseSBhY3Jvc3MgYWxsIHJlcGxpY2FzIGJ5IHRoZSBzY2hlZHVsZXIuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvdyN3b3JrZmxvd0NvbmN1cnJlbmN5TGltaXRzXG4gICAqL1xuICByZWFkb25seSB3b3JrZmxvd0NvbmN1cnJlbmN5TGltaXRzPzogQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd1dvcmtmbG93Q29uY3VycmVuY3lMaW1pdHNbXTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvdycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1dvcmtmbG93KG9iajogQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvdyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FjdGl2aXR5Q29uY3VycmVuY3lMaW1pdHMnOiBvYmouYWN0aXZpdHlDb25jdXJyZW5jeUxpbWl0cz8ubWFwKHkgPT4gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dBY3Rpdml0eUNvbmN1cnJlbmN5TGltaXRzKHkpKSxcbiAgICAnZ2xvYmFsTWF4Q29uY3VycmVudEFjdGl2aXR5SW52b2NhdGlvbnMnOiBvYmouZ2xvYmFsTWF4Q29uY3VycmVudEFjdGl2aXR5SW52b2NhdGlvbnMsXG4gICAgJ2dsb2JhbE1heENvbmN1cnJlbnRXb3JrZmxvd0ludm9jYXRpb25zJzogb2JqLmdsb2JhbE1heENvbmN1cnJlbnRXb3JrZmxvd0ludm9jYXRpb25zLFxuICAgICdtYXhDb25jdXJyZW50QWN0aXZpdHlJbnZvY2F0aW9ucyc6IG9iai5tYXhDb25jdXJyZW50QWN0aXZpdHlJbnZvY2F0aW9ucyxcbiAgICAnbWF4Q29uY3VycmVudFdvcmtmbG93SW52b2NhdGlvbnMnOiBvYmoubWF4Q29uY3VycmVudFdvcmtmbG93SW52b2NhdGlvbnMsXG4gICAgJ3N0YXRlUmV0ZW50aW9uUG9saWN5JzogdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dTdGF0ZVJldGVudGlvblBvbGljeShvYmouc3RhdGVSZXRlbnRpb25Qb2xpY3kpLFxuICAgICd3b3JrZmxvd0NvbmN1cnJlbmN5TGltaXRzJzogb2JqLndvcmtmbG93Q29uY3VycmVuY3lMaW1pdHM/Lm1hcCh5ID0+IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1dvcmtmbG93V29ya2Zsb3dDb25jdXJyZW5jeUxpbWl0cyh5KSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBcHBQb2xpY3lTcGVjIGRlZmluZXMgdGhlIHBvbGljeSBkYXRhIHN0cnVjdHVyZSBmb3IgZWFjaCBhcHAuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2xQb2xpY2llc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjQWNjZXNzQ29udHJvbFBvbGljaWVzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXMjYXBwSWRcbiAgICovXG4gIHJlYWRvbmx5IGFwcElkOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXMjZGVmYXVsdEFjdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgZGVmYXVsdEFjdGlvbj86IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2xQb2xpY2llcyNuYW1lc3BhY2VcbiAgICovXG4gIHJlYWRvbmx5IG5hbWVzcGFjZT86IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2xQb2xpY2llcyNvcGVyYXRpb25zXG4gICAqL1xuICByZWFkb25seSBvcGVyYXRpb25zPzogQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXNPcGVyYXRpb25zW107XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXMjdHJ1c3REb21haW5cbiAgICovXG4gIHJlYWRvbmx5IHRydXN0RG9tYWluPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2xQb2xpY2llcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2xQb2xpY2llcyhvYmo6IENvbmZpZ3VyYXRpb25TcGVjQWNjZXNzQ29udHJvbFBvbGljaWVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXBwSWQnOiBvYmouYXBwSWQsXG4gICAgJ2RlZmF1bHRBY3Rpb24nOiBvYmouZGVmYXVsdEFjdGlvbixcbiAgICAnbmFtZXNwYWNlJzogb2JqLm5hbWVzcGFjZSxcbiAgICAnb3BlcmF0aW9ucyc6IG9iai5vcGVyYXRpb25zPy5tYXAoeSA9PiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXNPcGVyYXRpb25zKHkpKSxcbiAgICAndHJ1c3REb21haW4nOiBvYmoudHJ1c3REb21haW4sXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBUElBY2Nlc3NSdWxlIGRlc2NyaWJlcyBhbiBhY2Nlc3MgcnVsZSBmb3IgYWxsb3dpbmcgb3IgZGVueWluZyBhIERhcHIgQVBJLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcGlBbGxvd2VkXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNBcGlBbGxvd2VkIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcGlBbGxvd2VkI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FwaUFsbG93ZWQjcHJvdG9jb2xcbiAgICovXG4gIHJlYWRvbmx5IHByb3RvY29sPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjQXBpQWxsb3dlZCN2ZXJzaW9uXG4gICAqL1xuICByZWFkb25seSB2ZXJzaW9uOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjQXBpQWxsb3dlZCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FwaUFsbG93ZWQob2JqOiBDb25maWd1cmF0aW9uU3BlY0FwaUFsbG93ZWQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ3Byb3RvY29sJzogb2JqLnByb3RvY29sLFxuICAgICd2ZXJzaW9uJzogb2JqLnZlcnNpb24sXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBUElBY2Nlc3NSdWxlIGRlc2NyaWJlcyBhbiBhY2Nlc3MgcnVsZSBmb3IgYWxsb3dpbmcgb3IgZGVueWluZyBhIERhcHIgQVBJLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcGlEZW5pZWRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY0FwaURlbmllZCB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjQXBpRGVuaWVkI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FwaURlbmllZCNwcm90b2NvbFxuICAgKi9cbiAgcmVhZG9ubHkgcHJvdG9jb2w/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcGlEZW5pZWQjdmVyc2lvblxuICAgKi9cbiAgcmVhZG9ubHkgdmVyc2lvbjogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY0FwaURlbmllZCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FwaURlbmllZChvYmo6IENvbmZpZ3VyYXRpb25TcGVjQXBpRGVuaWVkIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICdwcm90b2NvbCc6IG9iai5wcm90b2NvbCxcbiAgICAndmVyc2lvbic6IG9iai52ZXJzaW9uLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogSGFuZGxlclNwZWMgZGVmaW5lcyBhIHJlcXVlc3QgaGFuZGxlcnMuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZUhhbmRsZXJzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVycyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lSGFuZGxlcnMjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZWxlY3RvclNwZWMgc2VsZWN0cyB0YXJnZXQgc2VydmljZXMgdG8gd2hpY2ggdGhlIGhhbmRsZXIgaXMgdG8gYmUgYXBwbGllZC5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZUhhbmRsZXJzI3NlbGVjdG9yXG4gICAqL1xuICByZWFkb25seSBzZWxlY3Rvcj86IENvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvcjtcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZUhhbmRsZXJzI3R5cGVcbiAgICovXG4gIHJlYWRvbmx5IHR5cGU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVycycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZUhhbmRsZXJzKG9iajogQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVycyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnc2VsZWN0b3InOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yKG9iai5zZWxlY3RvciksXG4gICAgJ3R5cGUnOiBvYmoudHlwZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEhhbmRsZXJTcGVjIGRlZmluZXMgYSByZXF1ZXN0IGhhbmRsZXJzLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmVIYW5kbGVyc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnMge1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogU2VsZWN0b3JTcGVjIHNlbGVjdHMgdGFyZ2V0IHNlcnZpY2VzIHRvIHdoaWNoIHRoZSBoYW5kbGVyIGlzIHRvIGJlIGFwcGxpZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmVIYW5kbGVycyNzZWxlY3RvclxuICAgKi9cbiAgcmVhZG9ubHkgc2VsZWN0b3I/OiBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3I7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmVIYW5kbGVycyN0eXBlXG4gICAqL1xuICByZWFkb25seSB0eXBlOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmVIYW5kbGVycyhvYmo6IENvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ3NlbGVjdG9yJzogdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvcihvYmouc2VsZWN0b3IpLFxuICAgICd0eXBlJzogb2JqLnR5cGUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBDb25maWd1cmUgQVBJIGxvZ2dpbmcuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0xvZ2dpbmdBcGlMb2dnaW5nXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNMb2dnaW5nQXBpTG9nZ2luZyB7XG4gIC8qKlxuICAgKiBEZWZhdWx0IHZhbHVlIGZvciBlbmFibGluZyBBUEkgbG9nZ2luZy4gU2lkZWNhcnMgY2FuIGFsd2F5cyBvdmVycmlkZSB0aGlzIGJ5IHNldHRpbmcgYC0tZW5hYmxlLWFwaS1sb2dnaW5nYCB0byB0cnVlIG9yIGZhbHNlIGV4cGxpY2l0bHkuXG4gICAqIFRoZSBkZWZhdWx0IHZhbHVlIGlzIGZhbHNlLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTG9nZ2luZ0FwaUxvZ2dpbmcjZW5hYmxlZFxuICAgKi9cbiAgcmVhZG9ubHkgZW5hYmxlZD86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFdoZW4gZW5hYmxlZCwgb2JmdXNjYXRlcyB0aGUgdmFsdWVzIG9mIFVSTHMgaW4gSFRUUCBBUEkgbG9ncywgbG9nZ2luZyB0aGUgcm91dGUgbmFtZSByYXRoZXIgdGhhbiB0aGUgZnVsbCBwYXRoIGJlaW5nIGludm9rZWQsIHdoaWNoIGNvdWxkIGNvbnRhaW4gUElJLlxuICAgKiBEZWZhdWx0OiBmYWxzZS5cbiAgICogVGhpcyBvcHRpb24gaGFzIG5vIGVmZmVjdCBpZiBBUEkgbG9nZ2luZyBpcyBkaXNhYmxlZC5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0xvZ2dpbmdBcGlMb2dnaW5nI29iZnVzY2F0ZVVSTHNcbiAgICovXG4gIHJlYWRvbmx5IG9iZnVzY2F0ZVVyTHM/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBJZiB0cnVlLCBoZWFsdGggY2hlY2tzIGFyZSBub3QgcmVwb3J0ZWQgaW4gQVBJIGxvZ3MuIERlZmF1bHQ6IGZhbHNlLlxuICAgKiBUaGlzIG9wdGlvbiBoYXMgbm8gZWZmZWN0IGlmIEFQSSBsb2dnaW5nIGlzIGRpc2FibGVkLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTG9nZ2luZ0FwaUxvZ2dpbmcjb21pdEhlYWx0aENoZWNrc1xuICAgKi9cbiAgcmVhZG9ubHkgb21pdEhlYWx0aENoZWNrcz86IGJvb2xlYW47XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjTG9nZ2luZ0FwaUxvZ2dpbmcnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNMb2dnaW5nQXBpTG9nZ2luZyhvYmo6IENvbmZpZ3VyYXRpb25TcGVjTG9nZ2luZ0FwaUxvZ2dpbmcgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdlbmFibGVkJzogb2JqLmVuYWJsZWQsXG4gICAgJ29iZnVzY2F0ZVVSTHMnOiBvYmoub2JmdXNjYXRlVXJMcyxcbiAgICAnb21pdEhlYWx0aENoZWNrcyc6IG9iai5vbWl0SGVhbHRoQ2hlY2tzLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTWV0cmljSFRUUCBkZWZpbmVzIGNvbmZpZ3VyYXRpb24gZm9yIG1ldHJpY3MgZm9yIHRoZSBIVFRQIHNlcnZlclxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNIdHRwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNIdHRwIHtcbiAgLyoqXG4gICAqIElmIHRydWUgKGRlZmF1bHQgaXMgZmFsc2UpIEhUVFAgdmVyYnMgKGUuZy4sIEdFVCwgUE9TVCkgYXJlIGV4Y2x1ZGVkIGZyb20gdGhlIG1ldHJpY3MuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNIdHRwI2V4Y2x1ZGVWZXJic1xuICAgKi9cbiAgcmVhZG9ubHkgZXhjbHVkZVZlcmJzPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogSWYgZmFsc2UsIG1ldHJpY3MgZm9yIHRoZSBIVFRQIHNlcnZlciBhcmUgY29sbGVjdGVkIHdpdGggaW5jcmVhc2VkIGNhcmRpbmFsaXR5LlxuICAgKiBUaGUgZGVmYXVsdCBpcyB0cnVlIGluIERhcHIgMS4xMywgYnV0IHdpbGwgYmUgY2hhbmdlZCB0byBmYWxzZSBpbiAxLjE1K1xuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljSHR0cCNpbmNyZWFzZWRDYXJkaW5hbGl0eVxuICAgKi9cbiAgcmVhZG9ubHkgaW5jcmVhc2VkQ2FyZGluYWxpdHk/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljSHR0cCNwYXRoTWF0Y2hpbmdcbiAgICovXG4gIHJlYWRvbmx5IHBhdGhNYXRjaGluZz86IHN0cmluZ1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY01ldHJpY0h0dHAnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNZXRyaWNIdHRwKG9iajogQ29uZmlndXJhdGlvblNwZWNNZXRyaWNIdHRwIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZXhjbHVkZVZlcmJzJzogb2JqLmV4Y2x1ZGVWZXJicyxcbiAgICAnaW5jcmVhc2VkQ2FyZGluYWxpdHknOiBvYmouaW5jcmVhc2VkQ2FyZGluYWxpdHksXG4gICAgJ3BhdGhNYXRjaGluZyc6IG9iai5wYXRoTWF0Y2hpbmc/Lm1hcCh5ID0+IHkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTWV0cmljc1J1bGUgZGVmaW5lcyBjb25maWd1cmF0aW9uIG9wdGlvbnMgZm9yIGEgbWV0cmljLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNSdWxlc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljUnVsZXMge1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpY1J1bGVzI2xhYmVsc1xuICAgKi9cbiAgcmVhZG9ubHkgbGFiZWxzOiBDb25maWd1cmF0aW9uU3BlY01ldHJpY1J1bGVzTGFiZWxzW107XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNSdWxlcyNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjTWV0cmljUnVsZXMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNZXRyaWNSdWxlcyhvYmo6IENvbmZpZ3VyYXRpb25TcGVjTWV0cmljUnVsZXMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdsYWJlbHMnOiBvYmoubGFiZWxzPy5tYXAoeSA9PiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNZXRyaWNSdWxlc0xhYmVscyh5KSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE1ldHJpY0hUVFAgZGVmaW5lcyBjb25maWd1cmF0aW9uIGZvciBtZXRyaWNzIGZvciB0aGUgSFRUUCBzZXJ2ZXJcbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljc0h0dHBcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NIdHRwIHtcbiAgLyoqXG4gICAqIElmIHRydWUgKGRlZmF1bHQgaXMgZmFsc2UpIEhUVFAgdmVyYnMgKGUuZy4sIEdFVCwgUE9TVCkgYXJlIGV4Y2x1ZGVkIGZyb20gdGhlIG1ldHJpY3MuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzSHR0cCNleGNsdWRlVmVyYnNcbiAgICovXG4gIHJlYWRvbmx5IGV4Y2x1ZGVWZXJicz86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIElmIGZhbHNlLCBtZXRyaWNzIGZvciB0aGUgSFRUUCBzZXJ2ZXIgYXJlIGNvbGxlY3RlZCB3aXRoIGluY3JlYXNlZCBjYXJkaW5hbGl0eS5cbiAgICogVGhlIGRlZmF1bHQgaXMgdHJ1ZSBpbiBEYXByIDEuMTMsIGJ1dCB3aWxsIGJlIGNoYW5nZWQgdG8gZmFsc2UgaW4gMS4xNStcbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NIdHRwI2luY3JlYXNlZENhcmRpbmFsaXR5XG4gICAqL1xuICByZWFkb25seSBpbmNyZWFzZWRDYXJkaW5hbGl0eT86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzSHR0cCNwYXRoTWF0Y2hpbmdcbiAgICovXG4gIHJlYWRvbmx5IHBhdGhNYXRjaGluZz86IHN0cmluZ1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY01ldHJpY3NIdHRwJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjTWV0cmljc0h0dHAob2JqOiBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NIdHRwIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZXhjbHVkZVZlcmJzJzogb2JqLmV4Y2x1ZGVWZXJicyxcbiAgICAnaW5jcmVhc2VkQ2FyZGluYWxpdHknOiBvYmouaW5jcmVhc2VkQ2FyZGluYWxpdHksXG4gICAgJ3BhdGhNYXRjaGluZyc6IG9iai5wYXRoTWF0Y2hpbmc/Lm1hcCh5ID0+IHkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTWV0cmljc1J1bGUgZGVmaW5lcyBjb25maWd1cmF0aW9uIG9wdGlvbnMgZm9yIGEgbWV0cmljLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzUnVsZXNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NSdWxlcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljc1J1bGVzI2xhYmVsc1xuICAgKi9cbiAgcmVhZG9ubHkgbGFiZWxzOiBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NSdWxlc0xhYmVsc1tdO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljc1J1bGVzI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzUnVsZXMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzUnVsZXMob2JqOiBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NSdWxlcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2xhYmVscyc6IG9iai5sYWJlbHM/Lm1hcCh5ID0+IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY01ldHJpY3NSdWxlc0xhYmVscyh5KSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFZhbGlkYXRvclNwZWMgY29udGFpbnMgYWRkaXRpb25hbCB0b2tlbiB2YWxpZGF0b3JzIHRvIHVzZS5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTXRsc1Rva2VuVmFsaWRhdG9yc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjTXRsc1Rva2VuVmFsaWRhdG9ycyB7XG4gIC8qKlxuICAgKiBOYW1lIG9mIHRoZSB2YWxpZGF0b3JcbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY010bHNUb2tlblZhbGlkYXRvcnMjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogQ29uZmlndXJhdGlvblNwZWNNdGxzVG9rZW5WYWxpZGF0b3JzTmFtZTtcblxuICAvKipcbiAgICogT3B0aW9ucyBmb3IgdGhlIHZhbGlkYXRvciwgaWYgYW55XG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNdGxzVG9rZW5WYWxpZGF0b3JzI29wdGlvbnNcbiAgICovXG4gIHJlYWRvbmx5IG9wdGlvbnM/OiBhbnk7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjTXRsc1Rva2VuVmFsaWRhdG9ycycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY010bHNUb2tlblZhbGlkYXRvcnMob2JqOiBDb25maWd1cmF0aW9uU3BlY010bHNUb2tlblZhbGlkYXRvcnMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICduYW1lJzogb2JqLm5hbWUsXG4gICAgJ29wdGlvbnMnOiBvYmoub3B0aW9ucyxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlY3JldHNTY29wZSBkZWZpbmVzIHRoZSBzY29wZSBmb3Igc2VjcmV0cy5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjU2VjcmV0c1Njb3Blc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjU2VjcmV0c1Njb3BlcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjU2VjcmV0c1Njb3BlcyNhbGxvd2VkU2VjcmV0c1xuICAgKi9cbiAgcmVhZG9ubHkgYWxsb3dlZFNlY3JldHM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1NlY3JldHNTY29wZXMjZGVmYXVsdEFjY2Vzc1xuICAgKi9cbiAgcmVhZG9ubHkgZGVmYXVsdEFjY2Vzcz86IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1NlY3JldHNTY29wZXMjZGVuaWVkU2VjcmV0c1xuICAgKi9cbiAgcmVhZG9ubHkgZGVuaWVkU2VjcmV0cz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjU2VjcmV0c1Njb3BlcyNzdG9yZU5hbWVcbiAgICovXG4gIHJlYWRvbmx5IHN0b3JlTmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY1NlY3JldHNTY29wZXMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNTZWNyZXRzU2NvcGVzKG9iajogQ29uZmlndXJhdGlvblNwZWNTZWNyZXRzU2NvcGVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYWxsb3dlZFNlY3JldHMnOiBvYmouYWxsb3dlZFNlY3JldHM/Lm1hcCh5ID0+IHkpLFxuICAgICdkZWZhdWx0QWNjZXNzJzogb2JqLmRlZmF1bHRBY2Nlc3MsXG4gICAgJ2RlbmllZFNlY3JldHMnOiBvYmouZGVuaWVkU2VjcmV0cz8ubWFwKHkgPT4geSksXG4gICAgJ3N0b3JlTmFtZSc6IG9iai5zdG9yZU5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBPdGVsU3BlYyBkZWZpbmVzIE90ZWwgZXhwb3J0ZXIgY29uZmlndXJhdGlvbnMuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbCB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWwjZW5kcG9pbnRBZGRyZXNzXG4gICAqL1xuICByZWFkb25seSBlbmRwb2ludEFkZHJlc3M6IHN0cmluZztcblxuICAvKipcbiAgICogSGVhZGVycyB0byBhZGQgdG8gdGhlIE9UTFAgdHJhY2UgZXhwb3J0ZXIgcmVxdWVzdC5cbiAgICogRWFjaCBoZWFkZXIgY2FuIGNvbnRhaW4gcGxhaW50ZXh0IHZhbHVlcywgcmVmZXJlbmNlIHNlY3JldHMsIG9yIHJlZmVyZW5jZSBlbnZpcm9ubWVudCB2YXJpYWJsZXMuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbCNoZWFkZXJzXG4gICAqL1xuICByZWFkb25seSBoZWFkZXJzPzogQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbEhlYWRlcnNbXTtcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsI2lzU2VjdXJlXG4gICAqL1xuICByZWFkb25seSBpc1NlY3VyZTogYm9vbGVhbjtcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsI3Byb3RvY29sXG4gICAqL1xuICByZWFkb25seSBwcm90b2NvbDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaW1lb3V0IGZvciB0aGUgT1RMUCB0cmFjZSBleHBvcnRlciByZXF1ZXN0LlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWwjdGltZW91dFxuICAgKi9cbiAgcmVhZG9ubHkgdGltZW91dD86IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsKG9iajogQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2VuZHBvaW50QWRkcmVzcyc6IG9iai5lbmRwb2ludEFkZHJlc3MsXG4gICAgJ2hlYWRlcnMnOiBvYmouaGVhZGVycz8ubWFwKHkgPT4gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWxIZWFkZXJzKHkpKSxcbiAgICAnaXNTZWN1cmUnOiBvYmouaXNTZWN1cmUsXG4gICAgJ3Byb3RvY29sJzogb2JqLnByb3RvY29sLFxuICAgICd0aW1lb3V0Jzogb2JqLnRpbWVvdXQsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBaaXBraW5TcGVjIGRlZmluZXMgWmlwa2luIHRyYWNlIGNvbmZpZ3VyYXRpb25zLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nWmlwa2luXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nWmlwa2luIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nWmlwa2luI2VuZHBvaW50QWRkcmVzc1xuICAgKi9cbiAgcmVhZG9ubHkgZW5kcG9pbnRBZGRyZXNzOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ1ppcGtpbicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1RyYWNpbmdaaXBraW4ob2JqOiBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdaaXBraW4gfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdlbmRwb2ludEFkZHJlc3MnOiBvYmouZW5kcG9pbnRBZGRyZXNzLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTmFtZWRDb25jdXJyZW5jeUxpbWl0IGRlZmluZXMgYSBwZXItbmFtZSBjb25jdXJyZW5jeSBsaW1pdCBmb3IgYSBzcGVjaWZpY1xuICogd29ya2Zsb3cgb3IgYWN0aXZpdHkgbmFtZS5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dBY3Rpdml0eUNvbmN1cnJlbmN5TGltaXRzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd0FjdGl2aXR5Q29uY3VycmVuY3lMaW1pdHMge1xuICAvKipcbiAgICogTWF4Q29uY3VycmVudCBpcyB0aGUgbWF4aW11bSBudW1iZXIgb2YgY29uY3VycmVudCBpbnZvY2F0aW9ucyBhY3Jvc3MgYWxsXG4gICAqIHJlcGxpY2FzLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dBY3Rpdml0eUNvbmN1cnJlbmN5TGltaXRzI21heENvbmN1cnJlbnRcbiAgICovXG4gIHJlYWRvbmx5IG1heENvbmN1cnJlbnQ/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIE5hbWUgaXMgdGhlIHdvcmtmbG93IG9yIGFjdGl2aXR5IG5hbWUgdG8gbGltaXQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd0FjdGl2aXR5Q29uY3VycmVuY3lMaW1pdHMjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZT86IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd0FjdGl2aXR5Q29uY3VycmVuY3lMaW1pdHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd0FjdGl2aXR5Q29uY3VycmVuY3lMaW1pdHMob2JqOiBDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93QWN0aXZpdHlDb25jdXJyZW5jeUxpbWl0cyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21heENvbmN1cnJlbnQnOiBvYmoubWF4Q29uY3VycmVudCxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU3RhdGVSZXRlbnRpb25Qb2xpY3kgZGVmaW5lcyB0aGUgcmV0ZW50aW9uIGNvbmZpZ3VyYXRpb24gZm9yIHdvcmtmbG93XG4gKiBzdGF0ZSBvbmNlIGEgd29ya2Zsb3cgcmVhY2hlcyBhIHRlcm1pbmFsIHN0YXRlLiBJZiBub3Qgc2V0LCB3b3JrZmxvd1xuICogaW5zdGFuY2VzIHdpbGwgbm90IGJlIGF1dG9tYXRpY2FsbHkgcHVyZ2VkLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd1N0YXRlUmV0ZW50aW9uUG9saWN5XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd1N0YXRlUmV0ZW50aW9uUG9saWN5IHtcbiAgLyoqXG4gICAqIEFueVRlcm1pbmFsIGlzIHRoZSBUVEwgZm9yIHB1cmdpbmcgd29ya2Zsb3cgaW5zdGFuY2VzIHRoYXQgcmVhY2ggYW55XG4gICAqIHRlcm1pbmFsIHN0YXRlLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dTdGF0ZVJldGVudGlvblBvbGljeSNhbnlUZXJtaW5hbFxuICAgKi9cbiAgcmVhZG9ubHkgYW55VGVybWluYWw/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIENvbXBsZXRlZCBpcyB0aGUgVFRMIGZvciBwdXJnaW5nIHdvcmtmbG93IGluc3RhbmNlcyB0aGF0IHJlYWNoIHRoZVxuICAgKiBDb21wbGV0ZWQgdGVybWluYWwgc3RhdGUuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd1N0YXRlUmV0ZW50aW9uUG9saWN5I2NvbXBsZXRlZFxuICAgKi9cbiAgcmVhZG9ubHkgY29tcGxldGVkPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBGYWlsZWQgaXMgdGhlIFRUTCBmb3IgcHVyZ2luZyB3b3JrZmxvdyBpbnN0YW5jZXMgdGhhdCByZWFjaCB0aGUgRmFpbGVkXG4gICAqIHRlcm1pbmFsIHN0YXRlLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dTdGF0ZVJldGVudGlvblBvbGljeSNmYWlsZWRcbiAgICovXG4gIHJlYWRvbmx5IGZhaWxlZD86IHN0cmluZztcblxuICAvKipcbiAgICogVGVybWluYXRlZCBpcyB0aGUgVFRMIGZvciBwdXJnaW5nIHdvcmtmbG93IGluc3RhbmNlcyB0aGF0IHJlYWNoIHRoZVxuICAgKiBUZXJtaW5hdGVkIHRlcm1pbmFsIHN0YXRlLlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dTdGF0ZVJldGVudGlvblBvbGljeSN0ZXJtaW5hdGVkXG4gICAqL1xuICByZWFkb25seSB0ZXJtaW5hdGVkPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93U3RhdGVSZXRlbnRpb25Qb2xpY3knIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd1N0YXRlUmV0ZW50aW9uUG9saWN5KG9iajogQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd1N0YXRlUmV0ZW50aW9uUG9saWN5IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYW55VGVybWluYWwnOiBvYmouYW55VGVybWluYWwsXG4gICAgJ2NvbXBsZXRlZCc6IG9iai5jb21wbGV0ZWQsXG4gICAgJ2ZhaWxlZCc6IG9iai5mYWlsZWQsXG4gICAgJ3Rlcm1pbmF0ZWQnOiBvYmoudGVybWluYXRlZCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE5hbWVkQ29uY3VycmVuY3lMaW1pdCBkZWZpbmVzIGEgcGVyLW5hbWUgY29uY3VycmVuY3kgbGltaXQgZm9yIGEgc3BlY2lmaWNcbiAqIHdvcmtmbG93IG9yIGFjdGl2aXR5IG5hbWUuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93V29ya2Zsb3dDb25jdXJyZW5jeUxpbWl0c1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dXb3JrZmxvd0NvbmN1cnJlbmN5TGltaXRzIHtcbiAgLyoqXG4gICAqIE1heENvbmN1cnJlbnQgaXMgdGhlIG1heGltdW0gbnVtYmVyIG9mIGNvbmN1cnJlbnQgaW52b2NhdGlvbnMgYWNyb3NzIGFsbFxuICAgKiByZXBsaWNhcy5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1dvcmtmbG93V29ya2Zsb3dDb25jdXJyZW5jeUxpbWl0cyNtYXhDb25jdXJyZW50XG4gICAqL1xuICByZWFkb25seSBtYXhDb25jdXJyZW50PzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBOYW1lIGlzIHRoZSB3b3JrZmxvdyBvciBhY3Rpdml0eSBuYW1lIHRvIGxpbWl0LlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dXb3JrZmxvd0NvbmN1cnJlbmN5TGltaXRzI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dXb3JrZmxvd0NvbmN1cnJlbmN5TGltaXRzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjV29ya2Zsb3dXb3JrZmxvd0NvbmN1cnJlbmN5TGltaXRzKG9iajogQ29uZmlndXJhdGlvblNwZWNXb3JrZmxvd1dvcmtmbG93Q29uY3VycmVuY3lMaW1pdHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtYXhDb25jdXJyZW50Jzogb2JqLm1heENvbmN1cnJlbnQsXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEFwcE9wZXJhdGlvbkFjdGlvbiBkZWZpbmVzIHRoZSBkYXRhIHN0cnVjdHVyZSBmb3IgZWFjaCBhcHAgb3BlcmF0aW9uLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXNPcGVyYXRpb25zXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXNPcGVyYXRpb25zIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXNPcGVyYXRpb25zI2FjdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgYWN0aW9uOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBY2Nlc3NDb250cm9sUG9saWNpZXNPcGVyYXRpb25zI2h0dHBWZXJiXG4gICAqL1xuICByZWFkb25seSBodHRwVmVyYj86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjQWNjZXNzQ29udHJvbFBvbGljaWVzT3BlcmF0aW9ucyNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjQWNjZXNzQ29udHJvbFBvbGljaWVzT3BlcmF0aW9ucycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2xQb2xpY2llc09wZXJhdGlvbnMob2JqOiBDb25maWd1cmF0aW9uU3BlY0FjY2Vzc0NvbnRyb2xQb2xpY2llc09wZXJhdGlvbnMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhY3Rpb24nOiBvYmouYWN0aW9uLFxuICAgICdodHRwVmVyYic6IG9iai5odHRwVmVyYj8ubWFwKHkgPT4geSksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlbGVjdG9yU3BlYyBzZWxlY3RzIHRhcmdldCBzZXJ2aWNlcyB0byB3aGljaCB0aGUgaGFuZGxlciBpcyB0byBiZSBhcHBsaWVkLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yI2ZpZWxkc1xuICAgKi9cbiAgcmVhZG9ubHkgZmllbGRzOiBDb25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3JGaWVsZHNbXTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvcihvYmo6IENvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvciB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2ZpZWxkcyc6IG9iai5maWVsZHM/Lm1hcCh5ID0+IHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0FwcEh0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3JGaWVsZHMoeSkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VsZWN0b3JTcGVjIHNlbGVjdHMgdGFyZ2V0IHNlcnZpY2VzIHRvIHdoaWNoIHRoZSBoYW5kbGVyIGlzIHRvIGJlIGFwcGxpZWQuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3JcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3Ige1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3IjZmllbGRzXG4gICAqL1xuICByZWFkb25seSBmaWVsZHM6IENvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkc1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3InIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yKG9iajogQ29uZmlndXJhdGlvblNwZWNIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZmllbGRzJzogb2JqLmZpZWxkcz8ubWFwKHkgPT4gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkcyh5KSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBNZXRyaWNzTGFiZWwgZGVmaW5lcyBhbiBvYmplY3QgdGhhdCBhbGxvd3MgdG8gc2V0IHJlZ2V4IGV4cHJlc3Npb25zIGZvciBhIGxhYmVsLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNSdWxlc0xhYmVsc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljUnVsZXNMYWJlbHMge1xuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpY1J1bGVzTGFiZWxzI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpY1J1bGVzTGFiZWxzI3JlZ2V4XG4gICAqL1xuICByZWFkb25seSByZWdleDogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNNZXRyaWNSdWxlc0xhYmVscycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY01ldHJpY1J1bGVzTGFiZWxzKG9iajogQ29uZmlndXJhdGlvblNwZWNNZXRyaWNSdWxlc0xhYmVscyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAncmVnZXgnOiAoKG9iai5yZWdleCkgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLnJlZ2V4KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE1ldHJpY3NMYWJlbCBkZWZpbmVzIGFuIG9iamVjdCB0aGF0IGFsbG93cyB0byBzZXQgcmVnZXggZXhwcmVzc2lvbnMgZm9yIGEgbGFiZWwuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NSdWxlc0xhYmVsc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljc1J1bGVzTGFiZWxzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzUnVsZXNMYWJlbHMjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjTWV0cmljc1J1bGVzTGFiZWxzI3JlZ2V4XG4gICAqL1xuICByZWFkb25seSByZWdleDogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzUnVsZXNMYWJlbHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNNZXRyaWNzUnVsZXNMYWJlbHMob2JqOiBDb25maWd1cmF0aW9uU3BlY01ldHJpY3NSdWxlc0xhYmVscyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAncmVnZXgnOiAoKG9iai5yZWdleCkgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLnJlZ2V4KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE5hbWUgb2YgdGhlIHZhbGlkYXRvclxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNNdGxzVG9rZW5WYWxpZGF0b3JzTmFtZVxuICovXG5leHBvcnQgZW51bSBDb25maWd1cmF0aW9uU3BlY010bHNUb2tlblZhbGlkYXRvcnNOYW1lIHtcbiAgLyoqIGp3a3MgKi9cbiAgSldLUyA9IFwiandrc1wiLFxufVxuXG4vKipcbiAqIE5hbWVWYWx1ZVBhaXIgaXMgYSBuYW1lL3ZhbHVlIHBhaXIuXG4gKlxuICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsSGVhZGVyc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWxIZWFkZXJzIHtcbiAgLyoqXG4gICAqIEVudlJlZiBpcyB0aGUgbmFtZSBvZiBhbiBlbnZpcm9ubWVudGFsIHZhcmlhYmxlIHRvIHJlYWQgdGhlIHZhbHVlIGZyb20uXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbEhlYWRlcnMjZW52UmVmXG4gICAqL1xuICByZWFkb25seSBlbnZSZWY/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE5hbWUgb2YgdGhlIHByb3BlcnR5LlxuICAgKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWxIZWFkZXJzI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbEhlYWRlcnMjc2VjcmV0S2V5UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRLZXlSZWY/OiBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsSGVhZGVyc1NlY3JldEtleVJlZjtcblxuICAvKipcbiAgICogVmFsdWUgb2YgdGhlIHByb3BlcnR5LCBpbiBwbGFpbnRleHQuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbEhlYWRlcnMjdmFsdWVcbiAgICovXG4gIHJlYWRvbmx5IHZhbHVlPzogYW55O1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsSGVhZGVycycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsSGVhZGVycyhvYmo6IENvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWxIZWFkZXJzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZW52UmVmJzogb2JqLmVudlJlZixcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICdzZWNyZXRLZXlSZWYnOiB0b0pzb25fQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbEhlYWRlcnNTZWNyZXRLZXlSZWYob2JqLnNlY3JldEtleVJlZiksXG4gICAgJ3ZhbHVlJzogb2JqLnZhbHVlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VsZWN0b3JGaWVsZCBkZWZpbmVzIGEgc2VsZWN0b3IgZmllbGRzLlxuICpcbiAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yRmllbGRzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yRmllbGRzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yRmllbGRzI2ZpZWxkXG4gICAqL1xuICByZWFkb25seSBmaWVsZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkcyN2YWx1ZVxuICAgKi9cbiAgcmVhZG9ubHkgdmFsdWU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnQ29uZmlndXJhdGlvblNwZWNBcHBIdHRwUGlwZWxpbmVIYW5kbGVyc1NlbGVjdG9yRmllbGRzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0NvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkcyhvYmo6IENvbmZpZ3VyYXRpb25TcGVjQXBwSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2ZpZWxkJzogb2JqLmZpZWxkLFxuICAgICd2YWx1ZSc6IG9iai52YWx1ZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlbGVjdG9yRmllbGQgZGVmaW5lcyBhIHNlbGVjdG9yIGZpZWxkcy5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkcyNmaWVsZFxuICAgKi9cbiAgcmVhZG9ubHkgZmllbGQ6IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3JGaWVsZHMjdmFsdWVcbiAgICovXG4gIHJlYWRvbmx5IHZhbHVlOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0NvbmZpZ3VyYXRpb25TcGVjSHR0cFBpcGVsaW5lSGFuZGxlcnNTZWxlY3RvckZpZWxkcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3JGaWVsZHMob2JqOiBDb25maWd1cmF0aW9uU3BlY0h0dHBQaXBlbGluZUhhbmRsZXJzU2VsZWN0b3JGaWVsZHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdmaWVsZCc6IG9iai5maWVsZCxcbiAgICAndmFsdWUnOiBvYmoudmFsdWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTZWNyZXRLZXlSZWYgaXMgdGhlIHJlZmVyZW5jZSBvZiBhIHZhbHVlIGluIGEgc2VjcmV0IHN0b3JlIGNvbXBvbmVudC5cbiAqXG4gKiBAc2NoZW1hIENvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWxIZWFkZXJzU2VjcmV0S2V5UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbEhlYWRlcnNTZWNyZXRLZXlSZWYge1xuICAvKipcbiAgICogRmllbGQgaW4gdGhlIHNlY3JldC5cbiAgICpcbiAgICogQHNjaGVtYSBDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsSGVhZGVyc1NlY3JldEtleVJlZiNrZXlcbiAgICovXG4gIHJlYWRvbmx5IGtleT86IHN0cmluZztcblxuICAvKipcbiAgICogU2VjcmV0IG5hbWUuXG4gICAqXG4gICAqIEBzY2hlbWEgQ29uZmlndXJhdGlvblNwZWNUcmFjaW5nT3RlbEhlYWRlcnNTZWNyZXRLZXlSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdDb25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsSGVhZGVyc1NlY3JldEtleVJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Db25maWd1cmF0aW9uU3BlY1RyYWNpbmdPdGVsSGVhZGVyc1NlY3JldEtleVJlZihvYmo6IENvbmZpZ3VyYXRpb25TcGVjVHJhY2luZ090ZWxIZWFkZXJzU2VjcmV0S2V5UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cblxuLyoqXG4gKiBIVFRQRW5kcG9pbnQgZGVzY3JpYmVzIGEgRGFwciBIVFRQRW5kcG9pbnQgdHlwZSBmb3IgZXh0ZXJuYWwgc2VydmljZSBpbnZvY2F0aW9uLlxuVGhpcyBlbmRwb2ludCBjYW4gYmUgZXh0ZXJuYWwgdG8gRGFwciwgb3IgZXh0ZXJuYWwgdG8gdGhlIGVudmlyb25tZW50LlxuICpcbiAqIEBzY2hlbWEgSFRUUEVuZHBvaW50XG4gKi9cbmV4cG9ydCBjbGFzcyBIdHRwRW5kcG9pbnQgZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJIVFRQRW5kcG9pbnRcIlxuICAgKi9cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSBHVks6IEdyb3VwVmVyc2lvbktpbmQgPSB7XG4gICAgYXBpVmVyc2lvbjogJ2RhcHIuaW8vdjFhbHBoYTEnLFxuICAgIGtpbmQ6ICdIVFRQRW5kcG9pbnQnLFxuICB9XG5cbiAgLyoqXG4gICAqIFJlbmRlcnMgYSBLdWJlcm5ldGVzIG1hbmlmZXN0IGZvciBcIkhUVFBFbmRwb2ludFwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBIdHRwRW5kcG9pbnRQcm9wcyA9IHt9KTogYW55IHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uSHR0cEVuZHBvaW50LkdWSyxcbiAgICAgIC4uLnRvSnNvbl9IdHRwRW5kcG9pbnRQcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJIVFRQRW5kcG9pbnRcIiBBUEkgb2JqZWN0XG4gICAqIEBwYXJhbSBzY29wZSB0aGUgc2NvcGUgaW4gd2hpY2ggdG8gZGVmaW5lIHRoaXMgb2JqZWN0XG4gICAqIEBwYXJhbSBpZCBhIHNjb3BlLWxvY2FsIG5hbWUgZm9yIHRoZSBvYmplY3RcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IEh0dHBFbmRwb2ludFByb3BzID0ge30pIHtcbiAgICBzdXBlcihzY29wZSwgaWQsIHtcbiAgICAgIC4uLkh0dHBFbmRwb2ludC5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIG92ZXJyaWRlIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uSHR0cEVuZHBvaW50LkdWSyxcbiAgICAgIC4uLnRvSnNvbl9IdHRwRW5kcG9pbnRQcm9wcyhyZXNvbHZlZCksXG4gICAgfTtcbiAgfVxufVxuXG4vKipcbiAqIEhUVFBFbmRwb2ludCBkZXNjcmliZXMgYSBEYXByIEhUVFBFbmRwb2ludCB0eXBlIGZvciBleHRlcm5hbCBzZXJ2aWNlIGludm9jYXRpb24uXG4gKiBUaGlzIGVuZHBvaW50IGNhbiBiZSBleHRlcm5hbCB0byBEYXByLCBvciBleHRlcm5hbCB0byB0aGUgZW52aXJvbm1lbnQuXG4gKlxuICogQHNjaGVtYSBIVFRQRW5kcG9pbnRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBIdHRwRW5kcG9pbnRQcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEhUVFBFbmRwb2ludCNtZXRhZGF0YVxuICAgKi9cbiAgcmVhZG9ubHkgbWV0YWRhdGE/OiBBcGlPYmplY3RNZXRhZGF0YTtcblxuICAvKipcbiAgICogQXV0aCByZXByZXNlbnRzIGF1dGhlbnRpY2F0aW9uIGRldGFpbHMgZm9yIHRoZSBjb21wb25lbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgSFRUUEVuZHBvaW50I2F1dGhcbiAgICovXG4gIHJlYWRvbmx5IGF1dGg/OiBIdHRwRW5kcG9pbnRBdXRoO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIEhUVFBFbmRwb2ludCNzY29wZXNcbiAgICovXG4gIHJlYWRvbmx5IHNjb3Blcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBIVFRQRW5kcG9pbnRTcGVjIGRlc2NyaWJlcyBhbiBhY2Nlc3Mgc3BlY2lmaWNhdGlvbiBmb3IgYWxsb3dpbmcgZXh0ZXJuYWwgc2VydmljZSBpbnZvY2F0aW9ucy5cbiAgICpcbiAgICogQHNjaGVtYSBIVFRQRW5kcG9pbnQjc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IEh0dHBFbmRwb2ludFNwZWM7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0h0dHBFbmRwb2ludFByb3BzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0h0dHBFbmRwb2ludFByb3BzKG9iajogSHR0cEVuZHBvaW50UHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnYXV0aCc6IHRvSnNvbl9IdHRwRW5kcG9pbnRBdXRoKG9iai5hdXRoKSxcbiAgICAnc2NvcGVzJzogb2JqLnNjb3Blcz8ubWFwKHkgPT4geSksXG4gICAgJ3NwZWMnOiB0b0pzb25fSHR0cEVuZHBvaW50U3BlYyhvYmouc3BlYyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBBdXRoIHJlcHJlc2VudHMgYXV0aGVudGljYXRpb24gZGV0YWlscyBmb3IgdGhlIGNvbXBvbmVudC5cbiAqXG4gKiBAc2NoZW1hIEh0dHBFbmRwb2ludEF1dGhcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBIdHRwRW5kcG9pbnRBdXRoIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50QXV0aCNzZWNyZXRTdG9yZVxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0U3RvcmU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnSHR0cEVuZHBvaW50QXV0aCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9IdHRwRW5kcG9pbnRBdXRoKG9iajogSHR0cEVuZHBvaW50QXV0aCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3NlY3JldFN0b3JlJzogb2JqLnNlY3JldFN0b3JlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogSFRUUEVuZHBvaW50U3BlYyBkZXNjcmliZXMgYW4gYWNjZXNzIHNwZWNpZmljYXRpb24gZm9yIGFsbG93aW5nIGV4dGVybmFsIHNlcnZpY2UgaW52b2NhdGlvbnMuXG4gKlxuICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSHR0cEVuZHBvaW50U3BlYyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWMjYmFzZVVybFxuICAgKi9cbiAgcmVhZG9ubHkgYmFzZVVybDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUTFMgZGVzY3JpYmVzIGhvdyB0byBidWlsZCBjbGllbnQgb3Igc2VydmVyIFRMUyBjb25maWd1cmF0aW9ucy5cbiAgICpcbiAgICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjI2NsaWVudFRMU1xuICAgKi9cbiAgcmVhZG9ubHkgY2xpZW50VGxzPzogSHR0cEVuZHBvaW50U3BlY0NsaWVudFRscztcblxuICAvKipcbiAgICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjI2hlYWRlcnNcbiAgICovXG4gIHJlYWRvbmx5IGhlYWRlcnM/OiBIdHRwRW5kcG9pbnRTcGVjSGVhZGVyc1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdIdHRwRW5kcG9pbnRTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0h0dHBFbmRwb2ludFNwZWMob2JqOiBIdHRwRW5kcG9pbnRTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYmFzZVVybCc6IG9iai5iYXNlVXJsLFxuICAgICdjbGllbnRUTFMnOiB0b0pzb25fSHR0cEVuZHBvaW50U3BlY0NsaWVudFRscyhvYmouY2xpZW50VGxzKSxcbiAgICAnaGVhZGVycyc6IG9iai5oZWFkZXJzPy5tYXAoeSA9PiB0b0pzb25fSHR0cEVuZHBvaW50U3BlY0hlYWRlcnMoeSkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogVExTIGRlc2NyaWJlcyBob3cgdG8gYnVpbGQgY2xpZW50IG9yIHNlcnZlciBUTFMgY29uZmlndXJhdGlvbnMuXG4gKlxuICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRscyB7XG4gIC8qKlxuICAgKiBUTFNEb2N1bWVudCBkZXNjcmliZXMgYW5kIGluLWxpbmUgb3IgcG9pbnRlciB0byBhIGRvY3VtZW50IHRvIGJ1aWxkIGEgVExTIGNvbmZpZ3VyYXRpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRscyNjZXJ0aWZpY2F0ZVxuICAgKi9cbiAgcmVhZG9ubHkgY2VydGlmaWNhdGU/OiBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzQ2VydGlmaWNhdGU7XG5cbiAgLyoqXG4gICAqIFRMU0RvY3VtZW50IGRlc2NyaWJlcyBhbmQgaW4tbGluZSBvciBwb2ludGVyIHRvIGEgZG9jdW1lbnQgdG8gYnVpbGQgYSBUTFMgY29uZmlndXJhdGlvbi5cbiAgICpcbiAgICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzI3ByaXZhdGVLZXlcbiAgICovXG4gIHJlYWRvbmx5IHByaXZhdGVLZXk/OiBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUHJpdmF0ZUtleTtcblxuICAvKipcbiAgICogUmVuZWdvdGlhdGlvbiBzZXRzIHRoZSB1bmRlcmx5aW5nIHRscyBuZWdvdGlhdGlvbiBzdHJhdGVneSBmb3IgYW4gaHR0cCBjaGFubmVsLlxuICAgKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHMjcmVuZWdvdGlhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgcmVuZWdvdGlhdGlvbj86IEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSZW5lZ290aWF0aW9uO1xuXG4gIC8qKlxuICAgKiBUTFNEb2N1bWVudCBkZXNjcmliZXMgYW5kIGluLWxpbmUgb3IgcG9pbnRlciB0byBhIGRvY3VtZW50IHRvIGJ1aWxkIGEgVExTIGNvbmZpZ3VyYXRpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRscyNyb290Q0FcbiAgICovXG4gIHJlYWRvbmx5IHJvb3RDYT86IEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSb290Q2E7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0h0dHBFbmRwb2ludFNwZWNDbGllbnRUbHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fSHR0cEVuZHBvaW50U3BlY0NsaWVudFRscyhvYmo6IEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdjZXJ0aWZpY2F0ZSc6IHRvSnNvbl9IdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzQ2VydGlmaWNhdGUob2JqLmNlcnRpZmljYXRlKSxcbiAgICAncHJpdmF0ZUtleSc6IHRvSnNvbl9IdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUHJpdmF0ZUtleShvYmoucHJpdmF0ZUtleSksXG4gICAgJ3JlbmVnb3RpYXRpb24nOiBvYmoucmVuZWdvdGlhdGlvbixcbiAgICAncm9vdENBJzogdG9Kc29uX0h0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSb290Q2Eob2JqLnJvb3RDYSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBOYW1lVmFsdWVQYWlyIGlzIGEgbmFtZS92YWx1ZSBwYWlyLlxuICpcbiAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0hlYWRlcnNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBIdHRwRW5kcG9pbnRTcGVjSGVhZGVycyB7XG4gIC8qKlxuICAgKiBFbnZSZWYgaXMgdGhlIG5hbWUgb2YgYW4gZW52aXJvbm1lbnRhbCB2YXJpYWJsZSB0byByZWFkIHRoZSB2YWx1ZSBmcm9tLlxuICAgKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNIZWFkZXJzI2VudlJlZlxuICAgKi9cbiAgcmVhZG9ubHkgZW52UmVmPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOYW1lIG9mIHRoZSBwcm9wZXJ0eS5cbiAgICpcbiAgICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjSGVhZGVycyNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldEtleVJlZiBpcyB0aGUgcmVmZXJlbmNlIG9mIGEgdmFsdWUgaW4gYSBzZWNyZXQgc3RvcmUgY29tcG9uZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNIZWFkZXJzI3NlY3JldEtleVJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0S2V5UmVmPzogSHR0cEVuZHBvaW50U3BlY0hlYWRlcnNTZWNyZXRLZXlSZWY7XG5cbiAgLyoqXG4gICAqIFZhbHVlIG9mIHRoZSBwcm9wZXJ0eSwgaW4gcGxhaW50ZXh0LlxuICAgKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNIZWFkZXJzI3ZhbHVlXG4gICAqL1xuICByZWFkb25seSB2YWx1ZT86IGFueTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnSHR0cEVuZHBvaW50U3BlY0hlYWRlcnMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fSHR0cEVuZHBvaW50U3BlY0hlYWRlcnMob2JqOiBIdHRwRW5kcG9pbnRTcGVjSGVhZGVycyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2VudlJlZic6IG9iai5lbnZSZWYsXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnc2VjcmV0S2V5UmVmJzogdG9Kc29uX0h0dHBFbmRwb2ludFNwZWNIZWFkZXJzU2VjcmV0S2V5UmVmKG9iai5zZWNyZXRLZXlSZWYpLFxuICAgICd2YWx1ZSc6IG9iai52YWx1ZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRMU0RvY3VtZW50IGRlc2NyaWJlcyBhbmQgaW4tbGluZSBvciBwb2ludGVyIHRvIGEgZG9jdW1lbnQgdG8gYnVpbGQgYSBUTFMgY29uZmlndXJhdGlvbi5cbiAqXG4gKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNDZXJ0aWZpY2F0ZVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNDZXJ0aWZpY2F0ZSB7XG4gIC8qKlxuICAgKiBTZWNyZXRLZXlSZWYgaXMgdGhlIHJlZmVyZW5jZSBvZiBhIHZhbHVlIGluIGEgc2VjcmV0IHN0b3JlIGNvbXBvbmVudC5cbiAgICpcbiAgICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzQ2VydGlmaWNhdGUjc2VjcmV0S2V5UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRLZXlSZWY/OiBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzQ2VydGlmaWNhdGVTZWNyZXRLZXlSZWY7XG5cbiAgLyoqXG4gICAqIFZhbHVlIG9mIHRoZSBwcm9wZXJ0eSwgaW4gcGxhaW50ZXh0LlxuICAgKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNDZXJ0aWZpY2F0ZSN2YWx1ZVxuICAgKi9cbiAgcmVhZG9ubHkgdmFsdWU/OiBhbnk7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ0h0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNDZXJ0aWZpY2F0ZScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9IdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzQ2VydGlmaWNhdGUob2JqOiBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzQ2VydGlmaWNhdGUgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdzZWNyZXRLZXlSZWYnOiB0b0pzb25fSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc0NlcnRpZmljYXRlU2VjcmV0S2V5UmVmKG9iai5zZWNyZXRLZXlSZWYpLFxuICAgICd2YWx1ZSc6IG9iai52YWx1ZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRMU0RvY3VtZW50IGRlc2NyaWJlcyBhbmQgaW4tbGluZSBvciBwb2ludGVyIHRvIGEgZG9jdW1lbnQgdG8gYnVpbGQgYSBUTFMgY29uZmlndXJhdGlvbi5cbiAqXG4gKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNQcml2YXRlS2V5XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1ByaXZhdGVLZXkge1xuICAvKipcbiAgICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1ByaXZhdGVLZXkjc2VjcmV0S2V5UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRLZXlSZWY/OiBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUHJpdmF0ZUtleVNlY3JldEtleVJlZjtcblxuICAvKipcbiAgICogVmFsdWUgb2YgdGhlIHByb3BlcnR5LCBpbiBwbGFpbnRleHQuXG4gICAqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1ByaXZhdGVLZXkjdmFsdWVcbiAgICovXG4gIHJlYWRvbmx5IHZhbHVlPzogYW55O1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUHJpdmF0ZUtleScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9IdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUHJpdmF0ZUtleShvYmo6IEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNQcml2YXRlS2V5IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VjcmV0S2V5UmVmJzogdG9Kc29uX0h0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNQcml2YXRlS2V5U2VjcmV0S2V5UmVmKG9iai5zZWNyZXRLZXlSZWYpLFxuICAgICd2YWx1ZSc6IG9iai52YWx1ZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFJlbmVnb3RpYXRpb24gc2V0cyB0aGUgdW5kZXJseWluZyB0bHMgbmVnb3RpYXRpb24gc3RyYXRlZ3kgZm9yIGFuIGh0dHAgY2hhbm5lbC5cbiAqXG4gKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSZW5lZ290aWF0aW9uXG4gKi9cbmV4cG9ydCBlbnVtIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSZW5lZ290aWF0aW9uIHtcbiAgLyoqIE5ldmVyICovXG4gIE5FVkVSID0gXCJOZXZlclwiLFxuICAvKiogT25jZUFzQ2xpZW50ICovXG4gIE9OQ0VfQVNfQ0xJRU5UID0gXCJPbmNlQXNDbGllbnRcIixcbiAgLyoqIEZyZWVseUFzQ2xpZW50ICovXG4gIEZSRUVMWV9BU19DTElFTlQgPSBcIkZyZWVseUFzQ2xpZW50XCIsXG59XG5cbi8qKlxuICogVExTRG9jdW1lbnQgZGVzY3JpYmVzIGFuZCBpbi1saW5lIG9yIHBvaW50ZXIgdG8gYSBkb2N1bWVudCB0byBidWlsZCBhIFRMUyBjb25maWd1cmF0aW9uLlxuICpcbiAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1Jvb3RDYVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSb290Q2Ege1xuICAvKipcbiAgICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1Jvb3RDYSNzZWNyZXRLZXlSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldEtleVJlZj86IEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSb290Q2FTZWNyZXRLZXlSZWY7XG5cbiAgLyoqXG4gICAqIFZhbHVlIG9mIHRoZSBwcm9wZXJ0eSwgaW4gcGxhaW50ZXh0LlxuICAgKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSb290Q2EjdmFsdWVcbiAgICovXG4gIHJlYWRvbmx5IHZhbHVlPzogYW55O1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUm9vdENhJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX0h0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSb290Q2Eob2JqOiBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUm9vdENhIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnc2VjcmV0S2V5UmVmJzogdG9Kc29uX0h0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSb290Q2FTZWNyZXRLZXlSZWYob2JqLnNlY3JldEtleVJlZiksXG4gICAgJ3ZhbHVlJzogb2JqLnZhbHVlLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gKlxuICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjSGVhZGVyc1NlY3JldEtleVJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEh0dHBFbmRwb2ludFNwZWNIZWFkZXJzU2VjcmV0S2V5UmVmIHtcbiAgLyoqXG4gICAqIEZpZWxkIGluIHRoZSBzZWNyZXQuXG4gICAqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0hlYWRlcnNTZWNyZXRLZXlSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldCBuYW1lLlxuICAgKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNIZWFkZXJzU2VjcmV0S2V5UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnSHR0cEVuZHBvaW50U3BlY0hlYWRlcnNTZWNyZXRLZXlSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fSHR0cEVuZHBvaW50U3BlY0hlYWRlcnNTZWNyZXRLZXlSZWYob2JqOiBIdHRwRW5kcG9pbnRTcGVjSGVhZGVyc1NlY3JldEtleVJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlY3JldEtleVJlZiBpcyB0aGUgcmVmZXJlbmNlIG9mIGEgdmFsdWUgaW4gYSBzZWNyZXQgc3RvcmUgY29tcG9uZW50LlxuICpcbiAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc0NlcnRpZmljYXRlU2VjcmV0S2V5UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc0NlcnRpZmljYXRlU2VjcmV0S2V5UmVmIHtcbiAgLyoqXG4gICAqIEZpZWxkIGluIHRoZSBzZWNyZXQuXG4gICAqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc0NlcnRpZmljYXRlU2VjcmV0S2V5UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZWNyZXQgbmFtZS5cbiAgICpcbiAgICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzQ2VydGlmaWNhdGVTZWNyZXRLZXlSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzQ2VydGlmaWNhdGVTZWNyZXRLZXlSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc0NlcnRpZmljYXRlU2VjcmV0S2V5UmVmKG9iajogSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc0NlcnRpZmljYXRlU2VjcmV0S2V5UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gKlxuICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUHJpdmF0ZUtleVNlY3JldEtleVJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNQcml2YXRlS2V5U2VjcmV0S2V5UmVmIHtcbiAgLyoqXG4gICAqIEZpZWxkIGluIHRoZSBzZWNyZXQuXG4gICAqXG4gICAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1ByaXZhdGVLZXlTZWNyZXRLZXlSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldCBuYW1lLlxuICAgKlxuICAgKiBAc2NoZW1hIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNQcml2YXRlS2V5U2VjcmV0S2V5UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1ByaXZhdGVLZXlTZWNyZXRLZXlSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1ByaXZhdGVLZXlTZWNyZXRLZXlSZWYob2JqOiBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUHJpdmF0ZUtleVNlY3JldEtleVJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNlY3JldEtleVJlZiBpcyB0aGUgcmVmZXJlbmNlIG9mIGEgdmFsdWUgaW4gYSBzZWNyZXQgc3RvcmUgY29tcG9uZW50LlxuICpcbiAqIEBzY2hlbWEgSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1Jvb3RDYVNlY3JldEtleVJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEh0dHBFbmRwb2ludFNwZWNDbGllbnRUbHNSb290Q2FTZWNyZXRLZXlSZWYge1xuICAvKipcbiAgICogRmllbGQgaW4gdGhlIHNlY3JldC5cbiAgICpcbiAgICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUm9vdENhU2VjcmV0S2V5UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZWNyZXQgbmFtZS5cbiAgICpcbiAgICogQHNjaGVtYSBIdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUm9vdENhU2VjcmV0S2V5UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1Jvb3RDYVNlY3JldEtleVJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9IdHRwRW5kcG9pbnRTcGVjQ2xpZW50VGxzUm9vdENhU2VjcmV0S2V5UmVmKG9iajogSHR0cEVuZHBvaW50U3BlY0NsaWVudFRsc1Jvb3RDYVNlY3JldEtleVJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG5cbi8qKlxuICogTUNQU2VydmVyIGRlc2NyaWJlcyBhIERhcHIgTUNQU2VydmVyIHJlc291cmNlIHRoYXQgZGVjbGFyZXMgYSBjb25uZWN0aW9uIHRvXG5hbiBNQ1AgKE1vZGVsIENvbnRleHQgUHJvdG9jb2wpIHNlcnZlciBmb3IgZHVyYWJsZSB0b29sIGV4ZWN1dGlvbi5cbiAqXG4gKiBAc2NoZW1hIE1DUFNlcnZlclxuICovXG5leHBvcnQgY2xhc3MgTWNwU2VydmVyIGV4dGVuZHMgQXBpT2JqZWN0IHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFwaVZlcnNpb24gYW5kIGtpbmQgZm9yIFwiTUNQU2VydmVyXCJcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgR1ZLOiBHcm91cFZlcnNpb25LaW5kID0ge1xuICAgIGFwaVZlcnNpb246ICdkYXByLmlvL3YxYWxwaGExJyxcbiAgICBraW5kOiAnTUNQU2VydmVyJyxcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIGEgS3ViZXJuZXRlcyBtYW5pZmVzdCBmb3IgXCJNQ1BTZXJ2ZXJcIi5cbiAgICpcbiAgICogVGhpcyBjYW4gYmUgdXNlZCB0byBpbmxpbmUgcmVzb3VyY2UgbWFuaWZlc3RzIGluc2lkZSBvdGhlciBvYmplY3RzIChlLmcuIGFzIHRlbXBsYXRlcykuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtYW5pZmVzdChwcm9wczogTWNwU2VydmVyUHJvcHMgPSB7fSk6IGFueSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLk1jcFNlcnZlci5HVkssXG4gICAgICAuLi50b0pzb25fTWNwU2VydmVyUHJvcHMocHJvcHMpLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhIFwiTUNQU2VydmVyXCIgQVBJIG9iamVjdFxuICAgKiBAcGFyYW0gc2NvcGUgdGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIG9iamVjdFxuICAgKiBAcGFyYW0gaWQgYSBzY29wZS1sb2NhbCBuYW1lIGZvciB0aGUgb2JqZWN0XG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBNY3BTZXJ2ZXJQcm9wcyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICAuLi5NY3BTZXJ2ZXIuR1ZLLFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyB0aGUgb2JqZWN0IHRvIEt1YmVybmV0ZXMgSlNPTi5cbiAgICovXG4gIHB1YmxpYyBvdmVycmlkZSB0b0pzb24oKTogYW55IHtcbiAgICBjb25zdCByZXNvbHZlZCA9IHN1cGVyLnRvSnNvbigpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLk1jcFNlcnZlci5HVkssXG4gICAgICAuLi50b0pzb25fTWNwU2VydmVyUHJvcHMocmVzb2x2ZWQpLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBNQ1BTZXJ2ZXIgZGVzY3JpYmVzIGEgRGFwciBNQ1BTZXJ2ZXIgcmVzb3VyY2UgdGhhdCBkZWNsYXJlcyBhIGNvbm5lY3Rpb24gdG9cbiAqIGFuIE1DUCAoTW9kZWwgQ29udGV4dCBQcm90b2NvbCkgc2VydmVyIGZvciBkdXJhYmxlIHRvb2wgZXhlY3V0aW9uLlxuICpcbiAqIEBzY2hlbWEgTUNQU2VydmVyXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyUHJvcHMge1xuICAvKipcbiAgICogQHNjaGVtYSBNQ1BTZXJ2ZXIjbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogQXBpT2JqZWN0TWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgTUNQU2VydmVyI3Njb3Blc1xuICAgKi9cbiAgcmVhZG9ubHkgc2NvcGVzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIE1DUFNlcnZlclNwZWMgaXMgdGhlIGZ1bGwgY29uZmlndXJhdGlvbiBmb3IgYW4gTUNQIHNlcnZlciBjb25uZWN0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIE1DUFNlcnZlciNzcGVjXG4gICAqL1xuICByZWFkb25seSBzcGVjPzogTWNwU2VydmVyU3BlYztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyUHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyUHJvcHMob2JqOiBNY3BTZXJ2ZXJQcm9wcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ21ldGFkYXRhJzogb2JqLm1ldGFkYXRhLFxuICAgICdzY29wZXMnOiBvYmouc2NvcGVzPy5tYXAoeSA9PiB5KSxcbiAgICAnc3BlYyc6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE1DUFNlcnZlclNwZWMgaXMgdGhlIGZ1bGwgY29uZmlndXJhdGlvbiBmb3IgYW4gTUNQIHNlcnZlciBjb25uZWN0aW9uLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWMge1xuICAvKipcbiAgICogQ2F0YWxvZyBob2xkcyB1c2VyLWZhY2luZyBnb3Zlcm5hbmNlIG1ldGFkYXRhIChkaXNwbGF5IG5hbWUsIGRlc2NyaXB0aW9uLFxuICAgKiBvd25lciwgdGFncywgbGlua3MpLiBJdCBpcyBwdXJlbHkgaW5mb3JtYXRpb25hbCBhbmQgbm90IHVzZWQgYXQgcnVudGltZS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjI2NhdGFsb2dcbiAgICovXG4gIHJlYWRvbmx5IGNhdGFsb2c/OiBNY3BTZXJ2ZXJTcGVjQ2F0YWxvZztcblxuICAvKipcbiAgICogRW5kcG9pbnQgZGVzY3JpYmVzIHRoZSB0cmFuc3BvcnQgYW5kIHRhcmdldCBvZiB0aGUgTUNQIHNlcnZlci5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjI2VuZHBvaW50XG4gICAqL1xuICByZWFkb25seSBlbmRwb2ludDogTWNwU2VydmVyU3BlY0VuZHBvaW50O1xuXG4gIC8qKlxuICAgKiBJZ25vcmVFcnJvcnMsIHdoZW4gdHJ1ZSwgYWxsb3dzIGRhcHJkIHRvIGNvbnRpbnVlIHJ1bm5pbmcgaWYgdmFsaWRhdGlvblxuICAgKiBvciBzZWNyZXQgcmVzb2x1dGlvbiBmYWlscyBmb3IgdGhpcyBNQ1BTZXJ2ZXIuIFdoZW4gZmFsc2UgKGRlZmF1bHQpLFxuICAgKiBzdWNoIGZhaWx1cmVzIGNhdXNlIGRhcHJkIHRvIGV4aXQgZ3JhY2VmdWxseS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjI2lnbm9yZUVycm9yc1xuICAgKi9cbiAgcmVhZG9ubHkgaWdub3JlRXJyb3JzPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogTWlkZGxld2FyZSBkZWZpbmVzIG9wdGlvbmFsIHdvcmtmbG93IGhvb2tzIGludm9rZWQgYXJvdW5kIGVhY2ggdG9vbCBjYWxsLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWMjbWlkZGxld2FyZVxuICAgKi9cbiAgcmVhZG9ubHkgbWlkZGxld2FyZT86IE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWMob2JqOiBNY3BTZXJ2ZXJTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnY2F0YWxvZyc6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjQ2F0YWxvZyhvYmouY2F0YWxvZyksXG4gICAgJ2VuZHBvaW50JzogdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludChvYmouZW5kcG9pbnQpLFxuICAgICdpZ25vcmVFcnJvcnMnOiBvYmouaWdub3JlRXJyb3JzLFxuICAgICdtaWRkbGV3YXJlJzogdG9Kc29uX01jcFNlcnZlclNwZWNNaWRkbGV3YXJlKG9iai5taWRkbGV3YXJlKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIENhdGFsb2cgaG9sZHMgdXNlci1mYWNpbmcgZ292ZXJuYW5jZSBtZXRhZGF0YSAoZGlzcGxheSBuYW1lLCBkZXNjcmlwdGlvbixcbiAqIG93bmVyLCB0YWdzLCBsaW5rcykuIEl0IGlzIHB1cmVseSBpbmZvcm1hdGlvbmFsIGFuZCBub3QgdXNlZCBhdCBydW50aW1lLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0NhdGFsb2dcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjQ2F0YWxvZyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNDYXRhbG9nI2Rlc2NyaXB0aW9uXG4gICAqL1xuICByZWFkb25seSBkZXNjcmlwdGlvbj86IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjQ2F0YWxvZyNkaXNwbGF5TmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgZGlzcGxheU5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIExpbmtzIGlzIGEgZnJlZS1mb3JtIG1hcCBvZiBuYW1lZCBVUkxzIChlLmcuIFwiZG9jc1wiLCBcInJ1bmJvb2tcIiwgXCJkYXNoYm9hcmRcIikuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0NhdGFsb2cjbGlua3NcbiAgICovXG4gIHJlYWRvbmx5IGxpbmtzPzogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcblxuICAvKipcbiAgICogTUNQQ2F0YWxvZ093bmVyIGlkZW50aWZpZXMgdGhlIHRlYW0gcmVzcG9uc2libGUgZm9yIHRoZSBNQ1Agc2VydmVyLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNDYXRhbG9nI293bmVyXG4gICAqL1xuICByZWFkb25seSBvd25lcj86IE1jcFNlcnZlclNwZWNDYXRhbG9nT3duZXI7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0NhdGFsb2cjdGFnc1xuICAgKi9cbiAgcmVhZG9ubHkgdGFncz86IHN0cmluZ1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjQ2F0YWxvZycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9NY3BTZXJ2ZXJTcGVjQ2F0YWxvZyhvYmo6IE1jcFNlcnZlclNwZWNDYXRhbG9nIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZGVzY3JpcHRpb24nOiBvYmouZGVzY3JpcHRpb24sXG4gICAgJ2Rpc3BsYXlOYW1lJzogb2JqLmRpc3BsYXlOYW1lLFxuICAgICdsaW5rcyc6ICgob2JqLmxpbmtzKSA9PT0gdW5kZWZpbmVkKSA/IHVuZGVmaW5lZCA6IChPYmplY3QuZW50cmllcyhvYmoubGlua3MpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSkpLFxuICAgICdvd25lcic6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjQ2F0YWxvZ093bmVyKG9iai5vd25lciksXG4gICAgJ3RhZ3MnOiBvYmoudGFncz8ubWFwKHkgPT4geSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBFbmRwb2ludCBkZXNjcmliZXMgdGhlIHRyYW5zcG9ydCBhbmQgdGFyZ2V0IG9mIHRoZSBNQ1Agc2VydmVyLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0VuZHBvaW50IHtcbiAgLyoqXG4gICAqIFNTRSBob2xkcyBjb25maWd1cmF0aW9uIGZvciB0aGUgbGVnYWN5IFNTRSB0cmFuc3BvcnQuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50I3NzZVxuICAgKi9cbiAgcmVhZG9ubHkgc3NlPzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlO1xuXG4gIC8qKlxuICAgKiBTdGRpbyBob2xkcyBjb25maWd1cmF0aW9uIGZvciB0aGUgc3RkaW8gc3VicHJvY2VzcyB0cmFuc3BvcnQuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50I3N0ZGlvXG4gICAqL1xuICByZWFkb25seSBzdGRpbz86IE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvO1xuXG4gIC8qKlxuICAgKiBTdHJlYW1hYmxlSFRUUCBob2xkcyBjb25maWd1cmF0aW9uIGZvciB0aGUgc3RyZWFtYWJsZV9odHRwIHRyYW5zcG9ydC5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnQjc3RyZWFtYWJsZUhUVFBcbiAgICovXG4gIHJlYWRvbmx5IHN0cmVhbWFibGVIdHRwPzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHA7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ01jcFNlcnZlclNwZWNFbmRwb2ludCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnQob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdzc2UnOiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlKG9iai5zc2UpLFxuICAgICdzdGRpbyc6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpbyhvYmouc3RkaW8pLFxuICAgICdzdHJlYW1hYmxlSFRUUCc6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cChvYmouc3RyZWFtYWJsZUh0dHApLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTWlkZGxld2FyZSBkZWZpbmVzIG9wdGlvbmFsIHdvcmtmbG93IGhvb2tzIGludm9rZWQgYXJvdW5kIGVhY2ggdG9vbCBjYWxsLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZSB7XG4gIC8qKlxuICAgKiBBZnRlckNhbGxUb29sIGhvb2tzIGFyZSBpbnZva2VkIGluIG9yZGVyIGFmdGVyIGVhY2ggQ2FsbFRvb2wuXG4gICAqIFJlY2VpdmVzIHttY3BTZXJ2ZXIsIHRvb2xOYW1lLCBhcmd1bWVudHMsIHJlc3VsdH0gYXMgaW5wdXQuXG4gICAqIEVycm9ycyBmYWlsIHRoZSB3b3JrZmxvdyDigJQgYWZ0ZXItaG9va3MgYWN0IGFzIGF1dGhvcml6YXRpb24gZ2F0ZXMuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY01pZGRsZXdhcmUjYWZ0ZXJDYWxsVG9vbFxuICAgKi9cbiAgcmVhZG9ubHkgYWZ0ZXJDYWxsVG9vbD86IE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbFtdO1xuXG4gIC8qKlxuICAgKiBBZnRlckxpc3RUb29scyBob29rcyBhcmUgaW52b2tlZCBpbiBvcmRlciBhZnRlciBlYWNoIExpc3RUb29scy5cbiAgICogUmVjZWl2ZXMge21jcFNlcnZlciwgcmVzdWx0fSBhcyBpbnB1dC5cbiAgICogRXJyb3JzIGFyZSBsb2dnZWQgYnV0IGRvIG5vdCBhZmZlY3QgdGhlIHJlc3VsdC5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZSNhZnRlckxpc3RUb29sc1xuICAgKi9cbiAgcmVhZG9ubHkgYWZ0ZXJMaXN0VG9vbHM/OiBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyTGlzdFRvb2xzW107XG5cbiAgLyoqXG4gICAqIEJlZm9yZUNhbGxUb29sIGhvb2tzIGFyZSBpbnZva2VkIGluIG9yZGVyIGJlZm9yZSBlYWNoIENhbGxUb29sLlxuICAgKiBSZWNlaXZlcyB7bWNwU2VydmVyLCB0b29sTmFtZSwgYXJndW1lbnRzfSBhcyBpbnB1dC5cbiAgICogSWYgYW55IGhvb2sgcmV0dXJucyBhbiBlcnJvciwgdGhlIGNoYWluIHN0b3BzIGFuZCB0aGUgd29ya2Zsb3cgY29tcGxldGVzXG4gICAqIHdpdGggQ2FsbFRvb2xSZXN1bHR7aXNFcnJvcjogdHJ1ZX0gc28gdGhlIGFnZW50L0xMTSBjYW4gc2VsZi1jb3JyZWN0LlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlI2JlZm9yZUNhbGxUb29sXG4gICAqL1xuICByZWFkb25seSBiZWZvcmVDYWxsVG9vbD86IE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlQ2FsbFRvb2xbXTtcblxuICAvKipcbiAgICogQmVmb3JlTGlzdFRvb2xzIGhvb2tzIGFyZSBpbnZva2VkIGluIG9yZGVyIGJlZm9yZSBlYWNoIExpc3RUb29scy5cbiAgICogUmVjZWl2ZXMge21jcFNlcnZlcn0gYXMgaW5wdXQuXG4gICAqIElmIGFueSBob29rIHJldHVybnMgYW4gZXJyb3IsIHRoZSBjaGFpbiBzdG9wcyBhbmQgdGhlIGVycm9yIGlzIHJldHVybmVkLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlI2JlZm9yZUxpc3RUb29sc1xuICAgKi9cbiAgcmVhZG9ubHkgYmVmb3JlTGlzdFRvb2xzPzogTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVMaXN0VG9vbHNbXTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY01pZGRsZXdhcmUnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY01pZGRsZXdhcmUob2JqOiBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZSB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FmdGVyQ2FsbFRvb2wnOiBvYmouYWZ0ZXJDYWxsVG9vbD8ubWFwKHkgPT4gdG9Kc29uX01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbCh5KSksXG4gICAgJ2FmdGVyTGlzdFRvb2xzJzogb2JqLmFmdGVyTGlzdFRvb2xzPy5tYXAoeSA9PiB0b0pzb25fTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckxpc3RUb29scyh5KSksXG4gICAgJ2JlZm9yZUNhbGxUb29sJzogb2JqLmJlZm9yZUNhbGxUb29sPy5tYXAoeSA9PiB0b0pzb25fTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVDYWxsVG9vbCh5KSksXG4gICAgJ2JlZm9yZUxpc3RUb29scyc6IG9iai5iZWZvcmVMaXN0VG9vbHM/Lm1hcCh5ID0+IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUxpc3RUb29scyh5KSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBNQ1BDYXRhbG9nT3duZXIgaWRlbnRpZmllcyB0aGUgdGVhbSByZXNwb25zaWJsZSBmb3IgdGhlIE1DUCBzZXJ2ZXIuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjQ2F0YWxvZ093bmVyXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0NhdGFsb2dPd25lciB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNDYXRhbG9nT3duZXIjY29udGFjdFxuICAgKi9cbiAgcmVhZG9ubHkgY29udGFjdD86IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjQ2F0YWxvZ093bmVyI3RlYW1cbiAgICovXG4gIHJlYWRvbmx5IHRlYW0/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ01jcFNlcnZlclNwZWNDYXRhbG9nT3duZXInIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY0NhdGFsb2dPd25lcihvYmo6IE1jcFNlcnZlclNwZWNDYXRhbG9nT3duZXIgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdjb250YWN0Jzogb2JqLmNvbnRhY3QsXG4gICAgJ3RlYW0nOiBvYmoudGVhbSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNTRSBob2xkcyBjb25maWd1cmF0aW9uIGZvciB0aGUgbGVnYWN5IFNTRSB0cmFuc3BvcnQuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2Uge1xuICAvKipcbiAgICogQXV0aCBjb25maWd1cmVzIGF1dGhlbnRpY2F0aW9uIGZvciB0aGUgTUNQIHNlcnZlciBjb25uZWN0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZSNhdXRoXG4gICAqL1xuICByZWFkb25seSBhdXRoPzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aDtcblxuICAvKipcbiAgICogSGVhZGVycyBhcmUgaW5qZWN0ZWQgb24gYWxsIG91dGJvdW5kIEhUVFAgcmVxdWVzdHMgdG8gdGhlIE1DUCBzZXJ2ZXIuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlI2hlYWRlcnNcbiAgICovXG4gIHJlYWRvbmx5IGhlYWRlcnM/OiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VIZWFkZXJzW107XG5cbiAgLyoqXG4gICAqIFByb3RvY29sVmVyc2lvbiBwaW5zIHRoZSBNQ1Agc3BlYyB2ZXJzaW9uIHRoZSBzZXJ2ZXIgaW1wbGVtZW50cyxcbiAgICogdXNpbmcgdGhlIGRhdGUtYmFzZWQgZm9ybWF0IGRlZmluZWQgYnkgdGhlIE1DUCBzcGVjaWZpY2F0aW9uIChlLmcuIFwiMjAyNS0wNi0xOFwiKS5cbiAgICogV2hlbiB1bnNldCwgdGhlIGdvLXNkayBuZWdvdGlhdGVzIHRoZSBsYXRlc3QgdmVyc2lvbiBzdXBwb3J0ZWQgYnkgYm90aCBzaWRlcy5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2UjcHJvdG9jb2xWZXJzaW9uXG4gICAqL1xuICByZWFkb25seSBwcm90b2NvbFZlcnNpb24/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRpbWVvdXQgaXMgdGhlIHBlci1jYWxsIGRlYWRsaW5lIGZvciBNQ1AgcmVxdWVzdHMuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlI3RpbWVvdXRcbiAgICovXG4gIHJlYWRvbmx5IHRpbWVvdXQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFVSTCBpcyB0aGUgZW5kcG9pbnQgVVJMIG9mIHRoZSBNQ1Agc2VydmVyLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZSN1cmxcbiAgICovXG4gIHJlYWRvbmx5IHVybDogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2UnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlKG9iajogTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXV0aCc6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoKG9iai5hdXRoKSxcbiAgICAnaGVhZGVycyc6IG9iai5oZWFkZXJzPy5tYXAoeSA9PiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlSGVhZGVycyh5KSksXG4gICAgJ3Byb3RvY29sVmVyc2lvbic6IG9iai5wcm90b2NvbFZlcnNpb24sXG4gICAgJ3RpbWVvdXQnOiBvYmoudGltZW91dCxcbiAgICAndXJsJzogb2JqLnVybCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFN0ZGlvIGhvbGRzIGNvbmZpZ3VyYXRpb24gZm9yIHRoZSBzdGRpbyBzdWJwcm9jZXNzIHRyYW5zcG9ydC5cbiAqXG4gKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW8ge1xuICAvKipcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpbyNhcmdzXG4gICAqL1xuICByZWFkb25seSBhcmdzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIENvbW1hbmQgaXMgdGhlIGV4ZWN1dGFibGUgdG8gcnVuLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvI2NvbW1hbmRcbiAgICovXG4gIHJlYWRvbmx5IGNvbW1hbmQ6IHN0cmluZztcblxuICAvKipcbiAgICogRW52IGFyZSBlbnZpcm9ubWVudCB2YXJpYWJsZXMgaW5qZWN0ZWQgaW50byB0aGUgc3VicHJvY2Vzcy5cbiAgICogU3VwcG9ydHMgcGxhaW4gdmFsdWUsIHNlY3JldEtleVJlZiwgYW5kIGVudlJlZi5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpbyNlbnZcbiAgICovXG4gIHJlYWRvbmx5IGVudj86IE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvRW52W107XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ01jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvKG9iajogTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW8gfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhcmdzJzogb2JqLmFyZ3M/Lm1hcCh5ID0+IHkpLFxuICAgICdjb21tYW5kJzogb2JqLmNvbW1hbmQsXG4gICAgJ2Vudic6IG9iai5lbnY/Lm1hcCh5ID0+IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpb0Vudih5KSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTdHJlYW1hYmxlSFRUUCBob2xkcyBjb25maWd1cmF0aW9uIGZvciB0aGUgc3RyZWFtYWJsZV9odHRwIHRyYW5zcG9ydC5cbiAqXG4gKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHAge1xuICAvKipcbiAgICogQXV0aCBjb25maWd1cmVzIGF1dGhlbnRpY2F0aW9uIGZvciB0aGUgTUNQIHNlcnZlciBjb25uZWN0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwI2F1dGhcbiAgICovXG4gIHJlYWRvbmx5IGF1dGg/OiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGg7XG5cbiAgLyoqXG4gICAqIEhlYWRlcnMgYXJlIGluamVjdGVkIG9uIGFsbCBvdXRib3VuZCBIVFRQIHJlcXVlc3RzIHRvIHRoZSBNQ1Agc2VydmVyLlxuICAgKiBFYWNoIGVudHJ5IGZvbGxvd3MgdGhlIHNhbWUgTmFtZVZhbHVlUGFpciBjb250cmFjdCB1c2VkIGJ5IEhUVFBFbmRwb2ludDpcbiAgICogcGxhaW4gdmFsdWUsIHNlY3JldEtleVJlZiwgb3IgZW52UmVmLiBTZWNyZXQgcmVzb2x1dGlvbiB1c2VzIGF1dGguc2VjcmV0U3RvcmUuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHAjaGVhZGVyc1xuICAgKi9cbiAgcmVhZG9ubHkgaGVhZGVycz86IE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwSGVhZGVyc1tdO1xuXG4gIC8qKlxuICAgKiBQcm90b2NvbFZlcnNpb24gcGlucyB0aGUgTUNQIHNwZWMgdmVyc2lvbiB0aGUgc2VydmVyIGltcGxlbWVudHMsXG4gICAqIHVzaW5nIHRoZSBkYXRlLWJhc2VkIGZvcm1hdCBkZWZpbmVkIGJ5IHRoZSBNQ1Agc3BlY2lmaWNhdGlvbiAoZS5nLiBcIjIwMjUtMDYtMThcIikuXG4gICAqIFdoZW4gdW5zZXQsIHRoZSBnby1zZGsgbmVnb3RpYXRlcyB0aGUgbGF0ZXN0IHZlcnNpb24gc3VwcG9ydGVkIGJ5IGJvdGggc2lkZXMuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHAjcHJvdG9jb2xWZXJzaW9uXG4gICAqL1xuICByZWFkb25seSBwcm90b2NvbFZlcnNpb24/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRpbWVvdXQgaXMgdGhlIHBlci1jYWxsIGRlYWRsaW5lIGZvciBNQ1AgcmVxdWVzdHMuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHAjdGltZW91dFxuICAgKi9cbiAgcmVhZG9ubHkgdGltZW91dD86IHN0cmluZztcblxuICAvKipcbiAgICogVVJMIGlzIHRoZSBlbmRwb2ludCBVUkwgb2YgdGhlIE1DUCBzZXJ2ZXIuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHAjdXJsXG4gICAqL1xuICByZWFkb25seSB1cmw6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHAnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHAob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1dGgnOiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoKG9iai5hdXRoKSxcbiAgICAnaGVhZGVycyc6IG9iai5oZWFkZXJzPy5tYXAoeSA9PiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBIZWFkZXJzKHkpKSxcbiAgICAncHJvdG9jb2xWZXJzaW9uJzogb2JqLnByb3RvY29sVmVyc2lvbixcbiAgICAndGltZW91dCc6IG9iai50aW1lb3V0LFxuICAgICd1cmwnOiBvYmoudXJsLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTXV0YXRpbmdNQ1BNaWRkbGV3YXJlSG9vayBleHRlbmRzIE1DUE1pZGRsZXdhcmVIb29rIHdpdGggdGhlIGFiaWxpdHkgdG9cbiAqIHJlcGxhY2UgdGhlIGRhdGEgZmxvd2luZyB0aHJvdWdoIHRoZSBwaXBlbGluZSB3aGVuIE11dGF0ZSBpcyB0cnVlLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckNhbGxUb29sXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckNhbGxUb29sIHtcbiAgLyoqXG4gICAqIE11dGF0ZSwgd2hlbiB0cnVlLCBjYXVzZXMgdGhlIGhvb2sncyByZXR1cm4gdmFsdWUgdG8gcmVwbGFjZSB0aGUgZGF0YVxuICAgKiBmbG93aW5nIHRocm91Z2ggdGhlIHBpcGVsaW5lOlxuICAgKiAtIGJlZm9yZUNhbGxUb29sOiByZXBsYWNlcyB0aGUgYXJndW1lbnRzIHNlbnQgdG8gdGhlIHRvb2wgY2FsbFxuICAgKiAoZS5nLiByZWRhY3QgUElJLCBpbmplY3QgZGVmYXVsdHMpLlxuICAgKiAtIGFmdGVyQ2FsbFRvb2wgLyBhZnRlckxpc3RUb29sczogcmVwbGFjZXMgdGhlIHJlc3VsdCByZXR1cm5lZCB0byB0aGUgY2FsbGVyLlxuICAgKiBXaGVuIGZhbHNlIChkZWZhdWx0KSwgdGhlIGhvb2sgdmFsaWRhdGVzL29ic2VydmVzIG9ubHkg4oCUIGl0cyBvdXRwdXQgaXMgZGlzY2FyZGVkLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbCNtdXRhdGVcbiAgICovXG4gIHJlYWRvbmx5IG11dGF0ZT86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFdvcmtmbG93IGlzIHRoZSBEYXByIHdvcmtmbG93IHRvIGludm9rZSBhcyB0aGUgaG9vay5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyQ2FsbFRvb2wjd29ya2Zsb3dcbiAgICovXG4gIHJlYWRvbmx5IHdvcmtmbG93OiBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyQ2FsbFRvb2xXb3JrZmxvdztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckNhbGxUb29sJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbChvYmo6IE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ211dGF0ZSc6IG9iai5tdXRhdGUsXG4gICAgJ3dvcmtmbG93JzogdG9Kc29uX01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbFdvcmtmbG93KG9iai53b3JrZmxvdyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBNdXRhdGluZ01DUE1pZGRsZXdhcmVIb29rIGV4dGVuZHMgTUNQTWlkZGxld2FyZUhvb2sgd2l0aCB0aGUgYWJpbGl0eSB0b1xuICogcmVwbGFjZSB0aGUgZGF0YSBmbG93aW5nIHRocm91Z2ggdGhlIHBpcGVsaW5lIHdoZW4gTXV0YXRlIGlzIHRydWUuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyTGlzdFRvb2xzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckxpc3RUb29scyB7XG4gIC8qKlxuICAgKiBNdXRhdGUsIHdoZW4gdHJ1ZSwgY2F1c2VzIHRoZSBob29rJ3MgcmV0dXJuIHZhbHVlIHRvIHJlcGxhY2UgdGhlIGRhdGFcbiAgICogZmxvd2luZyB0aHJvdWdoIHRoZSBwaXBlbGluZTpcbiAgICogLSBiZWZvcmVDYWxsVG9vbDogcmVwbGFjZXMgdGhlIGFyZ3VtZW50cyBzZW50IHRvIHRoZSB0b29sIGNhbGxcbiAgICogKGUuZy4gcmVkYWN0IFBJSSwgaW5qZWN0IGRlZmF1bHRzKS5cbiAgICogLSBhZnRlckNhbGxUb29sIC8gYWZ0ZXJMaXN0VG9vbHM6IHJlcGxhY2VzIHRoZSByZXN1bHQgcmV0dXJuZWQgdG8gdGhlIGNhbGxlci5cbiAgICogV2hlbiBmYWxzZSAoZGVmYXVsdCksIHRoZSBob29rIHZhbGlkYXRlcy9vYnNlcnZlcyBvbmx5IOKAlCBpdHMgb3V0cHV0IGlzIGRpc2NhcmRlZC5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyTGlzdFRvb2xzI211dGF0ZVxuICAgKi9cbiAgcmVhZG9ubHkgbXV0YXRlPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogV29ya2Zsb3cgaXMgdGhlIERhcHIgd29ya2Zsb3cgdG8gaW52b2tlIGFzIHRoZSBob29rLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJMaXN0VG9vbHMjd29ya2Zsb3dcbiAgICovXG4gIHJlYWRvbmx5IHdvcmtmbG93OiBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyTGlzdFRvb2xzV29ya2Zsb3c7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJMaXN0VG9vbHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckxpc3RUb29scyhvYmo6IE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJMaXN0VG9vbHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtdXRhdGUnOiBvYmoubXV0YXRlLFxuICAgICd3b3JrZmxvdyc6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyTGlzdFRvb2xzV29ya2Zsb3cob2JqLndvcmtmbG93KSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE11dGF0aW5nTUNQTWlkZGxld2FyZUhvb2sgZXh0ZW5kcyBNQ1BNaWRkbGV3YXJlSG9vayB3aXRoIHRoZSBhYmlsaXR5IHRvXG4gKiByZXBsYWNlIHRoZSBkYXRhIGZsb3dpbmcgdGhyb3VnaCB0aGUgcGlwZWxpbmUgd2hlbiBNdXRhdGUgaXMgdHJ1ZS5cbiAqXG4gKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlQ2FsbFRvb2xcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUNhbGxUb29sIHtcbiAgLyoqXG4gICAqIE11dGF0ZSwgd2hlbiB0cnVlLCBjYXVzZXMgdGhlIGhvb2sncyByZXR1cm4gdmFsdWUgdG8gcmVwbGFjZSB0aGUgZGF0YVxuICAgKiBmbG93aW5nIHRocm91Z2ggdGhlIHBpcGVsaW5lOlxuICAgKiAtIGJlZm9yZUNhbGxUb29sOiByZXBsYWNlcyB0aGUgYXJndW1lbnRzIHNlbnQgdG8gdGhlIHRvb2wgY2FsbFxuICAgKiAoZS5nLiByZWRhY3QgUElJLCBpbmplY3QgZGVmYXVsdHMpLlxuICAgKiAtIGFmdGVyQ2FsbFRvb2wgLyBhZnRlckxpc3RUb29sczogcmVwbGFjZXMgdGhlIHJlc3VsdCByZXR1cm5lZCB0byB0aGUgY2FsbGVyLlxuICAgKiBXaGVuIGZhbHNlIChkZWZhdWx0KSwgdGhlIGhvb2sgdmFsaWRhdGVzL29ic2VydmVzIG9ubHkg4oCUIGl0cyBvdXRwdXQgaXMgZGlzY2FyZGVkLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlQ2FsbFRvb2wjbXV0YXRlXG4gICAqL1xuICByZWFkb25seSBtdXRhdGU/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBXb3JrZmxvdyBpcyB0aGUgRGFwciB3b3JrZmxvdyB0byBpbnZva2UgYXMgdGhlIGhvb2suXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVDYWxsVG9vbCN3b3JrZmxvd1xuICAgKi9cbiAgcmVhZG9ubHkgd29ya2Zsb3c6IE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlQ2FsbFRvb2xXb3JrZmxvdztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVDYWxsVG9vbCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9NY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUNhbGxUb29sKG9iajogTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVDYWxsVG9vbCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ211dGF0ZSc6IG9iai5tdXRhdGUsXG4gICAgJ3dvcmtmbG93JzogdG9Kc29uX01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlQ2FsbFRvb2xXb3JrZmxvdyhvYmoud29ya2Zsb3cpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTUNQTWlkZGxld2FyZUhvb2sgaXMgYSBzaW5nbGUgbWlkZGxld2FyZSBob29rLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVMaXN0VG9vbHNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUxpc3RUb29scyB7XG4gIC8qKlxuICAgKiBXb3JrZmxvdyBpcyB0aGUgRGFwciB3b3JrZmxvdyB0byBpbnZva2UgYXMgdGhlIGhvb2suXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVMaXN0VG9vbHMjd29ya2Zsb3dcbiAgICovXG4gIHJlYWRvbmx5IHdvcmtmbG93OiBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUxpc3RUb29sc1dvcmtmbG93O1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUxpc3RUb29scycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9NY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUxpc3RUb29scyhvYmo6IE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlTGlzdFRvb2xzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnd29ya2Zsb3cnOiB0b0pzb25fTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVMaXN0VG9vbHNXb3JrZmxvdyhvYmoud29ya2Zsb3cpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogQXV0aCBjb25maWd1cmVzIGF1dGhlbnRpY2F0aW9uIGZvciB0aGUgTUNQIHNlcnZlciBjb25uZWN0aW9uLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGgge1xuICAvKipcbiAgICogT0F1dGgyIGNvbmZpZ3VyZXMgT0F1dGgyIGNsaWVudCBjcmVkZW50aWFscyBmbG93IGZvciB0aGUgTUNQIHNlcnZlci5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoI29hdXRoMlxuICAgKi9cbiAgcmVhZG9ubHkgb2F1dGgyPzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aE9hdXRoMjtcblxuICAvKipcbiAgICogU2VjcmV0U3RvcmUgbmFtZXMgdGhlIERhcHIgc2VjcmV0IHN0b3JlIHVzZWQgdG8gcmVzb2x2ZSBzZWNyZXRLZXlSZWYgZW50cmllc1xuICAgKiBpbiBzcGVjLmVuZHBvaW50Lmh0dHAuaGVhZGVycy4gYXV0aC5vYXV0aDIuc2VjcmV0S2V5UmVmIGlzIHJlc29sdmVkIHNlcGFyYXRlbHlcbiAgICogYXQgY2FsbCB0aW1lIGJ5IHRoZSBNQ1Agd29ya2VyLiBEZWZhdWx0cyB0byBcImt1YmVybmV0ZXNcIi5cbiAgICpcbiAgICogQGRlZmF1bHQga3ViZXJuZXRlc1wiLlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGgjc2VjcmV0U3RvcmVcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldFN0b3JlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTUElGRkUgY29uZmlndXJlcyB3b3JrbG9hZCBpZGVudGl0eSBKV1QgaW5qZWN0aW9uIHZpYSBEYXByJ3MgU2VudHJ5IENBLlxuICAgKiBObyBzZWNyZXQgaXMgcmVxdWlyZWQ7IFNlbnRyeSBpc3N1ZXMgdGhlIFNWSUQgYXV0b21hdGljYWxseS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoI3NwaWZmZVxuICAgKi9cbiAgcmVhZG9ubHkgc3BpZmZlPzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aFNwaWZmZTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoKG9iajogTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ29hdXRoMic6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyKG9iai5vYXV0aDIpLFxuICAgICdzZWNyZXRTdG9yZSc6IG9iai5zZWNyZXRTdG9yZSxcbiAgICAnc3BpZmZlJzogdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhTcGlmZmUob2JqLnNwaWZmZSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBOYW1lVmFsdWVQYWlyIGlzIGEgbmFtZS92YWx1ZSBwYWlyLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlSGVhZGVyc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUhlYWRlcnMge1xuICAvKipcbiAgICogRW52UmVmIGlzIHRoZSBuYW1lIG9mIGFuIGVudmlyb25tZW50YWwgdmFyaWFibGUgdG8gcmVhZCB0aGUgdmFsdWUgZnJvbS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VIZWFkZXJzI2VudlJlZlxuICAgKi9cbiAgcmVhZG9ubHkgZW52UmVmPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOYW1lIG9mIHRoZSBwcm9wZXJ0eS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VIZWFkZXJzI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlSGVhZGVycyNzZWNyZXRLZXlSZWZcbiAgICovXG4gIHJlYWRvbmx5IHNlY3JldEtleVJlZj86IE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUhlYWRlcnNTZWNyZXRLZXlSZWY7XG5cbiAgLyoqXG4gICAqIFZhbHVlIG9mIHRoZSBwcm9wZXJ0eSwgaW4gcGxhaW50ZXh0LlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUhlYWRlcnMjdmFsdWVcbiAgICovXG4gIHJlYWRvbmx5IHZhbHVlPzogYW55O1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VIZWFkZXJzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFNzZUhlYWRlcnMob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VIZWFkZXJzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZW52UmVmJzogb2JqLmVudlJlZixcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICdzZWNyZXRLZXlSZWYnOiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlSGVhZGVyc1NlY3JldEtleVJlZihvYmouc2VjcmV0S2V5UmVmKSxcbiAgICAndmFsdWUnOiBvYmoudmFsdWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBOYW1lVmFsdWVQYWlyIGlzIGEgbmFtZS92YWx1ZSBwYWlyLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW9FbnZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpb0VudiB7XG4gIC8qKlxuICAgKiBFbnZSZWYgaXMgdGhlIG5hbWUgb2YgYW4gZW52aXJvbm1lbnRhbCB2YXJpYWJsZSB0byByZWFkIHRoZSB2YWx1ZSBmcm9tLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvRW52I2VudlJlZlxuICAgKi9cbiAgcmVhZG9ubHkgZW52UmVmPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBOYW1lIG9mIHRoZSBwcm9wZXJ0eS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpb0VudiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldEtleVJlZiBpcyB0aGUgcmVmZXJlbmNlIG9mIGEgdmFsdWUgaW4gYSBzZWNyZXQgc3RvcmUgY29tcG9uZW50LlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvRW52I3NlY3JldEtleVJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0S2V5UmVmPzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW9FbnZTZWNyZXRLZXlSZWY7XG5cbiAgLyoqXG4gICAqIFZhbHVlIG9mIHRoZSBwcm9wZXJ0eSwgaW4gcGxhaW50ZXh0LlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvRW52I3ZhbHVlXG4gICAqL1xuICByZWFkb25seSB2YWx1ZT86IGFueTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW9FbnYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW9FbnYob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpb0VudiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2VudlJlZic6IG9iai5lbnZSZWYsXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgICAnc2VjcmV0S2V5UmVmJzogdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvRW52U2VjcmV0S2V5UmVmKG9iai5zZWNyZXRLZXlSZWYpLFxuICAgICd2YWx1ZSc6IG9iai52YWx1ZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEF1dGggY29uZmlndXJlcyBhdXRoZW50aWNhdGlvbiBmb3IgdGhlIE1DUCBzZXJ2ZXIgY29ubmVjdGlvbi5cbiAqXG4gKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aFxuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aCB7XG4gIC8qKlxuICAgKiBPQXV0aDIgY29uZmlndXJlcyBPQXV0aDIgY2xpZW50IGNyZWRlbnRpYWxzIGZsb3cgZm9yIHRoZSBNQ1Agc2VydmVyLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aCNvYXV0aDJcbiAgICovXG4gIHJlYWRvbmx5IG9hdXRoMj86IE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aE9hdXRoMjtcblxuICAvKipcbiAgICogU2VjcmV0U3RvcmUgbmFtZXMgdGhlIERhcHIgc2VjcmV0IHN0b3JlIHVzZWQgdG8gcmVzb2x2ZSBzZWNyZXRLZXlSZWYgZW50cmllc1xuICAgKiBpbiBzcGVjLmVuZHBvaW50Lmh0dHAuaGVhZGVycy4gYXV0aC5vYXV0aDIuc2VjcmV0S2V5UmVmIGlzIHJlc29sdmVkIHNlcGFyYXRlbHlcbiAgICogYXQgY2FsbCB0aW1lIGJ5IHRoZSBNQ1Agd29ya2VyLiBEZWZhdWx0cyB0byBcImt1YmVybmV0ZXNcIi5cbiAgICpcbiAgICogQGRlZmF1bHQga3ViZXJuZXRlc1wiLlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aCNzZWNyZXRTdG9yZVxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0U3RvcmU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNQSUZGRSBjb25maWd1cmVzIHdvcmtsb2FkIGlkZW50aXR5IEpXVCBpbmplY3Rpb24gdmlhIERhcHIncyBTZW50cnkgQ0EuXG4gICAqIE5vIHNlY3JldCBpcyByZXF1aXJlZDsgU2VudHJ5IGlzc3VlcyB0aGUgU1ZJRCBhdXRvbWF0aWNhbGx5LlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aCNzcGlmZmVcbiAgICovXG4gIHJlYWRvbmx5IHNwaWZmZT86IE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aFNwaWZmZTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aChvYmo6IE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ29hdXRoMic6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhPYXV0aDIob2JqLm9hdXRoMiksXG4gICAgJ3NlY3JldFN0b3JlJzogb2JqLnNlY3JldFN0b3JlLFxuICAgICdzcGlmZmUnOiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoU3BpZmZlKG9iai5zcGlmZmUpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogTmFtZVZhbHVlUGFpciBpcyBhIG5hbWUvdmFsdWUgcGFpci5cbiAqXG4gKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwSGVhZGVyc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwSGVhZGVycyB7XG4gIC8qKlxuICAgKiBFbnZSZWYgaXMgdGhlIG5hbWUgb2YgYW4gZW52aXJvbm1lbnRhbCB2YXJpYWJsZSB0byByZWFkIHRoZSB2YWx1ZSBmcm9tLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwSGVhZGVycyNlbnZSZWZcbiAgICovXG4gIHJlYWRvbmx5IGVudlJlZj86IHN0cmluZztcblxuICAvKipcbiAgICogTmFtZSBvZiB0aGUgcHJvcGVydHkuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBIZWFkZXJzI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBIZWFkZXJzI3NlY3JldEtleVJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0S2V5UmVmPzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBIZWFkZXJzU2VjcmV0S2V5UmVmO1xuXG4gIC8qKlxuICAgKiBWYWx1ZSBvZiB0aGUgcHJvcGVydHksIGluIHBsYWludGV4dC5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEhlYWRlcnMjdmFsdWVcbiAgICovXG4gIHJlYWRvbmx5IHZhbHVlPzogYW55O1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEhlYWRlcnMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBIZWFkZXJzKG9iajogTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBIZWFkZXJzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZW52UmVmJzogb2JqLmVudlJlZixcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICdzZWNyZXRLZXlSZWYnOiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBIZWFkZXJzU2VjcmV0S2V5UmVmKG9iai5zZWNyZXRLZXlSZWYpLFxuICAgICd2YWx1ZSc6IG9iai52YWx1ZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFdvcmtmbG93IGlzIHRoZSBEYXByIHdvcmtmbG93IHRvIGludm9rZSBhcyB0aGUgaG9vay5cbiAqXG4gKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbFdvcmtmbG93XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckNhbGxUb29sV29ya2Zsb3cge1xuICAvKipcbiAgICogQXBwSUQgdGFyZ2V0cyB0aGUgd29ya2Zsb3cgb24gYSByZW1vdGUgRGFwciBhcHAgdmlhIHNlcnZpY2UgaW52b2NhdGlvbi5cbiAgICogV2hlbiB1bnNldCwgdGhlIHdvcmtmbG93IGlzIGludm9rZWQgbG9jYWxseS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyQ2FsbFRvb2xXb3JrZmxvdyNhcHBJRFxuICAgKi9cbiAgcmVhZG9ubHkgYXBwSWQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFdvcmtmbG93TmFtZSBpcyB0aGUgbmFtZSBvZiB0aGUgd29ya2Zsb3cgdG8gaW52b2tlLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbFdvcmtmbG93I3dvcmtmbG93TmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgd29ya2Zsb3dOYW1lOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbFdvcmtmbG93JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJDYWxsVG9vbFdvcmtmbG93KG9iajogTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckNhbGxUb29sV29ya2Zsb3cgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhcHBJRCc6IG9iai5hcHBJZCxcbiAgICAnd29ya2Zsb3dOYW1lJzogb2JqLndvcmtmbG93TmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFdvcmtmbG93IGlzIHRoZSBEYXByIHdvcmtmbG93IHRvIGludm9rZSBhcyB0aGUgaG9vay5cbiAqXG4gKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJMaXN0VG9vbHNXb3JrZmxvd1xuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJMaXN0VG9vbHNXb3JrZmxvdyB7XG4gIC8qKlxuICAgKiBBcHBJRCB0YXJnZXRzIHRoZSB3b3JrZmxvdyBvbiBhIHJlbW90ZSBEYXByIGFwcCB2aWEgc2VydmljZSBpbnZvY2F0aW9uLlxuICAgKiBXaGVuIHVuc2V0LCB0aGUgd29ya2Zsb3cgaXMgaW52b2tlZCBsb2NhbGx5LlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJMaXN0VG9vbHNXb3JrZmxvdyNhcHBJRFxuICAgKi9cbiAgcmVhZG9ubHkgYXBwSWQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFdvcmtmbG93TmFtZSBpcyB0aGUgbmFtZSBvZiB0aGUgd29ya2Zsb3cgdG8gaW52b2tlLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQWZ0ZXJMaXN0VG9vbHNXb3JrZmxvdyN3b3JrZmxvd05hbWVcbiAgICovXG4gIHJlYWRvbmx5IHdvcmtmbG93TmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUFmdGVyTGlzdFRvb2xzV29ya2Zsb3cnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckxpc3RUb29sc1dvcmtmbG93KG9iajogTWNwU2VydmVyU3BlY01pZGRsZXdhcmVBZnRlckxpc3RUb29sc1dvcmtmbG93IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXBwSUQnOiBvYmouYXBwSWQsXG4gICAgJ3dvcmtmbG93TmFtZSc6IG9iai53b3JrZmxvd05hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBXb3JrZmxvdyBpcyB0aGUgRGFwciB3b3JrZmxvdyB0byBpbnZva2UgYXMgdGhlIGhvb2suXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUNhbGxUb29sV29ya2Zsb3dcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUNhbGxUb29sV29ya2Zsb3cge1xuICAvKipcbiAgICogQXBwSUQgdGFyZ2V0cyB0aGUgd29ya2Zsb3cgb24gYSByZW1vdGUgRGFwciBhcHAgdmlhIHNlcnZpY2UgaW52b2NhdGlvbi5cbiAgICogV2hlbiB1bnNldCwgdGhlIHdvcmtmbG93IGlzIGludm9rZWQgbG9jYWxseS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUNhbGxUb29sV29ya2Zsb3cjYXBwSURcbiAgICovXG4gIHJlYWRvbmx5IGFwcElkPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBXb3JrZmxvd05hbWUgaXMgdGhlIG5hbWUgb2YgdGhlIHdvcmtmbG93IHRvIGludm9rZS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUNhbGxUb29sV29ya2Zsb3cjd29ya2Zsb3dOYW1lXG4gICAqL1xuICByZWFkb25seSB3b3JrZmxvd05hbWU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVDYWxsVG9vbFdvcmtmbG93JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlQ2FsbFRvb2xXb3JrZmxvdyhvYmo6IE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlQ2FsbFRvb2xXb3JrZmxvdyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2FwcElEJzogb2JqLmFwcElkLFxuICAgICd3b3JrZmxvd05hbWUnOiBvYmoud29ya2Zsb3dOYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogV29ya2Zsb3cgaXMgdGhlIERhcHIgd29ya2Zsb3cgdG8gaW52b2tlIGFzIHRoZSBob29rLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVMaXN0VG9vbHNXb3JrZmxvd1xuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlTGlzdFRvb2xzV29ya2Zsb3cge1xuICAvKipcbiAgICogQXBwSUQgdGFyZ2V0cyB0aGUgd29ya2Zsb3cgb24gYSByZW1vdGUgRGFwciBhcHAgdmlhIHNlcnZpY2UgaW52b2NhdGlvbi5cbiAgICogV2hlbiB1bnNldCwgdGhlIHdvcmtmbG93IGlzIGludm9rZWQgbG9jYWxseS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUxpc3RUb29sc1dvcmtmbG93I2FwcElEXG4gICAqL1xuICByZWFkb25seSBhcHBJZD86IHN0cmluZztcblxuICAvKipcbiAgICogV29ya2Zsb3dOYW1lIGlzIHRoZSBuYW1lIG9mIHRoZSB3b3JrZmxvdyB0byBpbnZva2UuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY01pZGRsZXdhcmVCZWZvcmVMaXN0VG9vbHNXb3JrZmxvdyN3b3JrZmxvd05hbWVcbiAgICovXG4gIHJlYWRvbmx5IHdvcmtmbG93TmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUxpc3RUb29sc1dvcmtmbG93JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNNaWRkbGV3YXJlQmVmb3JlTGlzdFRvb2xzV29ya2Zsb3cob2JqOiBNY3BTZXJ2ZXJTcGVjTWlkZGxld2FyZUJlZm9yZUxpc3RUb29sc1dvcmtmbG93IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXBwSUQnOiBvYmouYXBwSWQsXG4gICAgJ3dvcmtmbG93TmFtZSc6IG9iai53b3JrZmxvd05hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBPQXV0aDIgY29uZmlndXJlcyBPQXV0aDIgY2xpZW50IGNyZWRlbnRpYWxzIGZsb3cgZm9yIHRoZSBNQ1Agc2VydmVyLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aE9hdXRoMlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhPYXV0aDIge1xuICAvKipcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyI2F1ZGllbmNlXG4gICAqL1xuICByZWFkb25seSBhdWRpZW5jZT86IHN0cmluZztcblxuICAvKipcbiAgICogQ2xpZW50SUQgaXMgdGhlIE9BdXRoMiBjbGllbnQgaWRlbnRpZmllciBzZW50IHRvIHRoZSB0b2tlbiBlbmRwb2ludC5cbiAgICogUmVxdWlyZWQgYnkgUkZDIDY3NDkgZm9yIHRoZSBzdGFuZGFyZCBjbGllbnRfY3JlZGVudGlhbHMgZmxvdyAoZm9ybSBwYXJhbWV0ZXJcbiAgICogb3IgSFRUUCBCYXNpYyB1c2VybmFtZSkuIE1heSBiZSBsZWZ0IGVtcHR5IGZvciBub24tc3RhbmRhcmQgZmxvd3MgKGUuZy4gSldULWJlYXJlclxuICAgKiBhc3NlcnRpb25zIG9yIHRva2VuIGVuZHBvaW50cyB0aGF0IGtleSBzb2xlbHkgb24gdGhlIGNsaWVudF9zZWNyZXQpLiBDbGllbnQgSURzXG4gICAqIGFyZSB0eXBpY2FsbHkgcHVibGljIGlkZW50aWZpZXJzOyB1c2Ugc3BlYy5oZWFkZXJzIHdpdGggYSBzZWNyZXRLZXlSZWYgaWYgeW91clxuICAgKiBlbnZpcm9ubWVudCByZXF1aXJlcyBzb3VyY2luZyB0aGUgdmFsdWUgZnJvbSBhIHNlY3JldCBzdG9yZS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyI2NsaWVudElEXG4gICAqL1xuICByZWFkb25seSBjbGllbnRJZD86IHN0cmluZztcblxuICAvKipcbiAgICogSXNzdWVyIGlzIHRoZSB0b2tlbiBlbmRwb2ludCBvZiB0aGUgYXV0aG9yaXphdGlvbiBzZXJ2ZXIuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aE9hdXRoMiNpc3N1ZXJcbiAgICovXG4gIHJlYWRvbmx5IGlzc3Vlcjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhPYXV0aDIjc2NvcGVzXG4gICAqL1xuICByZWFkb25seSBzY29wZXM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogU2VjcmV0S2V5UmVmIHJlZmVyZW5jZXMgdGhlIGNsaWVudCBzZWNyZXQgaW4gdGhlIGNvbmZpZ3VyZWQgc2VjcmV0IHN0b3JlLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhPYXV0aDIjc2VjcmV0S2V5UmVmXG4gICAqL1xuICByZWFkb25seSBzZWNyZXRLZXlSZWY/OiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyU2VjcmV0S2V5UmVmO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhPYXV0aDIob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2UnOiBvYmouYXVkaWVuY2UsXG4gICAgJ2NsaWVudElEJzogb2JqLmNsaWVudElkLFxuICAgICdpc3N1ZXInOiBvYmouaXNzdWVyLFxuICAgICdzY29wZXMnOiBvYmouc2NvcGVzPy5tYXAoeSA9PiB5KSxcbiAgICAnc2VjcmV0S2V5UmVmJzogdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhPYXV0aDJTZWNyZXRLZXlSZWYob2JqLnNlY3JldEtleVJlZiksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTUElGRkUgY29uZmlndXJlcyB3b3JrbG9hZCBpZGVudGl0eSBKV1QgaW5qZWN0aW9uIHZpYSBEYXByJ3MgU2VudHJ5IENBLlxuICogTm8gc2VjcmV0IGlzIHJlcXVpcmVkOyBTZW50cnkgaXNzdWVzIHRoZSBTVklEIGF1dG9tYXRpY2FsbHkuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoU3BpZmZlXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aFNwaWZmZSB7XG4gIC8qKlxuICAgKiBKV1QgY29uZmlndXJlcyBob3cgdGhlIFNQSUZGRSBTVklEIEpXVCBpcyBhdHRhY2hlZCB0byBvdXRib3VuZCByZXF1ZXN0cy5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoU3BpZmZlI2p3dFxuICAgKi9cbiAgcmVhZG9ubHkgand0PzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aFNwaWZmZUp3dDtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aFNwaWZmZScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoU3BpZmZlKG9iajogTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aFNwaWZmZSB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2p3dCc6IHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoU3BpZmZlSnd0KG9iai5qd3QpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VIZWFkZXJzU2VjcmV0S2V5UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlSGVhZGVyc1NlY3JldEtleVJlZiB7XG4gIC8qKlxuICAgKiBGaWVsZCBpbiB0aGUgc2VjcmV0LlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUhlYWRlcnNTZWNyZXRLZXlSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldCBuYW1lLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUhlYWRlcnNTZWNyZXRLZXlSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VIZWFkZXJzU2VjcmV0S2V5UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFNzZUhlYWRlcnNTZWNyZXRLZXlSZWYob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VIZWFkZXJzU2VjcmV0S2V5UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpb0VudlNlY3JldEtleVJlZlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvRW52U2VjcmV0S2V5UmVmIHtcbiAgLyoqXG4gICAqIEZpZWxkIGluIHRoZSBzZWNyZXQuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW9FbnZTZWNyZXRLZXlSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldCBuYW1lLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0ZGlvRW52U2VjcmV0S2V5UmVmI25hbWVcbiAgICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW9FbnZTZWNyZXRLZXlSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RkaW9FbnZTZWNyZXRLZXlSZWYob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdGRpb0VudlNlY3JldEtleVJlZiB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2tleSc6IG9iai5rZXksXG4gICAgJ25hbWUnOiBvYmoubmFtZSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIE9BdXRoMiBjb25maWd1cmVzIE9BdXRoMiBjbGllbnQgY3JlZGVudGlhbHMgZmxvdyBmb3IgdGhlIE1DUCBzZXJ2ZXIuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhPYXV0aDJcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhPYXV0aDIge1xuICAvKipcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhPYXV0aDIjYXVkaWVuY2VcbiAgICovXG4gIHJlYWRvbmx5IGF1ZGllbmNlPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBDbGllbnRJRCBpcyB0aGUgT0F1dGgyIGNsaWVudCBpZGVudGlmaWVyIHNlbnQgdG8gdGhlIHRva2VuIGVuZHBvaW50LlxuICAgKiBSZXF1aXJlZCBieSBSRkMgNjc0OSBmb3IgdGhlIHN0YW5kYXJkIGNsaWVudF9jcmVkZW50aWFscyBmbG93IChmb3JtIHBhcmFtZXRlclxuICAgKiBvciBIVFRQIEJhc2ljIHVzZXJuYW1lKS4gTWF5IGJlIGxlZnQgZW1wdHkgZm9yIG5vbi1zdGFuZGFyZCBmbG93cyAoZS5nLiBKV1QtYmVhcmVyXG4gICAqIGFzc2VydGlvbnMgb3IgdG9rZW4gZW5kcG9pbnRzIHRoYXQga2V5IHNvbGVseSBvbiB0aGUgY2xpZW50X3NlY3JldCkuIENsaWVudCBJRHNcbiAgICogYXJlIHR5cGljYWxseSBwdWJsaWMgaWRlbnRpZmllcnM7IHVzZSBzcGVjLmhlYWRlcnMgd2l0aCBhIHNlY3JldEtleVJlZiBpZiB5b3VyXG4gICAqIGVudmlyb25tZW50IHJlcXVpcmVzIHNvdXJjaW5nIHRoZSB2YWx1ZSBmcm9tIGEgc2VjcmV0IHN0b3JlLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aE9hdXRoMiNjbGllbnRJRFxuICAgKi9cbiAgcmVhZG9ubHkgY2xpZW50SWQ/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIElzc3VlciBpcyB0aGUgdG9rZW4gZW5kcG9pbnQgb2YgdGhlIGF1dGhvcml6YXRpb24gc2VydmVyLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aE9hdXRoMiNpc3N1ZXJcbiAgICovXG4gIHJlYWRvbmx5IGlzc3Vlcjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aE9hdXRoMiNzY29wZXNcbiAgICovXG4gIHJlYWRvbmx5IHNjb3Blcz86IHN0cmluZ1tdO1xuXG4gIC8qKlxuICAgKiBTZWNyZXRLZXlSZWYgcmVmZXJlbmNlcyB0aGUgY2xpZW50IHNlY3JldCBpbiB0aGUgY29uZmlndXJlZCBzZWNyZXQgc3RvcmUuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyI3NlY3JldEtleVJlZlxuICAgKi9cbiAgcmVhZG9ubHkgc2VjcmV0S2V5UmVmPzogTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyU2VjcmV0S2V5UmVmO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhPYXV0aDInIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyKG9iajogTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2UnOiBvYmouYXVkaWVuY2UsXG4gICAgJ2NsaWVudElEJzogb2JqLmNsaWVudElkLFxuICAgICdpc3N1ZXInOiBvYmouaXNzdWVyLFxuICAgICdzY29wZXMnOiBvYmouc2NvcGVzPy5tYXAoeSA9PiB5KSxcbiAgICAnc2VjcmV0S2V5UmVmJzogdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aE9hdXRoMlNlY3JldEtleVJlZihvYmouc2VjcmV0S2V5UmVmKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFNQSUZGRSBjb25maWd1cmVzIHdvcmtsb2FkIGlkZW50aXR5IEpXVCBpbmplY3Rpb24gdmlhIERhcHIncyBTZW50cnkgQ0EuXG4gKiBObyBzZWNyZXQgaXMgcmVxdWlyZWQ7IFNlbnRyeSBpc3N1ZXMgdGhlIFNWSUQgYXV0b21hdGljYWxseS5cbiAqXG4gKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aFNwaWZmZVxuICovXG5leHBvcnQgaW50ZXJmYWNlIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aFNwaWZmZSB7XG4gIC8qKlxuICAgKiBKV1QgY29uZmlndXJlcyBob3cgdGhlIFNQSUZGRSBTVklEIEpXVCBpcyBhdHRhY2hlZCB0byBvdXRib3VuZCByZXF1ZXN0cy5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhTcGlmZmUjand0XG4gICAqL1xuICByZWFkb25seSBqd3Q/OiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhTcGlmZmVKd3Q7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ01jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aFNwaWZmZScgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhTcGlmZmUob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhTcGlmZmUgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdqd3QnOiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoU3BpZmZlSnd0KG9iai5qd3QpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0S2V5UmVmIGlzIHRoZSByZWZlcmVuY2Ugb2YgYSB2YWx1ZSBpbiBhIHNlY3JldCBzdG9yZSBjb21wb25lbnQuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEhlYWRlcnNTZWNyZXRLZXlSZWZcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEhlYWRlcnNTZWNyZXRLZXlSZWYge1xuICAvKipcbiAgICogRmllbGQgaW4gdGhlIHNlY3JldC5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEhlYWRlcnNTZWNyZXRLZXlSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldCBuYW1lLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwSGVhZGVyc1NlY3JldEtleVJlZiNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ01jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwSGVhZGVyc1NlY3JldEtleVJlZicgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9NY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEhlYWRlcnNTZWNyZXRLZXlSZWYob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEhlYWRlcnNTZWNyZXRLZXlSZWYgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdrZXknOiBvYmoua2V5LFxuICAgICduYW1lJzogb2JqLm5hbWUsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTZWNyZXRLZXlSZWYgcmVmZXJlbmNlcyB0aGUgY2xpZW50IHNlY3JldCBpbiB0aGUgY29uZmlndXJlZCBzZWNyZXQgc3RvcmUuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyU2VjcmV0S2V5UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aE9hdXRoMlNlY3JldEtleVJlZiB7XG4gIC8qKlxuICAgKiBGaWVsZCBpbiB0aGUgc2VjcmV0LlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhPYXV0aDJTZWNyZXRLZXlSZWYja2V5XG4gICAqL1xuICByZWFkb25seSBrZXk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNlY3JldCBuYW1lLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhPYXV0aDJTZWNyZXRLZXlSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyU2VjcmV0S2V5UmVmJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhPYXV0aDJTZWNyZXRLZXlSZWYob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoT2F1dGgyU2VjcmV0S2V5UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogSldUIGNvbmZpZ3VyZXMgaG93IHRoZSBTUElGRkUgU1ZJRCBKV1QgaXMgYXR0YWNoZWQgdG8gb3V0Ym91bmQgcmVxdWVzdHMuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoU3BpZmZlSnd0XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aFNwaWZmZUp3dCB7XG4gIC8qKlxuICAgKiBBdWRpZW5jZSBpcyB0aGUgaW50ZW5kZWQgYXVkaWVuY2UgZm9yIHRoZSBKV1QgKGUuZy4gXCJtY3A6Ly9wYXltZW50c1wiKS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoU3BpZmZlSnd0I2F1ZGllbmNlXG4gICAqL1xuICByZWFkb25seSBhdWRpZW5jZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBIZWFkZXIgaXMgdGhlIEhUVFAgaGVhZGVyIG5hbWUgdG8gaW5qZWN0IHRoZSBKV1QgaW50byAoZS5nLiBcIkF1dGhvcml6YXRpb25cIikuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3NlQXV0aFNwaWZmZUp3dCNoZWFkZXJcbiAgICovXG4gIHJlYWRvbmx5IGhlYWRlcjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBIZWFkZXJWYWx1ZVByZWZpeCBpcyBhbiBvcHRpb25hbCBzdHJpbmcgcHJlcGVuZGVkIHRvIHRoZSBKV1QgdmFsdWUgKGUuZy4gXCJCZWFyZXIgXCIpLlxuICAgKlxuICAgKiBAc2NoZW1hIE1jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhTcGlmZmVKd3QjaGVhZGVyVmFsdWVQcmVmaXhcbiAgICovXG4gIHJlYWRvbmx5IGhlYWRlclZhbHVlUHJlZml4Pzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoU3BpZmZlSnd0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFNzZUF1dGhTcGlmZmVKd3Qob2JqOiBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTc2VBdXRoU3BpZmZlSnd0IHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXVkaWVuY2UnOiBvYmouYXVkaWVuY2UsXG4gICAgJ2hlYWRlcic6IG9iai5oZWFkZXIsXG4gICAgJ2hlYWRlclZhbHVlUHJlZml4Jzogb2JqLmhlYWRlclZhbHVlUHJlZml4LFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogU2VjcmV0S2V5UmVmIHJlZmVyZW5jZXMgdGhlIGNsaWVudCBzZWNyZXQgaW4gdGhlIGNvbmZpZ3VyZWQgc2VjcmV0IHN0b3JlLlxuICpcbiAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyU2VjcmV0S2V5UmVmXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyU2VjcmV0S2V5UmVmIHtcbiAgLyoqXG4gICAqIEZpZWxkIGluIHRoZSBzZWNyZXQuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyU2VjcmV0S2V5UmVmI2tleVxuICAgKi9cbiAgcmVhZG9ubHkga2V5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBTZWNyZXQgbmFtZS5cbiAgICpcbiAgICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhPYXV0aDJTZWNyZXRLZXlSZWYjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhPYXV0aDJTZWNyZXRLZXlSZWYnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyU2VjcmV0S2V5UmVmKG9iajogTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoT2F1dGgyU2VjcmV0S2V5UmVmIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAna2V5Jzogb2JqLmtleSxcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogSldUIGNvbmZpZ3VyZXMgaG93IHRoZSBTUElGRkUgU1ZJRCBKV1QgaXMgYXR0YWNoZWQgdG8gb3V0Ym91bmQgcmVxdWVzdHMuXG4gKlxuICogQHNjaGVtYSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhTcGlmZmVKd3RcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBNY3BTZXJ2ZXJTcGVjRW5kcG9pbnRTdHJlYW1hYmxlSHR0cEF1dGhTcGlmZmVKd3Qge1xuICAvKipcbiAgICogQXVkaWVuY2UgaXMgdGhlIGludGVuZGVkIGF1ZGllbmNlIGZvciB0aGUgSldUIChlLmcuIFwibWNwOi8vcGF5bWVudHNcIikuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoU3BpZmZlSnd0I2F1ZGllbmNlXG4gICAqL1xuICByZWFkb25seSBhdWRpZW5jZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBIZWFkZXIgaXMgdGhlIEhUVFAgaGVhZGVyIG5hbWUgdG8gaW5qZWN0IHRoZSBKV1QgaW50byAoZS5nLiBcIkF1dGhvcml6YXRpb25cIikuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoU3BpZmZlSnd0I2hlYWRlclxuICAgKi9cbiAgcmVhZG9ubHkgaGVhZGVyOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEhlYWRlclZhbHVlUHJlZml4IGlzIGFuIG9wdGlvbmFsIHN0cmluZyBwcmVwZW5kZWQgdG8gdGhlIEpXVCB2YWx1ZSAoZS5nLiBcIkJlYXJlciBcIikuXG4gICAqXG4gICAqIEBzY2hlbWEgTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoU3BpZmZlSnd0I2hlYWRlclZhbHVlUHJlZml4XG4gICAqL1xuICByZWFkb25seSBoZWFkZXJWYWx1ZVByZWZpeD86IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnTWNwU2VydmVyU3BlY0VuZHBvaW50U3RyZWFtYWJsZUh0dHBBdXRoU3BpZmZlSnd0JyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX01jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aFNwaWZmZUp3dChvYmo6IE1jcFNlcnZlclNwZWNFbmRwb2ludFN0cmVhbWFibGVIdHRwQXV0aFNwaWZmZUp3dCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2F1ZGllbmNlJzogb2JqLmF1ZGllbmNlLFxuICAgICdoZWFkZXInOiBvYmouaGVhZGVyLFxuICAgICdoZWFkZXJWYWx1ZVByZWZpeCc6IG9iai5oZWFkZXJWYWx1ZVByZWZpeCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG5cbi8qKlxuICpcbiAqXG4gKiBAc2NoZW1hIFJlc2lsaWVuY3lcbiAqL1xuZXhwb3J0IGNsYXNzIFJlc2lsaWVuY3kgZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJSZXNpbGllbmN5XCJcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgR1ZLOiBHcm91cFZlcnNpb25LaW5kID0ge1xuICAgIGFwaVZlcnNpb246ICdkYXByLmlvL3YxYWxwaGExJyxcbiAgICBraW5kOiAnUmVzaWxpZW5jeScsXG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyBhIEt1YmVybmV0ZXMgbWFuaWZlc3QgZm9yIFwiUmVzaWxpZW5jeVwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBSZXNpbGllbmN5UHJvcHMgPSB7fSk6IGFueSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLlJlc2lsaWVuY3kuR1ZLLFxuICAgICAgLi4udG9Kc29uX1Jlc2lsaWVuY3lQcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJSZXNpbGllbmN5XCIgQVBJIG9iamVjdFxuICAgKiBAcGFyYW0gc2NvcGUgdGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIG9iamVjdFxuICAgKiBAcGFyYW0gaWQgYSBzY29wZS1sb2NhbCBuYW1lIGZvciB0aGUgb2JqZWN0XG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBSZXNpbGllbmN5UHJvcHMgPSB7fSkge1xuICAgIHN1cGVyKHNjb3BlLCBpZCwge1xuICAgICAgLi4uUmVzaWxpZW5jeS5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIG92ZXJyaWRlIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uUmVzaWxpZW5jeS5HVkssXG4gICAgICAuLi50b0pzb25fUmVzaWxpZW5jeVByb3BzKHJlc29sdmVkKSxcbiAgICB9O1xuICB9XG59XG5cbi8qKlxuICogQHNjaGVtYSBSZXNpbGllbmN5XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVzaWxpZW5jeVByb3BzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeSNtZXRhZGF0YVxuICAgKi9cbiAgcmVhZG9ubHkgbWV0YWRhdGE/OiBBcGlPYmplY3RNZXRhZGF0YTtcblxuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5I3Njb3Blc1xuICAgKi9cbiAgcmVhZG9ubHkgc2NvcGVzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeSNzcGVjXG4gICAqL1xuICByZWFkb25seSBzcGVjPzogUmVzaWxpZW5jeVNwZWM7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1Jlc2lsaWVuY3lQcm9wcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9SZXNpbGllbmN5UHJvcHMob2JqOiBSZXNpbGllbmN5UHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc2NvcGVzJzogb2JqLnNjb3Blcz8ubWFwKHkgPT4geSksXG4gICAgJ3NwZWMnOiB0b0pzb25fUmVzaWxpZW5jeVNwZWMob2JqLnNwZWMpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFJlc2lsaWVuY3lTcGVjIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWMjcG9saWNpZXNcbiAgICovXG4gIHJlYWRvbmx5IHBvbGljaWVzOiBSZXNpbGllbmN5U3BlY1BvbGljaWVzO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjI3RhcmdldHNcbiAgICovXG4gIHJlYWRvbmx5IHRhcmdldHM6IFJlc2lsaWVuY3lTcGVjVGFyZ2V0cztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnUmVzaWxpZW5jeVNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fUmVzaWxpZW5jeVNwZWMob2JqOiBSZXNpbGllbmN5U3BlYyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ3BvbGljaWVzJzogdG9Kc29uX1Jlc2lsaWVuY3lTcGVjUG9saWNpZXMob2JqLnBvbGljaWVzKSxcbiAgICAndGFyZ2V0cyc6IHRvSnNvbl9SZXNpbGllbmN5U3BlY1RhcmdldHMob2JqLnRhcmdldHMpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1BvbGljaWVzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVzaWxpZW5jeVNwZWNQb2xpY2llcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjUG9saWNpZXMjY2lyY3VpdEJyZWFrZXJzXG4gICAqL1xuICByZWFkb25seSBjaXJjdWl0QnJlYWtlcnM/OiB7IFtrZXk6IHN0cmluZ106IFJlc2lsaWVuY3lTcGVjUG9saWNpZXNDaXJjdWl0QnJlYWtlcnMgfTtcblxuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1BvbGljaWVzI3JldHJpZXNcbiAgICovXG4gIHJlYWRvbmx5IHJldHJpZXM/OiB7IFtrZXk6IHN0cmluZ106IFJlc2lsaWVuY3lTcGVjUG9saWNpZXNSZXRyaWVzIH07XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNQb2xpY2llcyN0aW1lb3V0c1xuICAgKi9cbiAgcmVhZG9ubHkgdGltZW91dHM/OiB7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9O1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdSZXNpbGllbmN5U3BlY1BvbGljaWVzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1Jlc2lsaWVuY3lTcGVjUG9saWNpZXMob2JqOiBSZXNpbGllbmN5U3BlY1BvbGljaWVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnY2lyY3VpdEJyZWFrZXJzJzogKChvYmouY2lyY3VpdEJyZWFrZXJzKSA9PT0gdW5kZWZpbmVkKSA/IHVuZGVmaW5lZCA6IChPYmplY3QuZW50cmllcyhvYmouY2lyY3VpdEJyZWFrZXJzKS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogdG9Kc29uX1Jlc2lsaWVuY3lTcGVjUG9saWNpZXNDaXJjdWl0QnJlYWtlcnMoaVsxXSkgfSksIHt9KSksXG4gICAgJ3JldHJpZXMnOiAoKG9iai5yZXRyaWVzKSA9PT0gdW5kZWZpbmVkKSA/IHVuZGVmaW5lZCA6IChPYmplY3QuZW50cmllcyhvYmoucmV0cmllcykucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IHRvSnNvbl9SZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllcyhpWzFdKSB9KSwge30pKSxcbiAgICAndGltZW91dHMnOiAoKG9iai50aW1lb3V0cykgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLnRpbWVvdXRzKS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVzaWxpZW5jeVNwZWNUYXJnZXRzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzI2FjdG9yc1xuICAgKi9cbiAgcmVhZG9ubHkgYWN0b3JzPzogeyBba2V5OiBzdHJpbmddOiBSZXNpbGllbmN5U3BlY1RhcmdldHNBY3RvcnMgfTtcblxuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1RhcmdldHMjYXBwc1xuICAgKi9cbiAgcmVhZG9ubHkgYXBwcz86IHsgW2tleTogc3RyaW5nXTogUmVzaWxpZW5jeVNwZWNUYXJnZXRzQXBwcyB9O1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0cyNjb21wb25lbnRzXG4gICAqL1xuICByZWFkb25seSBjb21wb25lbnRzPzogeyBba2V5OiBzdHJpbmddOiBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzIH07XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1Jlc2lsaWVuY3lTcGVjVGFyZ2V0cycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9SZXNpbGllbmN5U3BlY1RhcmdldHMob2JqOiBSZXNpbGllbmN5U3BlY1RhcmdldHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdhY3RvcnMnOiAoKG9iai5hY3RvcnMpID09PSB1bmRlZmluZWQpID8gdW5kZWZpbmVkIDogKE9iamVjdC5lbnRyaWVzKG9iai5hY3RvcnMpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiB0b0pzb25fUmVzaWxpZW5jeVNwZWNUYXJnZXRzQWN0b3JzKGlbMV0pIH0pLCB7fSkpLFxuICAgICdhcHBzJzogKChvYmouYXBwcykgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLmFwcHMpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiB0b0pzb25fUmVzaWxpZW5jeVNwZWNUYXJnZXRzQXBwcyhpWzFdKSB9KSwge30pKSxcbiAgICAnY29tcG9uZW50cyc6ICgob2JqLmNvbXBvbmVudHMpID09PSB1bmRlZmluZWQpID8gdW5kZWZpbmVkIDogKE9iamVjdC5lbnRyaWVzKG9iai5jb21wb25lbnRzKS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogdG9Kc29uX1Jlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHMoaVsxXSkgfSksIHt9KSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjUG9saWNpZXNDaXJjdWl0QnJlYWtlcnNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSZXNpbGllbmN5U3BlY1BvbGljaWVzQ2lyY3VpdEJyZWFrZXJzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNQb2xpY2llc0NpcmN1aXRCcmVha2VycyNpbnRlcnZhbFxuICAgKi9cbiAgcmVhZG9ubHkgaW50ZXJ2YWw/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNQb2xpY2llc0NpcmN1aXRCcmVha2VycyNtYXhSZXF1ZXN0c1xuICAgKi9cbiAgcmVhZG9ubHkgbWF4UmVxdWVzdHM/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNQb2xpY2llc0NpcmN1aXRCcmVha2VycyN0aW1lb3V0XG4gICAqL1xuICByZWFkb25seSB0aW1lb3V0Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjUG9saWNpZXNDaXJjdWl0QnJlYWtlcnMjdHJpcFxuICAgKi9cbiAgcmVhZG9ubHkgdHJpcD86IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnUmVzaWxpZW5jeVNwZWNQb2xpY2llc0NpcmN1aXRCcmVha2VycycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9SZXNpbGllbmN5U3BlY1BvbGljaWVzQ2lyY3VpdEJyZWFrZXJzKG9iajogUmVzaWxpZW5jeVNwZWNQb2xpY2llc0NpcmN1aXRCcmVha2VycyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2ludGVydmFsJzogb2JqLmludGVydmFsLFxuICAgICdtYXhSZXF1ZXN0cyc6IG9iai5tYXhSZXF1ZXN0cyxcbiAgICAndGltZW91dCc6IG9iai50aW1lb3V0LFxuICAgICd0cmlwJzogb2JqLnRyaXAsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjUG9saWNpZXNSZXRyaWVzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVzaWxpZW5jeVNwZWNQb2xpY2llc1JldHJpZXMge1xuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllcyNkdXJhdGlvblxuICAgKi9cbiAgcmVhZG9ubHkgZHVyYXRpb24/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFJldHJ5TWF0Y2hpbmcgcmVwcmVzZW50cyB0aGUgcnVsZXMgdG8gdHJpZ2dlciByZXRyeSBpbiBzcGVjaWZpYyBzY2VuYXJpb3MuXG4gICAqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNQb2xpY2llc1JldHJpZXMjbWF0Y2hpbmdcbiAgICovXG4gIHJlYWRvbmx5IG1hdGNoaW5nPzogUmVzaWxpZW5jeVNwZWNQb2xpY2llc1JldHJpZXNNYXRjaGluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllcyNtYXhJbnRlcnZhbFxuICAgKi9cbiAgcmVhZG9ubHkgbWF4SW50ZXJ2YWw/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNQb2xpY2llc1JldHJpZXMjbWF4UmV0cmllc1xuICAgKi9cbiAgcmVhZG9ubHkgbWF4UmV0cmllcz86IG51bWJlcjtcblxuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllcyNwb2xpY3lcbiAgICovXG4gIHJlYWRvbmx5IHBvbGljeT86IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnUmVzaWxpZW5jeVNwZWNQb2xpY2llc1JldHJpZXMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fUmVzaWxpZW5jeVNwZWNQb2xpY2llc1JldHJpZXMob2JqOiBSZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2R1cmF0aW9uJzogb2JqLmR1cmF0aW9uLFxuICAgICdtYXRjaGluZyc6IHRvSnNvbl9SZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllc01hdGNoaW5nKG9iai5tYXRjaGluZyksXG4gICAgJ21heEludGVydmFsJzogb2JqLm1heEludGVydmFsLFxuICAgICdtYXhSZXRyaWVzJzogb2JqLm1heFJldHJpZXMsXG4gICAgJ3BvbGljeSc6IG9iai5wb2xpY3ksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0FjdG9yc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0FjdG9ycyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0FjdG9ycyNjaXJjdWl0QnJlYWtlclxuICAgKi9cbiAgcmVhZG9ubHkgY2lyY3VpdEJyZWFrZXI/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQWN0b3JzI2NpcmN1aXRCcmVha2VyQ2FjaGVTaXplXG4gICAqL1xuICByZWFkb25seSBjaXJjdWl0QnJlYWtlckNhY2hlU2l6ZT86IG51bWJlcjtcblxuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1RhcmdldHNBY3RvcnMjY2lyY3VpdEJyZWFrZXJTY29wZVxuICAgKi9cbiAgcmVhZG9ubHkgY2lyY3VpdEJyZWFrZXJTY29wZT86IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1RhcmdldHNBY3RvcnMjcmV0cnlcbiAgICovXG4gIHJlYWRvbmx5IHJldHJ5Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0FjdG9ycyN0aW1lb3V0XG4gICAqL1xuICByZWFkb25seSB0aW1lb3V0Pzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdSZXNpbGllbmN5U3BlY1RhcmdldHNBY3RvcnMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fUmVzaWxpZW5jeVNwZWNUYXJnZXRzQWN0b3JzKG9iajogUmVzaWxpZW5jeVNwZWNUYXJnZXRzQWN0b3JzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnY2lyY3VpdEJyZWFrZXInOiBvYmouY2lyY3VpdEJyZWFrZXIsXG4gICAgJ2NpcmN1aXRCcmVha2VyQ2FjaGVTaXplJzogb2JqLmNpcmN1aXRCcmVha2VyQ2FjaGVTaXplLFxuICAgICdjaXJjdWl0QnJlYWtlclNjb3BlJzogb2JqLmNpcmN1aXRCcmVha2VyU2NvcGUsXG4gICAgJ3JldHJ5Jzogb2JqLnJldHJ5LFxuICAgICd0aW1lb3V0Jzogb2JqLnRpbWVvdXQsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0FwcHNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSZXNpbGllbmN5U3BlY1RhcmdldHNBcHBzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQXBwcyNjaXJjdWl0QnJlYWtlclxuICAgKi9cbiAgcmVhZG9ubHkgY2lyY3VpdEJyZWFrZXI/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQXBwcyNjaXJjdWl0QnJlYWtlckNhY2hlU2l6ZVxuICAgKi9cbiAgcmVhZG9ubHkgY2lyY3VpdEJyZWFrZXJDYWNoZVNpemU/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQXBwcyNyZXRyeVxuICAgKi9cbiAgcmVhZG9ubHkgcmV0cnk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQXBwcyN0aW1lb3V0XG4gICAqL1xuICByZWFkb25seSB0aW1lb3V0Pzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdSZXNpbGllbmN5U3BlY1RhcmdldHNBcHBzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1Jlc2lsaWVuY3lTcGVjVGFyZ2V0c0FwcHMob2JqOiBSZXNpbGllbmN5U3BlY1RhcmdldHNBcHBzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnY2lyY3VpdEJyZWFrZXInOiBvYmouY2lyY3VpdEJyZWFrZXIsXG4gICAgJ2NpcmN1aXRCcmVha2VyQ2FjaGVTaXplJzogb2JqLmNpcmN1aXRCcmVha2VyQ2FjaGVTaXplLFxuICAgICdyZXRyeSc6IG9iai5yZXRyeSxcbiAgICAndGltZW91dCc6IG9iai50aW1lb3V0LFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQ29tcG9uZW50cyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHMjaW5ib3VuZFxuICAgKi9cbiAgcmVhZG9ubHkgaW5ib3VuZD86IFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHNJbmJvdW5kO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHMjb3V0Ym91bmRcbiAgICovXG4gIHJlYWRvbmx5IG91dGJvdW5kPzogUmVzaWxpZW5jeVNwZWNUYXJnZXRzQ29tcG9uZW50c091dGJvdW5kO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1Jlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHMob2JqOiBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnaW5ib3VuZCc6IHRvSnNvbl9SZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzSW5ib3VuZChvYmouaW5ib3VuZCksXG4gICAgJ291dGJvdW5kJzogdG9Kc29uX1Jlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHNPdXRib3VuZChvYmoub3V0Ym91bmQpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogUmV0cnlNYXRjaGluZyByZXByZXNlbnRzIHRoZSBydWxlcyB0byB0cmlnZ2VyIHJldHJ5IGluIHNwZWNpZmljIHNjZW5hcmlvcy5cbiAqXG4gKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjUG9saWNpZXNSZXRyaWVzTWF0Y2hpbmdcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllc01hdGNoaW5nIHtcbiAgLyoqXG4gICAqIEdSUENTdGF0dXNDb2RlcyByZXByZXNlbnRzIGdSUEMgc3RhdHVzIGNvZGVzIHRvIGJlIHJldHJpZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNQb2xpY2llc1JldHJpZXNNYXRjaGluZyNnUlBDU3RhdHVzQ29kZXNcbiAgICovXG4gIHJlYWRvbmx5IGdScGNTdGF0dXNDb2Rlcz86IHN0cmluZztcblxuICAvKipcbiAgICogSFRUUFN0YXR1c0NvZGVzIHJlcHJlc2VudHMgSFRUUCBzdGF0dXMgY29kZXMgdG8gYmUgcmV0cmllZC5cbiAgICpcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllc01hdGNoaW5nI2h0dHBTdGF0dXNDb2Rlc1xuICAgKi9cbiAgcmVhZG9ubHkgaHR0cFN0YXR1c0NvZGVzPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdSZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllc01hdGNoaW5nJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1Jlc2lsaWVuY3lTcGVjUG9saWNpZXNSZXRyaWVzTWF0Y2hpbmcob2JqOiBSZXNpbGllbmN5U3BlY1BvbGljaWVzUmV0cmllc01hdGNoaW5nIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnZ1JQQ1N0YXR1c0NvZGVzJzogb2JqLmdScGNTdGF0dXNDb2RlcyxcbiAgICAnaHR0cFN0YXR1c0NvZGVzJzogb2JqLmh0dHBTdGF0dXNDb2RlcyxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQ29tcG9uZW50c0luYm91bmRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzSW5ib3VuZCB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHNJbmJvdW5kI2NpcmN1aXRCcmVha2VyXG4gICAqL1xuICByZWFkb25seSBjaXJjdWl0QnJlYWtlcj86IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzSW5ib3VuZCNyZXRyeVxuICAgKi9cbiAgcmVhZG9ubHkgcmV0cnk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQ29tcG9uZW50c0luYm91bmQjdGltZW91dFxuICAgKi9cbiAgcmVhZG9ubHkgdGltZW91dD86IHN0cmluZztcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnUmVzaWxpZW5jeVNwZWNUYXJnZXRzQ29tcG9uZW50c0luYm91bmQnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fUmVzaWxpZW5jeVNwZWNUYXJnZXRzQ29tcG9uZW50c0luYm91bmQob2JqOiBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzSW5ib3VuZCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2NpcmN1aXRCcmVha2VyJzogb2JqLmNpcmN1aXRCcmVha2VyLFxuICAgICdyZXRyeSc6IG9iai5yZXRyeSxcbiAgICAndGltZW91dCc6IG9iai50aW1lb3V0LFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzT3V0Ym91bmRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzT3V0Ym91bmQge1xuICAvKipcbiAgICogQHNjaGVtYSBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzT3V0Ym91bmQjY2lyY3VpdEJyZWFrZXJcbiAgICovXG4gIHJlYWRvbmx5IGNpcmN1aXRCcmVha2VyPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFJlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHNPdXRib3VuZCNyZXRyeVxuICAgKi9cbiAgcmVhZG9ubHkgcmV0cnk/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgUmVzaWxpZW5jeVNwZWNUYXJnZXRzQ29tcG9uZW50c091dGJvdW5kI3RpbWVvdXRcbiAgICovXG4gIHJlYWRvbmx5IHRpbWVvdXQ/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1Jlc2lsaWVuY3lTcGVjVGFyZ2V0c0NvbXBvbmVudHNPdXRib3VuZCcgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9SZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzT3V0Ym91bmQob2JqOiBSZXNpbGllbmN5U3BlY1RhcmdldHNDb21wb25lbnRzT3V0Ym91bmQgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdjaXJjdWl0QnJlYWtlcic6IG9iai5jaXJjdWl0QnJlYWtlcixcbiAgICAncmV0cnknOiBvYmoucmV0cnksXG4gICAgJ3RpbWVvdXQnOiBvYmoudGltZW91dCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG5cbi8qKlxuICogU3Vic2NyaXB0aW9uIGRlc2NyaWJlcyBhbiBwdWIvc3ViIGV2ZW50IHN1YnNjcmlwdGlvbi5cbiAqXG4gKiBAc2NoZW1hIFN1YnNjcmlwdGlvblxuICovXG5leHBvcnQgY2xhc3MgU3Vic2NyaXB0aW9uIGV4dGVuZHMgQXBpT2JqZWN0IHtcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGFwaVZlcnNpb24gYW5kIGtpbmQgZm9yIFwiU3Vic2NyaXB0aW9uXCJcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgR1ZLOiBHcm91cFZlcnNpb25LaW5kID0ge1xuICAgIGFwaVZlcnNpb246ICdkYXByLmlvL3YxYWxwaGExJyxcbiAgICBraW5kOiAnU3Vic2NyaXB0aW9uJyxcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIGEgS3ViZXJuZXRlcyBtYW5pZmVzdCBmb3IgXCJTdWJzY3JpcHRpb25cIi5cbiAgICpcbiAgICogVGhpcyBjYW4gYmUgdXNlZCB0byBpbmxpbmUgcmVzb3VyY2UgbWFuaWZlc3RzIGluc2lkZSBvdGhlciBvYmplY3RzIChlLmcuIGFzIHRlbXBsYXRlcykuXG4gICAqXG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIHN0YXRpYyBtYW5pZmVzdChwcm9wczogU3Vic2NyaXB0aW9uUHJvcHMgPSB7fSk6IGFueSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLlN1YnNjcmlwdGlvbi5HVkssXG4gICAgICAuLi50b0pzb25fU3Vic2NyaXB0aW9uUHJvcHMocHJvcHMpLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRGVmaW5lcyBhIFwiU3Vic2NyaXB0aW9uXCIgQVBJIG9iamVjdFxuICAgKiBAcGFyYW0gc2NvcGUgdGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIG9iamVjdFxuICAgKiBAcGFyYW0gaWQgYSBzY29wZS1sb2NhbCBuYW1lIGZvciB0aGUgb2JqZWN0XG4gICAqIEBwYXJhbSBwcm9wcyBpbml0aWFsaXphdGlvbiBwcm9wc1xuICAgKi9cbiAgcHVibGljIGNvbnN0cnVjdG9yKHNjb3BlOiBDb25zdHJ1Y3QsIGlkOiBzdHJpbmcsIHByb3BzOiBTdWJzY3JpcHRpb25Qcm9wcyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICAuLi5TdWJzY3JpcHRpb24uR1ZLLFxuICAgICAgLi4ucHJvcHMsXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmVuZGVycyB0aGUgb2JqZWN0IHRvIEt1YmVybmV0ZXMgSlNPTi5cbiAgICovXG4gIHB1YmxpYyBvdmVycmlkZSB0b0pzb24oKTogYW55IHtcbiAgICBjb25zdCByZXNvbHZlZCA9IHN1cGVyLnRvSnNvbigpO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLlN1YnNjcmlwdGlvbi5HVkssXG4gICAgICAuLi50b0pzb25fU3Vic2NyaXB0aW9uUHJvcHMocmVzb2x2ZWQpLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdWJzY3JpcHRpb24gZGVzY3JpYmVzIGFuIHB1Yi9zdWIgZXZlbnQgc3Vic2NyaXB0aW9uLlxuICpcbiAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3Vic2NyaXB0aW9uUHJvcHMge1xuICAvKipcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb24jbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogQXBpT2JqZWN0TWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uI3Njb3Blc1xuICAgKi9cbiAgcmVhZG9ubHkgc2NvcGVzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFN1YnNjcmlwdGlvblNwZWMgaXMgdGhlIHNwZWMgZm9yIGFuIGV2ZW50IHN1YnNjcmlwdGlvbi5cbiAgICpcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb24jc3BlY1xuICAgKi9cbiAgcmVhZG9ubHkgc3BlYz86IFN1YnNjcmlwdGlvblNwZWM7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N1YnNjcmlwdGlvblByb3BzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1N1YnNjcmlwdGlvblByb3BzKG9iajogU3Vic2NyaXB0aW9uUHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc2NvcGVzJzogb2JqLnNjb3Blcz8ubWFwKHkgPT4geSksXG4gICAgJ3NwZWMnOiB0b0pzb25fU3Vic2NyaXB0aW9uU3BlYyhvYmouc3BlYyksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBTdWJzY3JpcHRpb25TcGVjIGlzIHRoZSBzcGVjIGZvciBhbiBldmVudCBzdWJzY3JpcHRpb24uXG4gKlxuICogQHNjaGVtYSBTdWJzY3JpcHRpb25TcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3Vic2NyaXB0aW9uU3BlYyB7XG4gIC8qKlxuICAgKiBCdWxrU3Vic2NyaWJlIGVuY2Fwc3VsYXRlcyB0aGUgYnVsayBzdWJzY3JpcHRpb24gY29uZmlndXJhdGlvbiBmb3IgYSB0b3BpYy5cbiAgICpcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25TcGVjI2J1bGtTdWJzY3JpYmVcbiAgICovXG4gIHJlYWRvbmx5IGJ1bGtTdWJzY3JpYmU/OiBTdWJzY3JpcHRpb25TcGVjQnVsa1N1YnNjcmliZTtcblxuICAvKipcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25TcGVjI2RlYWRMZXR0ZXJUb3BpY1xuICAgKi9cbiAgcmVhZG9ubHkgZGVhZExldHRlclRvcGljPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFN1YnNjcmlwdGlvblNwZWMjbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogeyBba2V5OiBzdHJpbmddOiBzdHJpbmcgfTtcblxuICAvKipcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25TcGVjI3B1YnN1Ym5hbWVcbiAgICovXG4gIHJlYWRvbmx5IHB1YnN1Ym5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25TcGVjI3JvdXRlXG4gICAqL1xuICByZWFkb25seSByb3V0ZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFN1YnNjcmlwdGlvblNwZWMjdG9waWNcbiAgICovXG4gIHJlYWRvbmx5IHRvcGljOiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N1YnNjcmlwdGlvblNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fU3Vic2NyaXB0aW9uU3BlYyhvYmo6IFN1YnNjcmlwdGlvblNwZWMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdidWxrU3Vic2NyaWJlJzogdG9Kc29uX1N1YnNjcmlwdGlvblNwZWNCdWxrU3Vic2NyaWJlKG9iai5idWxrU3Vic2NyaWJlKSxcbiAgICAnZGVhZExldHRlclRvcGljJzogb2JqLmRlYWRMZXR0ZXJUb3BpYyxcbiAgICAnbWV0YWRhdGEnOiAoKG9iai5tZXRhZGF0YSkgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLm1ldGFkYXRhKS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pKSxcbiAgICAncHVic3VibmFtZSc6IG9iai5wdWJzdWJuYW1lLFxuICAgICdyb3V0ZSc6IG9iai5yb3V0ZSxcbiAgICAndG9waWMnOiBvYmoudG9waWMsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBCdWxrU3Vic2NyaWJlIGVuY2Fwc3VsYXRlcyB0aGUgYnVsayBzdWJzY3JpcHRpb24gY29uZmlndXJhdGlvbiBmb3IgYSB0b3BpYy5cbiAqXG4gKiBAc2NoZW1hIFN1YnNjcmlwdGlvblNwZWNCdWxrU3Vic2NyaWJlXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU3Vic2NyaXB0aW9uU3BlY0J1bGtTdWJzY3JpYmUge1xuICAvKipcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25TcGVjQnVsa1N1YnNjcmliZSNlbmFibGVkXG4gICAqL1xuICByZWFkb25seSBlbmFibGVkOiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFN1YnNjcmlwdGlvblNwZWNCdWxrU3Vic2NyaWJlI21heEF3YWl0RHVyYXRpb25Nc1xuICAgKi9cbiAgcmVhZG9ubHkgbWF4QXdhaXREdXJhdGlvbk1zPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFN1YnNjcmlwdGlvblNwZWNCdWxrU3Vic2NyaWJlI21heE1lc3NhZ2VzQ291bnRcbiAgICovXG4gIHJlYWRvbmx5IG1heE1lc3NhZ2VzQ291bnQ/OiBudW1iZXI7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N1YnNjcmlwdGlvblNwZWNCdWxrU3Vic2NyaWJlJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1N1YnNjcmlwdGlvblNwZWNCdWxrU3Vic2NyaWJlKG9iajogU3Vic2NyaXB0aW9uU3BlY0J1bGtTdWJzY3JpYmUgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdlbmFibGVkJzogb2JqLmVuYWJsZWQsXG4gICAgJ21heEF3YWl0RHVyYXRpb25Ncyc6IG9iai5tYXhBd2FpdER1cmF0aW9uTXMsXG4gICAgJ21heE1lc3NhZ2VzQ291bnQnOiBvYmoubWF4TWVzc2FnZXNDb3VudCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG5cbi8qKlxuICogU3Vic2NyaXB0aW9uIGRlc2NyaWJlcyBhbiBwdWIvc3ViIGV2ZW50IHN1YnNjcmlwdGlvbi5cbiAqXG4gKiBAc2NoZW1hIFN1YnNjcmlwdGlvblYyQWxwaGExXG4gKi9cbmV4cG9ydCBjbGFzcyBTdWJzY3JpcHRpb25WMkFscGhhMSBleHRlbmRzIEFwaU9iamVjdCB7XG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBhcGlWZXJzaW9uIGFuZCBraW5kIGZvciBcIlN1YnNjcmlwdGlvblYyQWxwaGExXCJcbiAgICovXG4gIHB1YmxpYyBzdGF0aWMgcmVhZG9ubHkgR1ZLOiBHcm91cFZlcnNpb25LaW5kID0ge1xuICAgIGFwaVZlcnNpb246ICdkYXByLmlvL3YyYWxwaGExJyxcbiAgICBraW5kOiAnU3Vic2NyaXB0aW9uJyxcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIGEgS3ViZXJuZXRlcyBtYW5pZmVzdCBmb3IgXCJTdWJzY3JpcHRpb25WMkFscGhhMVwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBTdWJzY3JpcHRpb25WMkFscGhhMVByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5TdWJzY3JpcHRpb25WMkFscGhhMS5HVkssXG4gICAgICAuLi50b0pzb25fU3Vic2NyaXB0aW9uVjJBbHBoYTFQcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJTdWJzY3JpcHRpb25WMkFscGhhMVwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogU3Vic2NyaXB0aW9uVjJBbHBoYTFQcm9wcyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICAuLi5TdWJzY3JpcHRpb25WMkFscGhhMS5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIG92ZXJyaWRlIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uU3Vic2NyaXB0aW9uVjJBbHBoYTEuR1ZLLFxuICAgICAgLi4udG9Kc29uX1N1YnNjcmlwdGlvblYyQWxwaGExUHJvcHMocmVzb2x2ZWQpLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBTdWJzY3JpcHRpb24gZGVzY3JpYmVzIGFuIHB1Yi9zdWIgZXZlbnQgc3Vic2NyaXB0aW9uLlxuICpcbiAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBTdWJzY3JpcHRpb25WMkFscGhhMVByb3BzIHtcbiAgLyoqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTEjbWV0YWRhdGFcbiAgICovXG4gIHJlYWRvbmx5IG1ldGFkYXRhPzogQXBpT2JqZWN0TWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTEjc2NvcGVzXG4gICAqL1xuICByZWFkb25seSBzY29wZXM/OiBzdHJpbmdbXTtcblxuICAvKipcbiAgICogU3Vic2NyaXB0aW9uU3BlYyBpcyB0aGUgc3BlYyBmb3IgYW4gZXZlbnQgc3Vic2NyaXB0aW9uLlxuICAgKlxuICAgKiBAc2NoZW1hIFN1YnNjcmlwdGlvblYyQWxwaGExI3NwZWNcbiAgICovXG4gIHJlYWRvbmx5IHNwZWM/OiBTdWJzY3JpcHRpb25WMkFscGhhMVNwZWM7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N1YnNjcmlwdGlvblYyQWxwaGExUHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fU3Vic2NyaXB0aW9uVjJBbHBoYTFQcm9wcyhvYmo6IFN1YnNjcmlwdGlvblYyQWxwaGExUHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc2NvcGVzJzogb2JqLnNjb3Blcz8ubWFwKHkgPT4geSksXG4gICAgJ3NwZWMnOiB0b0pzb25fU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFN1YnNjcmlwdGlvblNwZWMgaXMgdGhlIHNwZWMgZm9yIGFuIGV2ZW50IHN1YnNjcmlwdGlvbi5cbiAqXG4gKiBAc2NoZW1hIFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFN1YnNjcmlwdGlvblYyQWxwaGExU3BlYyB7XG4gIC8qKlxuICAgKiBUaGUgb3B0aW9uIHRvIGVuYWJsZSBidWxrIHN1YnNjcmlwdGlvbiBmb3IgdGhpcyB0b3BpYy5cbiAgICpcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25WMkFscGhhMVNwZWMjYnVsa1N1YnNjcmliZVxuICAgKi9cbiAgcmVhZG9ubHkgYnVsa1N1YnNjcmliZT86IFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY0J1bGtTdWJzY3JpYmU7XG5cbiAgLyoqXG4gICAqIFRoZSBvcHRpb25hbCBkZWFkIGxldHRlciBxdWV1ZSBmb3IgdGhpcyB0b3BpYyB0byBzZW5kIGV2ZW50cyB0by5cbiAgICpcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25WMkFscGhhMVNwZWMjZGVhZExldHRlclRvcGljXG4gICAqL1xuICByZWFkb25seSBkZWFkTGV0dGVyVG9waWM/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBvcHRpb25hbCBtZXRhZGF0YSB0byBwcm92aWRlIHRoZSBzdWJzY3JpcHRpb24uXG4gICAqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjI21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIH07XG5cbiAgLyoqXG4gICAqIFRoZSBQdWJTdWIgY29tcG9uZW50IG5hbWUuXG4gICAqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjI3B1YnN1Ym5hbWVcbiAgICovXG4gIHJlYWRvbmx5IHB1YnN1Ym5hbWU6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIFJvdXRlcyBjb25maWd1cmF0aW9uIGZvciB0aGlzIHRvcGljLlxuICAgKlxuICAgKiBAc2NoZW1hIFN1YnNjcmlwdGlvblYyQWxwaGExU3BlYyNyb3V0ZXNcbiAgICovXG4gIHJlYWRvbmx5IHJvdXRlczogU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjUm91dGVzO1xuXG4gIC8qKlxuICAgKiBUaGUgdG9waWMgbmFtZSB0byBzdWJzY3JpYmUgdG8uXG4gICAqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjI3RvcGljXG4gICAqL1xuICByZWFkb25seSB0b3BpYzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdTdWJzY3JpcHRpb25WMkFscGhhMVNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjKG9iajogU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYnVsa1N1YnNjcmliZSc6IHRvSnNvbl9TdWJzY3JpcHRpb25WMkFscGhhMVNwZWNCdWxrU3Vic2NyaWJlKG9iai5idWxrU3Vic2NyaWJlKSxcbiAgICAnZGVhZExldHRlclRvcGljJzogb2JqLmRlYWRMZXR0ZXJUb3BpYyxcbiAgICAnbWV0YWRhdGEnOiAoKG9iai5tZXRhZGF0YSkgPT09IHVuZGVmaW5lZCkgPyB1bmRlZmluZWQgOiAoT2JqZWN0LmVudHJpZXMob2JqLm1ldGFkYXRhKS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pKSxcbiAgICAncHVic3VibmFtZSc6IG9iai5wdWJzdWJuYW1lLFxuICAgICdyb3V0ZXMnOiB0b0pzb25fU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjUm91dGVzKG9iai5yb3V0ZXMpLFxuICAgICd0b3BpYyc6IG9iai50b3BpYyxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBvcHRpb24gdG8gZW5hYmxlIGJ1bGsgc3Vic2NyaXB0aW9uIGZvciB0aGlzIHRvcGljLlxuICpcbiAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjQnVsa1N1YnNjcmliZVxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY0J1bGtTdWJzY3JpYmUge1xuICAvKipcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25WMkFscGhhMVNwZWNCdWxrU3Vic2NyaWJlI2VuYWJsZWRcbiAgICovXG4gIHJlYWRvbmx5IGVuYWJsZWQ6IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjQnVsa1N1YnNjcmliZSNtYXhBd2FpdER1cmF0aW9uTXNcbiAgICovXG4gIHJlYWRvbmx5IG1heEF3YWl0RHVyYXRpb25Ncz86IG51bWJlcjtcblxuICAvKipcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25WMkFscGhhMVNwZWNCdWxrU3Vic2NyaWJlI21heE1lc3NhZ2VzQ291bnRcbiAgICovXG4gIHJlYWRvbmx5IG1heE1lc3NhZ2VzQ291bnQ/OiBudW1iZXI7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1N1YnNjcmlwdGlvblYyQWxwaGExU3BlY0J1bGtTdWJzY3JpYmUnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjQnVsa1N1YnNjcmliZShvYmo6IFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY0J1bGtTdWJzY3JpYmUgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdlbmFibGVkJzogb2JqLmVuYWJsZWQsXG4gICAgJ21heEF3YWl0RHVyYXRpb25Ncyc6IG9iai5tYXhBd2FpdER1cmF0aW9uTXMsXG4gICAgJ21heE1lc3NhZ2VzQ291bnQnOiBvYmoubWF4TWVzc2FnZXNDb3VudCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFRoZSBSb3V0ZXMgY29uZmlndXJhdGlvbiBmb3IgdGhpcyB0b3BpYy5cbiAqXG4gKiBAc2NoZW1hIFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY1JvdXRlc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY1JvdXRlcyB7XG4gIC8qKlxuICAgKiBUaGUgZGVmYXVsdCBwYXRoIGZvciB0aGlzIHRvcGljLlxuICAgKlxuICAgKiBAc2NoZW1hIFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY1JvdXRlcyNkZWZhdWx0XG4gICAqL1xuICByZWFkb25seSBkZWZhdWx0Pzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbGlzdCBvZiBydWxlcyBmb3IgdGhpcyB0b3BpYy5cbiAgICpcbiAgICogQHNjaGVtYSBTdWJzY3JpcHRpb25WMkFscGhhMVNwZWNSb3V0ZXMjcnVsZXNcbiAgICovXG4gIHJlYWRvbmx5IHJ1bGVzPzogU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjUm91dGVzUnVsZXNbXTtcbn1cblxuLyoqXG4gKiBDb252ZXJ0cyBhbiBvYmplY3Qgb2YgdHlwZSAnU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjUm91dGVzJyB0byBKU09OIHJlcHJlc2VudGF0aW9uLlxuICovXG4vKiBlc2xpbnQtZGlzYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5leHBvcnQgZnVuY3Rpb24gdG9Kc29uX1N1YnNjcmlwdGlvblYyQWxwaGExU3BlY1JvdXRlcyhvYmo6IFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY1JvdXRlcyB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIGFueT4gfCB1bmRlZmluZWQge1xuICBpZiAob2JqID09PSB1bmRlZmluZWQpIHsgcmV0dXJuIHVuZGVmaW5lZDsgfVxuICBjb25zdCByZXN1bHQgPSB7XG4gICAgJ2RlZmF1bHQnOiBvYmouZGVmYXVsdCxcbiAgICAncnVsZXMnOiBvYmoucnVsZXM/Lm1hcCh5ID0+IHRvSnNvbl9TdWJzY3JpcHRpb25WMkFscGhhMVNwZWNSb3V0ZXNSdWxlcyh5KSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBSdWxlIGlzIHVzZWQgdG8gc3BlY2lmeSB0aGUgY29uZGl0aW9uIGZvciBzZW5kaW5nXG4gKiBhIG1lc3NhZ2UgdG8gYSBzcGVjaWZpYyBwYXRoLlxuICpcbiAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjUm91dGVzUnVsZXNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBTdWJzY3JpcHRpb25WMkFscGhhMVNwZWNSb3V0ZXNSdWxlcyB7XG4gIC8qKlxuICAgKiBUaGUgb3B0aW9uYWwgQ0VMIGV4cHJlc3Npb24gdXNlZCB0byBtYXRjaCB0aGUgZXZlbnQuXG4gICAqIElmIHRoZSBtYXRjaCBpcyBub3Qgc3BlY2lmaWVkLCB0aGVuIHRoZSByb3V0ZSBpcyBjb25zaWRlcmVkXG4gICAqIHRoZSBkZWZhdWx0LiBUaGUgcnVsZXMgYXJlIHRlc3RlZCBpbiB0aGUgb3JkZXIgc3BlY2lmaWVkLFxuICAgKiBzbyB0aGV5IHNob3VsZCBiZSBkZWZpbmUgZnJvbSBtb3N0LXRvLWxlYXN0IHNwZWNpZmljLlxuICAgKiBUaGUgZGVmYXVsdCByb3V0ZSBzaG91bGQgYXBwZWFyIGxhc3QgaW4gdGhlIGxpc3QuXG4gICAqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjUm91dGVzUnVsZXMjbWF0Y2hcbiAgICovXG4gIHJlYWRvbmx5IG1hdGNoOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFRoZSBwYXRoIGZvciBldmVudHMgdGhhdCBtYXRjaCB0aGlzIHJ1bGUuXG4gICAqXG4gICAqIEBzY2hlbWEgU3Vic2NyaXB0aW9uVjJBbHBoYTFTcGVjUm91dGVzUnVsZXMjcGF0aFxuICAgKi9cbiAgcmVhZG9ubHkgcGF0aDogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdTdWJzY3JpcHRpb25WMkFscGhhMVNwZWNSb3V0ZXNSdWxlcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9TdWJzY3JpcHRpb25WMkFscGhhMVNwZWNSb3V0ZXNSdWxlcyhvYmo6IFN1YnNjcmlwdGlvblYyQWxwaGExU3BlY1JvdXRlc1J1bGVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbWF0Y2gnOiBvYmoubWF0Y2gsXG4gICAgJ3BhdGgnOiBvYmoucGF0aCxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG5cbi8qKlxuICogV29ya2Zsb3dBY2Nlc3NQb2xpY3kgY29udHJvbHMgd2hpY2ggYXBwIElEcyBhcmUgcGVybWl0dGVkIHRvIHNjaGVkdWxlXG5zcGVjaWZpYyB3b3JrZmxvd3MgYW5kIGFjdGl2aXRpZXMgb24gYSB0YXJnZXQgYXBwbGljYXRpb24uXG4gKlxuICogQHNjaGVtYSBXb3JrZmxvd0FjY2Vzc1BvbGljeVxuICovXG5leHBvcnQgY2xhc3MgV29ya2Zsb3dBY2Nlc3NQb2xpY3kgZXh0ZW5kcyBBcGlPYmplY3Qge1xuICAvKipcbiAgICogUmV0dXJucyB0aGUgYXBpVmVyc2lvbiBhbmQga2luZCBmb3IgXCJXb3JrZmxvd0FjY2Vzc1BvbGljeVwiXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIHJlYWRvbmx5IEdWSzogR3JvdXBWZXJzaW9uS2luZCA9IHtcbiAgICBhcGlWZXJzaW9uOiAnZGFwci5pby92MWFscGhhMScsXG4gICAga2luZDogJ1dvcmtmbG93QWNjZXNzUG9saWN5JyxcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIGEgS3ViZXJuZXRlcyBtYW5pZmVzdCBmb3IgXCJXb3JrZmxvd0FjY2Vzc1BvbGljeVwiLlxuICAgKlxuICAgKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGlubGluZSByZXNvdXJjZSBtYW5pZmVzdHMgaW5zaWRlIG90aGVyIG9iamVjdHMgKGUuZy4gYXMgdGVtcGxhdGVzKS5cbiAgICpcbiAgICogQHBhcmFtIHByb3BzIGluaXRpYWxpemF0aW9uIHByb3BzXG4gICAqL1xuICBwdWJsaWMgc3RhdGljIG1hbmlmZXN0KHByb3BzOiBXb3JrZmxvd0FjY2Vzc1BvbGljeVByb3BzID0ge30pOiBhbnkge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5Xb3JrZmxvd0FjY2Vzc1BvbGljeS5HVkssXG4gICAgICAuLi50b0pzb25fV29ya2Zsb3dBY2Nlc3NQb2xpY3lQcm9wcyhwcm9wcyksXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWZpbmVzIGEgXCJXb3JrZmxvd0FjY2Vzc1BvbGljeVwiIEFQSSBvYmplY3RcbiAgICogQHBhcmFtIHNjb3BlIHRoZSBzY29wZSBpbiB3aGljaCB0byBkZWZpbmUgdGhpcyBvYmplY3RcbiAgICogQHBhcmFtIGlkIGEgc2NvcGUtbG9jYWwgbmFtZSBmb3IgdGhlIG9iamVjdFxuICAgKiBAcGFyYW0gcHJvcHMgaW5pdGlhbGl6YXRpb24gcHJvcHNcbiAgICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBwcm9wczogV29ya2Zsb3dBY2Nlc3NQb2xpY3lQcm9wcyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICAuLi5Xb3JrZmxvd0FjY2Vzc1BvbGljeS5HVkssXG4gICAgICAuLi5wcm9wcyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW5kZXJzIHRoZSBvYmplY3QgdG8gS3ViZXJuZXRlcyBKU09OLlxuICAgKi9cbiAgcHVibGljIG92ZXJyaWRlIHRvSnNvbigpOiBhbnkge1xuICAgIGNvbnN0IHJlc29sdmVkID0gc3VwZXIudG9Kc29uKCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgLi4uV29ya2Zsb3dBY2Nlc3NQb2xpY3kuR1ZLLFxuICAgICAgLi4udG9Kc29uX1dvcmtmbG93QWNjZXNzUG9saWN5UHJvcHMocmVzb2x2ZWQpLFxuICAgIH07XG4gIH1cbn1cblxuLyoqXG4gKiBXb3JrZmxvd0FjY2Vzc1BvbGljeSBjb250cm9scyB3aGljaCBhcHAgSURzIGFyZSBwZXJtaXR0ZWQgdG8gc2NoZWR1bGVcbiAqIHNwZWNpZmljIHdvcmtmbG93cyBhbmQgYWN0aXZpdGllcyBvbiBhIHRhcmdldCBhcHBsaWNhdGlvbi5cbiAqXG4gKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5XG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgV29ya2Zsb3dBY2Nlc3NQb2xpY3lQcm9wcyB7XG4gIC8qKlxuICAgKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5I21ldGFkYXRhXG4gICAqL1xuICByZWFkb25seSBtZXRhZGF0YT86IEFwaU9iamVjdE1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5I3Njb3Blc1xuICAgKi9cbiAgcmVhZG9ubHkgc2NvcGVzPzogc3RyaW5nW107XG5cbiAgLyoqXG4gICAqIFdvcmtmbG93QWNjZXNzUG9saWN5U3BlYyBkZWZpbmVzIHRoZSBkZXNpcmVkIHN0YXRlIG9mIFdvcmtmbG93QWNjZXNzUG9saWN5LlxuICAgKlxuICAgKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5I3NwZWNcbiAgICovXG4gIHJlYWRvbmx5IHNwZWM/OiBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWM7XG59XG5cbi8qKlxuICogQ29udmVydHMgYW4gb2JqZWN0IG9mIHR5cGUgJ1dvcmtmbG93QWNjZXNzUG9saWN5UHJvcHMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fV29ya2Zsb3dBY2Nlc3NQb2xpY3lQcm9wcyhvYmo6IFdvcmtmbG93QWNjZXNzUG9saWN5UHJvcHMgfCB1bmRlZmluZWQpOiBSZWNvcmQ8c3RyaW5nLCBhbnk+IHwgdW5kZWZpbmVkIHtcbiAgaWYgKG9iaiA9PT0gdW5kZWZpbmVkKSB7IHJldHVybiB1bmRlZmluZWQ7IH1cbiAgY29uc3QgcmVzdWx0ID0ge1xuICAgICdtZXRhZGF0YSc6IG9iai5tZXRhZGF0YSxcbiAgICAnc2NvcGVzJzogb2JqLnNjb3Blcz8ubWFwKHkgPT4geSksXG4gICAgJ3NwZWMnOiB0b0pzb25fV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjKG9iai5zcGVjKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIFdvcmtmbG93QWNjZXNzUG9saWN5U3BlYyBkZWZpbmVzIHRoZSBkZXNpcmVkIHN0YXRlIG9mIFdvcmtmbG93QWNjZXNzUG9saWN5LlxuICpcbiAqIEBzY2hlbWEgV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjIHtcbiAgLyoqXG4gICAqIFJ1bGVzIGRlZmluZXMgdGhlIGFsbG93LWxpc3Qgb2Ygd2hpY2ggY2FsbGVycyBjYW4gcGVyZm9ybSB3aGljaCBvcGVyYXRpb25zLlxuICAgKlxuICAgKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5U3BlYyNydWxlc1xuICAgKi9cbiAgcmVhZG9ubHkgcnVsZXM/OiBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjKG9iajogV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAncnVsZXMnOiBvYmoucnVsZXM/Lm1hcCh5ID0+IHRvSnNvbl9Xb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlcyh5KSksXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBXb3JrZmxvd0FjY2Vzc1BvbGljeVJ1bGUgZ3JhbnRzIHRoZSBsaXN0ZWQgY2FsbGVycyBhY2Nlc3MgdG8gdGhlIGxpc3RlZFxuICogd29ya2Zsb3dzIGFuZC9vciBhY3Rpdml0aWVzLiBQcmVzZW5jZSBvZiBhIG1hdGNoaW5nIHJ1bGUgZ3JhbnRzIGFjY2VzczsgaWZcbiAqIG5vIHJ1bGUgbWF0Y2hlcywgdGhlIGNhbGwgaXMgZGVuaWVkLiBBdCBsZWFzdCBvbmUgb2Ygd29ya2Zsb3dzIG9yXG4gKiBhY3Rpdml0aWVzIG11c3QgYmUgc2V0LlxuICpcbiAqIEBzY2hlbWEgV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlcyB7XG4gIC8qKlxuICAgKiBBY3Rpdml0aWVzIGFyZSB0aGUgYWN0aXZpdHkgcnVsZXMgdGhhdCB0aGUgbWF0Y2hlZCBjYWxsZXJzIGFyZSBhbGxvd2VkLlxuICAgKlxuICAgKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzI2FjdGl2aXRpZXNcbiAgICovXG4gIHJlYWRvbmx5IGFjdGl2aXRpZXM/OiBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc0FjdGl2aXRpZXNbXTtcblxuICAvKipcbiAgICogQ2FsbGVycyB0aGF0IHRoaXMgcnVsZSBhcHBsaWVzIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzI2NhbGxlcnNcbiAgICovXG4gIHJlYWRvbmx5IGNhbGxlcnM6IFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzQ2FsbGVyc1tdO1xuXG4gIC8qKlxuICAgKiBXb3JrZmxvd3MgYXJlIHRoZSB3b3JrZmxvdyBydWxlcyB0aGF0IHRoZSBtYXRjaGVkIGNhbGxlcnMgYXJlIGFsbG93ZWQuXG4gICAqXG4gICAqIEBzY2hlbWEgV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXMjd29ya2Zsb3dzXG4gICAqL1xuICByZWFkb25seSB3b3JrZmxvd3M/OiBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc1dvcmtmbG93c1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlcycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Xb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlcyhvYmo6IFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYWN0aXZpdGllcyc6IG9iai5hY3Rpdml0aWVzPy5tYXAoeSA9PiB0b0pzb25fV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNBY3Rpdml0aWVzKHkpKSxcbiAgICAnY2FsbGVycyc6IG9iai5jYWxsZXJzPy5tYXAoeSA9PiB0b0pzb25fV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNDYWxsZXJzKHkpKSxcbiAgICAnd29ya2Zsb3dzJzogb2JqLndvcmtmbG93cz8ubWFwKHkgPT4gdG9Kc29uX1dvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzV29ya2Zsb3dzKHkpKSxcbiAgfTtcbiAgLy8gZmlsdGVyIHVuZGVmaW5lZCB2YWx1ZXNcbiAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHJlc3VsdCkucmVkdWNlKChyLCBpKSA9PiAoaVsxXSA9PT0gdW5kZWZpbmVkKSA/IHIgOiAoeyAuLi5yLCBbaVswXV06IGlbMV0gfSksIHt9KTtcbn1cbi8qIGVzbGludC1lbmFibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuXG4vKipcbiAqIEFjdGl2aXR5UnVsZSBncmFudHMgdGhlIG1hdGNoZWQgY2FsbGVycyBhY2Nlc3MgdG8gc2NoZWR1bGUgdGhlIGFjdGl2aXR5XG4gKiB3aG9zZSBuYW1lIG1hdGNoZXMgTmFtZSAoZXhhY3Qgb3IgZ2xvYikuIEFjdGl2aXRpZXMgb25seSBoYXZlIG9uZVxuICogb3BlcmF0aW9uIChzY2hlZHVsZSkuXG4gKlxuICogQHNjaGVtYSBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc0FjdGl2aXRpZXNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc0FjdGl2aXRpZXMge1xuICAvKipcbiAgICogTmFtZSBpcyB0aGUgZXhhY3QgbmFtZSBvciBnbG9iIHBhdHRlcm4gZm9yIHRoZSBhY3Rpdml0eS5cbiAgICpcbiAgICogQHNjaGVtYSBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc0FjdGl2aXRpZXMjbmFtZVxuICAgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc0FjdGl2aXRpZXMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNBY3Rpdml0aWVzKG9iajogV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNBY3Rpdml0aWVzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogV29ya2Zsb3dDYWxsZXIgaWRlbnRpZmllcyBhIGNhbGxpbmcgYXBwbGljYXRpb24uXG4gKlxuICogQHNjaGVtYSBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc0NhbGxlcnNcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc0NhbGxlcnMge1xuICAvKipcbiAgICogQXBwSUQgaXMgdGhlIERhcHIgYXBwIElEIG9mIHRoZSBjYWxsZXIuXG4gICAqXG4gICAqIEBzY2hlbWEgV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNDYWxsZXJzI2FwcElEXG4gICAqL1xuICByZWFkb25seSBhcHBJZDogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc0NhbGxlcnMnIHRvIEpTT04gcmVwcmVzZW50YXRpb24uXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cbmV4cG9ydCBmdW5jdGlvbiB0b0pzb25fV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNDYWxsZXJzKG9iajogV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNDYWxsZXJzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnYXBwSUQnOiBvYmouYXBwSWQsXG4gIH07XG4gIC8vIGZpbHRlciB1bmRlZmluZWQgdmFsdWVzXG4gIHJldHVybiBPYmplY3QuZW50cmllcyhyZXN1bHQpLnJlZHVjZSgociwgaSkgPT4gKGlbMV0gPT09IHVuZGVmaW5lZCkgPyByIDogKHsgLi4uciwgW2lbMF1dOiBpWzFdIH0pLCB7fSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlIG1heC1sZW4sIEBzdHlsaXN0aWMvbWF4LWxlbiwgcXVvdGUtcHJvcHMsIEBzdHlsaXN0aWMvcXVvdGUtcHJvcHMgKi9cblxuLyoqXG4gKiBXb3JrZmxvd1J1bGUgZ3JhbnRzIHRoZSBtYXRjaGVkIGNhbGxlcnMgYWNjZXNzIHRvIHRoZSBsaXN0ZWQgb3BlcmF0aW9ucyBvblxuICogd29ya2Zsb3dzIHdob3NlIG5hbWUgbWF0Y2hlcyBOYW1lIChleGFjdCBvciBnbG9iKS5cbiAqXG4gKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzV29ya2Zsb3dzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNXb3JrZmxvd3Mge1xuICAvKipcbiAgICogTmFtZSBpcyB0aGUgZXhhY3QgbmFtZSBvciBnbG9iIHBhdHRlcm4gZm9yIHRoZSB3b3JrZmxvdy5cbiAgICpcbiAgICogQHNjaGVtYSBXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc1dvcmtmbG93cyNuYW1lXG4gICAqL1xuICByZWFkb25seSBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIE9wZXJhdGlvbnMgaXMgdGhlIHNldCBvZiBvcGVyYXRpb25zIHRoaXMgcnVsZSBhcHBsaWVzIHRvLlxuICAgKlxuICAgKiBAc2NoZW1hIFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzV29ya2Zsb3dzI29wZXJhdGlvbnNcbiAgICovXG4gIHJlYWRvbmx5IG9wZXJhdGlvbnM6IFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzV29ya2Zsb3dzT3BlcmF0aW9uc1tdO1xufVxuXG4vKipcbiAqIENvbnZlcnRzIGFuIG9iamVjdCBvZiB0eXBlICdXb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc1dvcmtmbG93cycgdG8gSlNPTiByZXByZXNlbnRhdGlvbi5cbiAqL1xuLyogZXNsaW50LWRpc2FibGUgbWF4LWxlbiwgQHN0eWxpc3RpYy9tYXgtbGVuLCBxdW90ZS1wcm9wcywgQHN0eWxpc3RpYy9xdW90ZS1wcm9wcyAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvSnNvbl9Xb3JrZmxvd0FjY2Vzc1BvbGljeVNwZWNSdWxlc1dvcmtmbG93cyhvYmo6IFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzV29ya2Zsb3dzIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgYW55PiB8IHVuZGVmaW5lZCB7XG4gIGlmIChvYmogPT09IHVuZGVmaW5lZCkgeyByZXR1cm4gdW5kZWZpbmVkOyB9XG4gIGNvbnN0IHJlc3VsdCA9IHtcbiAgICAnbmFtZSc6IG9iai5uYW1lLFxuICAgICdvcGVyYXRpb25zJzogb2JqLm9wZXJhdGlvbnM/Lm1hcCh5ID0+IHkpLFxuICB9O1xuICAvLyBmaWx0ZXIgdW5kZWZpbmVkIHZhbHVlc1xuICByZXR1cm4gT2JqZWN0LmVudHJpZXMocmVzdWx0KS5yZWR1Y2UoKHIsIGkpID0+IChpWzFdID09PSB1bmRlZmluZWQpID8gciA6ICh7IC4uLnIsIFtpWzBdXTogaVsxXSB9KSwge30pO1xufVxuLyogZXNsaW50LWVuYWJsZSBtYXgtbGVuLCBAc3R5bGlzdGljL21heC1sZW4sIHF1b3RlLXByb3BzLCBAc3R5bGlzdGljL3F1b3RlLXByb3BzICovXG5cbi8qKlxuICogV29ya2Zsb3dPcGVyYXRpb24gaXMgdGhlIHNwZWNpZmljIHdvcmtmbG93IG9wZXJhdGlvbiBiZWluZyBjb250cm9sbGVkLlxuICpcbiAqIEBzY2hlbWEgV29ya2Zsb3dBY2Nlc3NQb2xpY3lTcGVjUnVsZXNXb3JrZmxvd3NPcGVyYXRpb25zXG4gKi9cbmV4cG9ydCBlbnVtIFdvcmtmbG93QWNjZXNzUG9saWN5U3BlY1J1bGVzV29ya2Zsb3dzT3BlcmF0aW9ucyB7XG4gIC8qKiBzY2hlZHVsZSAqL1xuICBTQ0hFRFVMRSA9IFwic2NoZWR1bGVcIixcbiAgLyoqIHRlcm1pbmF0ZSAqL1xuICBURVJNSU5BVEUgPSBcInRlcm1pbmF0ZVwiLFxuICAvKiogcmFpc2UgKi9cbiAgUkFJU0UgPSBcInJhaXNlXCIsXG4gIC8qKiBwYXVzZSAqL1xuICBQQVVTRSA9IFwicGF1c2VcIixcbiAgLyoqIHJlc3VtZSAqL1xuICBSRVNVTUUgPSBcInJlc3VtZVwiLFxuICAvKiogcHVyZ2UgKi9cbiAgUFVSR0UgPSBcInB1cmdlXCIsXG4gIC8qKiBnZXQgKi9cbiAgR0VUID0gXCJnZXRcIixcbiAgLyoqIHJlcnVuICovXG4gIFJFUlVOID0gXCJyZXJ1blwiLFxufVxuXG4iXX0=