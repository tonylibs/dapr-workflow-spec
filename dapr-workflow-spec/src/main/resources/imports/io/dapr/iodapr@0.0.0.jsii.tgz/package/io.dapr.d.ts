import { ApiObject, ApiObjectMetadata, GroupVersionKind } from 'cdk8s';
import { Construct } from 'constructs';
/**
 * Component describes an Dapr component type.
 *
 * @schema Component
 */
export declare class Component extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Component"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Component".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: ComponentProps): any;
    /**
     * Defines a "Component" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: ComponentProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * Component describes an Dapr component type.
 *
 * @schema Component
 */
export interface ComponentProps {
    /**
     * @schema Component#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * Auth represents authentication details for the component.
     *
     * @schema Component#auth
     */
    readonly auth?: ComponentAuth;
    /**
     * @schema Component#scopes
     */
    readonly scopes?: string[];
    /**
     * ComponentSpec is the spec for a component.
     *
     * @schema Component#spec
     */
    readonly spec?: ComponentSpec;
}
/**
 * Converts an object of type 'ComponentProps' to JSON representation.
 */
export declare function toJson_ComponentProps(obj: ComponentProps | undefined): Record<string, any> | undefined;
/**
 * Auth represents authentication details for the component.
 *
 * @schema ComponentAuth
 */
export interface ComponentAuth {
    /**
     * @schema ComponentAuth#secretStore
     */
    readonly secretStore: string;
}
/**
 * Converts an object of type 'ComponentAuth' to JSON representation.
 */
export declare function toJson_ComponentAuth(obj: ComponentAuth | undefined): Record<string, any> | undefined;
/**
 * ComponentSpec is the spec for a component.
 *
 * @schema ComponentSpec
 */
export interface ComponentSpec {
    /**
     * @schema ComponentSpec#ignoreErrors
     */
    readonly ignoreErrors?: boolean;
    /**
     * @schema ComponentSpec#initTimeout
     */
    readonly initTimeout?: string;
    /**
     * @schema ComponentSpec#metadata
     */
    readonly metadata: ComponentSpecMetadata[];
    /**
     * @schema ComponentSpec#type
     */
    readonly type: string;
    /**
     * @schema ComponentSpec#version
     */
    readonly version: string;
}
/**
 * Converts an object of type 'ComponentSpec' to JSON representation.
 */
export declare function toJson_ComponentSpec(obj: ComponentSpec | undefined): Record<string, any> | undefined;
/**
 * NameValuePair is a name/value pair.
 *
 * @schema ComponentSpecMetadata
 */
export interface ComponentSpecMetadata {
    /**
     * EnvRef is the name of an environmental variable to read the value from.
     *
     * @schema ComponentSpecMetadata#envRef
     */
    readonly envRef?: string;
    /**
     * Name of the property.
     *
     * @schema ComponentSpecMetadata#name
     */
    readonly name: string;
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema ComponentSpecMetadata#secretKeyRef
     */
    readonly secretKeyRef?: ComponentSpecMetadataSecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema ComponentSpecMetadata#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'ComponentSpecMetadata' to JSON representation.
 */
export declare function toJson_ComponentSpecMetadata(obj: ComponentSpecMetadata | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema ComponentSpecMetadataSecretKeyRef
 */
export interface ComponentSpecMetadataSecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema ComponentSpecMetadataSecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema ComponentSpecMetadataSecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'ComponentSpecMetadataSecretKeyRef' to JSON representation.
 */
export declare function toJson_ComponentSpecMetadataSecretKeyRef(obj: ComponentSpecMetadataSecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * Configuration describes an Dapr configuration setting.
 *
 * @schema Configuration
 */
export declare class Configuration extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Configuration"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Configuration".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: ConfigurationProps): any;
    /**
     * Defines a "Configuration" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: ConfigurationProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * Configuration describes an Dapr configuration setting.
 *
 * @schema Configuration
 */
export interface ConfigurationProps {
    /**
     * @schema Configuration#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * ConfigurationSpec is the spec for a configuration.
     *
     * @schema Configuration#spec
     */
    readonly spec?: ConfigurationSpec;
}
/**
 * Converts an object of type 'ConfigurationProps' to JSON representation.
 */
export declare function toJson_ConfigurationProps(obj: ConfigurationProps | undefined): Record<string, any> | undefined;
/**
 * ConfigurationSpec is the spec for a configuration.
 *
 * @schema ConfigurationSpec
 */
export interface ConfigurationSpec {
    /**
     * AccessControlSpec is the spec object in ConfigurationSpec.
     *
     * @schema ConfigurationSpec#accessControl
     */
    readonly accessControl?: ConfigurationSpecAccessControl;
    /**
     * APISpec describes the configuration for Dapr APIs.
     *
     * @schema ConfigurationSpec#api
     */
    readonly api?: ConfigurationSpecApi;
    /**
     * PipelineSpec defines the middleware pipeline.
     *
     * @schema ConfigurationSpec#appHttpPipeline
     */
    readonly appHttpPipeline?: ConfigurationSpecAppHttpPipeline;
    /**
     * ComponentsSpec describes the configuration for Dapr components
     *
     * @schema ConfigurationSpec#components
     */
    readonly components?: ConfigurationSpecComponents;
    /**
     * @schema ConfigurationSpec#features
     */
    readonly features?: ConfigurationSpecFeatures[];
    /**
     * PipelineSpec defines the middleware pipeline.
     *
     * @schema ConfigurationSpec#httpPipeline
     */
    readonly httpPipeline?: ConfigurationSpecHttpPipeline;
    /**
     * LoggingSpec defines the configuration for logging.
     *
     * @schema ConfigurationSpec#logging
     */
    readonly logging?: ConfigurationSpecLogging;
    /**
     * MetricSpec defines metrics configuration.
     *
     * @schema ConfigurationSpec#metric
     */
    readonly metric?: ConfigurationSpecMetric;
    /**
     * MetricSpec defines metrics configuration.
     *
     * @schema ConfigurationSpec#metrics
     */
    readonly metrics?: ConfigurationSpecMetrics;
    /**
     * MTLSSpec defines mTLS configuration.
     *
     * @schema ConfigurationSpec#mtls
     */
    readonly mtls?: ConfigurationSpecMtls;
    /**
     * NameResolutionSpec is the spec for name resolution configuration.
     *
     * @schema ConfigurationSpec#nameResolution
     */
    readonly nameResolution?: ConfigurationSpecNameResolution;
    /**
     * SecretsSpec is the spec for secrets configuration.
     *
     * @schema ConfigurationSpec#secrets
     */
    readonly secrets?: ConfigurationSpecSecrets;
    /**
     * TracingSpec defines distributed tracing configuration.
     *
     * @schema ConfigurationSpec#tracing
     */
    readonly tracing?: ConfigurationSpecTracing;
    /**
     * WasmSpec describes the security profile for all Dapr Wasm components.
     *
     * @schema ConfigurationSpec#wasm
     */
    readonly wasm?: ConfigurationSpecWasm;
    /**
     * WorkflowSpec defines the configuration for Dapr workflows.
     *
     * @schema ConfigurationSpec#workflow
     */
    readonly workflow?: ConfigurationSpecWorkflow;
}
/**
 * Converts an object of type 'ConfigurationSpec' to JSON representation.
 */
export declare function toJson_ConfigurationSpec(obj: ConfigurationSpec | undefined): Record<string, any> | undefined;
/**
 * AccessControlSpec is the spec object in ConfigurationSpec.
 *
 * @schema ConfigurationSpecAccessControl
 */
export interface ConfigurationSpecAccessControl {
    /**
     * @schema ConfigurationSpecAccessControl#defaultAction
     */
    readonly defaultAction?: string;
    /**
     * @schema ConfigurationSpecAccessControl#policies
     */
    readonly policies?: ConfigurationSpecAccessControlPolicies[];
    /**
     * @schema ConfigurationSpecAccessControl#trustDomain
     */
    readonly trustDomain?: string;
}
/**
 * Converts an object of type 'ConfigurationSpecAccessControl' to JSON representation.
 */
export declare function toJson_ConfigurationSpecAccessControl(obj: ConfigurationSpecAccessControl | undefined): Record<string, any> | undefined;
/**
 * APISpec describes the configuration for Dapr APIs.
 *
 * @schema ConfigurationSpecApi
 */
export interface ConfigurationSpecApi {
    /**
     * List of allowed APIs. Can be used in conjunction with denied.
     *
     * @schema ConfigurationSpecApi#allowed
     */
    readonly allowed?: ConfigurationSpecApiAllowed[];
    /**
     * List of denied APIs. Can be used in conjunction with allowed.
     *
     * @schema ConfigurationSpecApi#denied
     */
    readonly denied?: ConfigurationSpecApiDenied[];
}
/**
 * Converts an object of type 'ConfigurationSpecApi' to JSON representation.
 */
export declare function toJson_ConfigurationSpecApi(obj: ConfigurationSpecApi | undefined): Record<string, any> | undefined;
/**
 * PipelineSpec defines the middleware pipeline.
 *
 * @schema ConfigurationSpecAppHttpPipeline
 */
export interface ConfigurationSpecAppHttpPipeline {
    /**
     * @schema ConfigurationSpecAppHttpPipeline#handlers
     */
    readonly handlers: ConfigurationSpecAppHttpPipelineHandlers[];
}
/**
 * Converts an object of type 'ConfigurationSpecAppHttpPipeline' to JSON representation.
 */
export declare function toJson_ConfigurationSpecAppHttpPipeline(obj: ConfigurationSpecAppHttpPipeline | undefined): Record<string, any> | undefined;
/**
 * ComponentsSpec describes the configuration for Dapr components
 *
 * @schema ConfigurationSpecComponents
 */
export interface ConfigurationSpecComponents {
    /**
     * Denylist of component types that cannot be instantiated
     *
     * @schema ConfigurationSpecComponents#deny
     */
    readonly deny?: string[];
}
/**
 * Converts an object of type 'ConfigurationSpecComponents' to JSON representation.
 */
export declare function toJson_ConfigurationSpecComponents(obj: ConfigurationSpecComponents | undefined): Record<string, any> | undefined;
/**
 * FeatureSpec defines the features that are enabled/disabled.
 *
 * @schema ConfigurationSpecFeatures
 */
export interface ConfigurationSpecFeatures {
    /**
     * @schema ConfigurationSpecFeatures#enabled
     */
    readonly enabled: boolean;
    /**
     * @schema ConfigurationSpecFeatures#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'ConfigurationSpecFeatures' to JSON representation.
 */
export declare function toJson_ConfigurationSpecFeatures(obj: ConfigurationSpecFeatures | undefined): Record<string, any> | undefined;
/**
 * PipelineSpec defines the middleware pipeline.
 *
 * @schema ConfigurationSpecHttpPipeline
 */
export interface ConfigurationSpecHttpPipeline {
    /**
     * @schema ConfigurationSpecHttpPipeline#handlers
     */
    readonly handlers: ConfigurationSpecHttpPipelineHandlers[];
}
/**
 * Converts an object of type 'ConfigurationSpecHttpPipeline' to JSON representation.
 */
export declare function toJson_ConfigurationSpecHttpPipeline(obj: ConfigurationSpecHttpPipeline | undefined): Record<string, any> | undefined;
/**
 * LoggingSpec defines the configuration for logging.
 *
 * @schema ConfigurationSpecLogging
 */
export interface ConfigurationSpecLogging {
    /**
     * Configure API logging.
     *
     * @schema ConfigurationSpecLogging#apiLogging
     */
    readonly apiLogging?: ConfigurationSpecLoggingApiLogging;
}
/**
 * Converts an object of type 'ConfigurationSpecLogging' to JSON representation.
 */
export declare function toJson_ConfigurationSpecLogging(obj: ConfigurationSpecLogging | undefined): Record<string, any> | undefined;
/**
 * MetricSpec defines metrics configuration.
 *
 * @schema ConfigurationSpecMetric
 */
export interface ConfigurationSpecMetric {
    /**
     * @schema ConfigurationSpecMetric#enabled
     */
    readonly enabled: boolean;
    /**
     * MetricHTTP defines configuration for metrics for the HTTP server
     *
     * @schema ConfigurationSpecMetric#http
     */
    readonly http?: ConfigurationSpecMetricHttp;
    /**
     * The LatencyDistributionBuckets variable specifies the latency distribution buckets (in milliseconds) used for
     * histograms in the application. If this variable is not set or left empty, the application will default to using the standard histogram buckets.
     * The default histogram latency buckets (in milliseconds) are as follows:
     * 1, 2, 3, 4, 5, 6, 8, 10, 13, 16, 20, 25, 30, 40, 50, 65, 80, 100, 130, 160, 200, 250, 300, 400, 500, 650, 800, 1,000, 2,000, 5,000, 10,000, 20,000, 50,000, 100,000.
     *
     * @schema ConfigurationSpecMetric#latencyDistributionBuckets
     */
    readonly latencyDistributionBuckets?: number[];
    /**
     * @schema ConfigurationSpecMetric#recordErrorCodes
     */
    readonly recordErrorCodes?: boolean;
    /**
     * @schema ConfigurationSpecMetric#rules
     */
    readonly rules?: ConfigurationSpecMetricRules[];
}
/**
 * Converts an object of type 'ConfigurationSpecMetric' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMetric(obj: ConfigurationSpecMetric | undefined): Record<string, any> | undefined;
/**
 * MetricSpec defines metrics configuration.
 *
 * @schema ConfigurationSpecMetrics
 */
export interface ConfigurationSpecMetrics {
    /**
     * @schema ConfigurationSpecMetrics#enabled
     */
    readonly enabled: boolean;
    /**
     * MetricHTTP defines configuration for metrics for the HTTP server
     *
     * @schema ConfigurationSpecMetrics#http
     */
    readonly http?: ConfigurationSpecMetricsHttp;
    /**
     * The LatencyDistributionBuckets variable specifies the latency distribution buckets (in milliseconds) used for
     * histograms in the application. If this variable is not set or left empty, the application will default to using the standard histogram buckets.
     * The default histogram latency buckets (in milliseconds) are as follows:
     * 1, 2, 3, 4, 5, 6, 8, 10, 13, 16, 20, 25, 30, 40, 50, 65, 80, 100, 130, 160, 200, 250, 300, 400, 500, 650, 800, 1,000, 2,000, 5,000, 10,000, 20,000, 50,000, 100,000.
     *
     * @schema ConfigurationSpecMetrics#latencyDistributionBuckets
     */
    readonly latencyDistributionBuckets?: number[];
    /**
     * @schema ConfigurationSpecMetrics#recordErrorCodes
     */
    readonly recordErrorCodes?: boolean;
    /**
     * @schema ConfigurationSpecMetrics#rules
     */
    readonly rules?: ConfigurationSpecMetricsRules[];
}
/**
 * Converts an object of type 'ConfigurationSpecMetrics' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMetrics(obj: ConfigurationSpecMetrics | undefined): Record<string, any> | undefined;
/**
 * MTLSSpec defines mTLS configuration.
 *
 * @schema ConfigurationSpecMtls
 */
export interface ConfigurationSpecMtls {
    /**
     * @schema ConfigurationSpecMtls#allowedClockSkew
     */
    readonly allowedClockSkew?: string;
    /**
     * @schema ConfigurationSpecMtls#controlPlaneTrustDomain
     */
    readonly controlPlaneTrustDomain: string;
    /**
     * @schema ConfigurationSpecMtls#enabled
     */
    readonly enabled: boolean;
    /**
     * @schema ConfigurationSpecMtls#sentryAddress
     */
    readonly sentryAddress: string;
    /**
     * Additional token validators to use.
     * When Dapr is running in Kubernetes mode, this is in addition to the built-in "kubernetes" validator.
     * In self-hosted mode, enabling a custom validator will disable the built-in "insecure" validator.
     *
     * @schema ConfigurationSpecMtls#tokenValidators
     */
    readonly tokenValidators?: ConfigurationSpecMtlsTokenValidators[];
    /**
     * @schema ConfigurationSpecMtls#workloadCertTTL
     */
    readonly workloadCertTtl?: string;
}
/**
 * Converts an object of type 'ConfigurationSpecMtls' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMtls(obj: ConfigurationSpecMtls | undefined): Record<string, any> | undefined;
/**
 * NameResolutionSpec is the spec for name resolution configuration.
 *
 * @schema ConfigurationSpecNameResolution
 */
export interface ConfigurationSpecNameResolution {
    /**
     * @schema ConfigurationSpecNameResolution#component
     */
    readonly component: string;
    /**
     * DynamicValue is a dynamic value struct for the component.metadata pair value.
     *
     * @schema ConfigurationSpecNameResolution#configuration
     */
    readonly configuration: any;
    /**
     * @schema ConfigurationSpecNameResolution#version
     */
    readonly version: string;
}
/**
 * Converts an object of type 'ConfigurationSpecNameResolution' to JSON representation.
 */
export declare function toJson_ConfigurationSpecNameResolution(obj: ConfigurationSpecNameResolution | undefined): Record<string, any> | undefined;
/**
 * SecretsSpec is the spec for secrets configuration.
 *
 * @schema ConfigurationSpecSecrets
 */
export interface ConfigurationSpecSecrets {
    /**
     * @schema ConfigurationSpecSecrets#scopes
     */
    readonly scopes: ConfigurationSpecSecretsScopes[];
}
/**
 * Converts an object of type 'ConfigurationSpecSecrets' to JSON representation.
 */
export declare function toJson_ConfigurationSpecSecrets(obj: ConfigurationSpecSecrets | undefined): Record<string, any> | undefined;
/**
 * TracingSpec defines distributed tracing configuration.
 *
 * @schema ConfigurationSpecTracing
 */
export interface ConfigurationSpecTracing {
    /**
     * OtelSpec defines Otel exporter configurations.
     *
     * @schema ConfigurationSpecTracing#otel
     */
    readonly otel?: ConfigurationSpecTracingOtel;
    /**
     * @schema ConfigurationSpecTracing#samplingRate
     */
    readonly samplingRate: string;
    /**
     * @schema ConfigurationSpecTracing#stdout
     */
    readonly stdout?: boolean;
    /**
     * ZipkinSpec defines Zipkin trace configurations.
     *
     * @schema ConfigurationSpecTracing#zipkin
     */
    readonly zipkin?: ConfigurationSpecTracingZipkin;
}
/**
 * Converts an object of type 'ConfigurationSpecTracing' to JSON representation.
 */
export declare function toJson_ConfigurationSpecTracing(obj: ConfigurationSpecTracing | undefined): Record<string, any> | undefined;
/**
 * WasmSpec describes the security profile for all Dapr Wasm components.
 *
 * @schema ConfigurationSpecWasm
 */
export interface ConfigurationSpecWasm {
    /**
     * Force enabling strict sandbox mode for all WASM components.
     * When this is enabled, WASM components always run in strict mode regardless of their configuration.
     * Strict mode enhances security of the WASM sandbox by limiting access to certain capabilities such as real-time clocks and random number generators.
     *
     * @schema ConfigurationSpecWasm#strictSandbox
     */
    readonly strictSandbox?: boolean;
}
/**
 * Converts an object of type 'ConfigurationSpecWasm' to JSON representation.
 */
export declare function toJson_ConfigurationSpecWasm(obj: ConfigurationSpecWasm | undefined): Record<string, any> | undefined;
/**
 * WorkflowSpec defines the configuration for Dapr workflows.
 *
 * @schema ConfigurationSpecWorkflow
 */
export interface ConfigurationSpecWorkflow {
    /**
     * activityConcurrencyLimits defines per-activity-name concurrency limits
     * enforced globally across all replicas by the scheduler.
     *
     * @schema ConfigurationSpecWorkflow#activityConcurrencyLimits
     */
    readonly activityConcurrencyLimits?: ConfigurationSpecWorkflowActivityConcurrencyLimits[];
    /**
     * globalMaxConcurrentActivityInvocations is the maximum number of concurrent
     * activity invocations across all replicas, enforced by the scheduler.
     * If omitted, no global maximum will be enforced.
     *
     * @schema ConfigurationSpecWorkflow#globalMaxConcurrentActivityInvocations
     */
    readonly globalMaxConcurrentActivityInvocations?: number;
    /**
     * globalMaxConcurrentWorkflowInvocations is the maximum number of concurrent
     * workflow invocations across all replicas, enforced by the scheduler.
     * If omitted, no global maximum will be enforced.
     *
     * @schema ConfigurationSpecWorkflow#globalMaxConcurrentWorkflowInvocations
     */
    readonly globalMaxConcurrentWorkflowInvocations?: number;
    /**
     * maxConcurrentActivityInvocations is the maximum number of concurrent activities that can be processed by a single Dapr instance.
     * Attempted invocations beyond this will be queued until the number of concurrent invocations drops below this value.
     * If omitted, no maximum will be enforced.
     *
     * @schema ConfigurationSpecWorkflow#maxConcurrentActivityInvocations
     */
    readonly maxConcurrentActivityInvocations?: number;
    /**
     * maxConcurrentWorkflowInvocations is the maximum number of concurrent workflow invocations that can be scheduled by a single Dapr instance.
     * Attempted invocations beyond this will be queued until the number of concurrent invocations drops below this value.
     * If omitted, no maximum will be enforced.
     *
     * @schema ConfigurationSpecWorkflow#maxConcurrentWorkflowInvocations
     */
    readonly maxConcurrentWorkflowInvocations?: number;
    /**
     * StateRetentionPolicy defines the retention configuration for workflow
     * state once a workflow reaches a terminal state. If not set, workflow
     * instances will not be automatically purged.
     *
     * @schema ConfigurationSpecWorkflow#stateRetentionPolicy
     */
    readonly stateRetentionPolicy?: ConfigurationSpecWorkflowStateRetentionPolicy;
    /**
     * workflowConcurrencyLimits defines per-workflow-name concurrency limits
     * enforced globally across all replicas by the scheduler.
     *
     * @schema ConfigurationSpecWorkflow#workflowConcurrencyLimits
     */
    readonly workflowConcurrencyLimits?: ConfigurationSpecWorkflowWorkflowConcurrencyLimits[];
}
/**
 * Converts an object of type 'ConfigurationSpecWorkflow' to JSON representation.
 */
export declare function toJson_ConfigurationSpecWorkflow(obj: ConfigurationSpecWorkflow | undefined): Record<string, any> | undefined;
/**
 * AppPolicySpec defines the policy data structure for each app.
 *
 * @schema ConfigurationSpecAccessControlPolicies
 */
export interface ConfigurationSpecAccessControlPolicies {
    /**
     * @schema ConfigurationSpecAccessControlPolicies#appId
     */
    readonly appId: string;
    /**
     * @schema ConfigurationSpecAccessControlPolicies#defaultAction
     */
    readonly defaultAction?: string;
    /**
     * @schema ConfigurationSpecAccessControlPolicies#namespace
     */
    readonly namespace?: string;
    /**
     * @schema ConfigurationSpecAccessControlPolicies#operations
     */
    readonly operations?: ConfigurationSpecAccessControlPoliciesOperations[];
    /**
     * @schema ConfigurationSpecAccessControlPolicies#trustDomain
     */
    readonly trustDomain?: string;
}
/**
 * Converts an object of type 'ConfigurationSpecAccessControlPolicies' to JSON representation.
 */
export declare function toJson_ConfigurationSpecAccessControlPolicies(obj: ConfigurationSpecAccessControlPolicies | undefined): Record<string, any> | undefined;
/**
 * APIAccessRule describes an access rule for allowing or denying a Dapr API.
 *
 * @schema ConfigurationSpecApiAllowed
 */
export interface ConfigurationSpecApiAllowed {
    /**
     * @schema ConfigurationSpecApiAllowed#name
     */
    readonly name: string;
    /**
     * @schema ConfigurationSpecApiAllowed#protocol
     */
    readonly protocol?: string;
    /**
     * @schema ConfigurationSpecApiAllowed#version
     */
    readonly version: string;
}
/**
 * Converts an object of type 'ConfigurationSpecApiAllowed' to JSON representation.
 */
export declare function toJson_ConfigurationSpecApiAllowed(obj: ConfigurationSpecApiAllowed | undefined): Record<string, any> | undefined;
/**
 * APIAccessRule describes an access rule for allowing or denying a Dapr API.
 *
 * @schema ConfigurationSpecApiDenied
 */
export interface ConfigurationSpecApiDenied {
    /**
     * @schema ConfigurationSpecApiDenied#name
     */
    readonly name: string;
    /**
     * @schema ConfigurationSpecApiDenied#protocol
     */
    readonly protocol?: string;
    /**
     * @schema ConfigurationSpecApiDenied#version
     */
    readonly version: string;
}
/**
 * Converts an object of type 'ConfigurationSpecApiDenied' to JSON representation.
 */
export declare function toJson_ConfigurationSpecApiDenied(obj: ConfigurationSpecApiDenied | undefined): Record<string, any> | undefined;
/**
 * HandlerSpec defines a request handlers.
 *
 * @schema ConfigurationSpecAppHttpPipelineHandlers
 */
export interface ConfigurationSpecAppHttpPipelineHandlers {
    /**
     * @schema ConfigurationSpecAppHttpPipelineHandlers#name
     */
    readonly name: string;
    /**
     * SelectorSpec selects target services to which the handler is to be applied.
     *
     * @schema ConfigurationSpecAppHttpPipelineHandlers#selector
     */
    readonly selector?: ConfigurationSpecAppHttpPipelineHandlersSelector;
    /**
     * @schema ConfigurationSpecAppHttpPipelineHandlers#type
     */
    readonly type: string;
}
/**
 * Converts an object of type 'ConfigurationSpecAppHttpPipelineHandlers' to JSON representation.
 */
export declare function toJson_ConfigurationSpecAppHttpPipelineHandlers(obj: ConfigurationSpecAppHttpPipelineHandlers | undefined): Record<string, any> | undefined;
/**
 * HandlerSpec defines a request handlers.
 *
 * @schema ConfigurationSpecHttpPipelineHandlers
 */
export interface ConfigurationSpecHttpPipelineHandlers {
    /**
     * @schema ConfigurationSpecHttpPipelineHandlers#name
     */
    readonly name: string;
    /**
     * SelectorSpec selects target services to which the handler is to be applied.
     *
     * @schema ConfigurationSpecHttpPipelineHandlers#selector
     */
    readonly selector?: ConfigurationSpecHttpPipelineHandlersSelector;
    /**
     * @schema ConfigurationSpecHttpPipelineHandlers#type
     */
    readonly type: string;
}
/**
 * Converts an object of type 'ConfigurationSpecHttpPipelineHandlers' to JSON representation.
 */
export declare function toJson_ConfigurationSpecHttpPipelineHandlers(obj: ConfigurationSpecHttpPipelineHandlers | undefined): Record<string, any> | undefined;
/**
 * Configure API logging.
 *
 * @schema ConfigurationSpecLoggingApiLogging
 */
export interface ConfigurationSpecLoggingApiLogging {
    /**
     * Default value for enabling API logging. Sidecars can always override this by setting `--enable-api-logging` to true or false explicitly.
     * The default value is false.
     *
     * @schema ConfigurationSpecLoggingApiLogging#enabled
     */
    readonly enabled?: boolean;
    /**
     * When enabled, obfuscates the values of URLs in HTTP API logs, logging the route name rather than the full path being invoked, which could contain PII.
     * Default: false.
     * This option has no effect if API logging is disabled.
     *
     * @schema ConfigurationSpecLoggingApiLogging#obfuscateURLs
     */
    readonly obfuscateUrLs?: boolean;
    /**
     * If true, health checks are not reported in API logs. Default: false.
     * This option has no effect if API logging is disabled.
     *
     * @schema ConfigurationSpecLoggingApiLogging#omitHealthChecks
     */
    readonly omitHealthChecks?: boolean;
}
/**
 * Converts an object of type 'ConfigurationSpecLoggingApiLogging' to JSON representation.
 */
export declare function toJson_ConfigurationSpecLoggingApiLogging(obj: ConfigurationSpecLoggingApiLogging | undefined): Record<string, any> | undefined;
/**
 * MetricHTTP defines configuration for metrics for the HTTP server
 *
 * @schema ConfigurationSpecMetricHttp
 */
export interface ConfigurationSpecMetricHttp {
    /**
     * If true (default is false) HTTP verbs (e.g., GET, POST) are excluded from the metrics.
     *
     * @schema ConfigurationSpecMetricHttp#excludeVerbs
     */
    readonly excludeVerbs?: boolean;
    /**
     * If false, metrics for the HTTP server are collected with increased cardinality.
     * The default is true in Dapr 1.13, but will be changed to false in 1.15+
     *
     * @schema ConfigurationSpecMetricHttp#increasedCardinality
     */
    readonly increasedCardinality?: boolean;
    /**
     * @schema ConfigurationSpecMetricHttp#pathMatching
     */
    readonly pathMatching?: string[];
}
/**
 * Converts an object of type 'ConfigurationSpecMetricHttp' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMetricHttp(obj: ConfigurationSpecMetricHttp | undefined): Record<string, any> | undefined;
/**
 * MetricsRule defines configuration options for a metric.
 *
 * @schema ConfigurationSpecMetricRules
 */
export interface ConfigurationSpecMetricRules {
    /**
     * @schema ConfigurationSpecMetricRules#labels
     */
    readonly labels: ConfigurationSpecMetricRulesLabels[];
    /**
     * @schema ConfigurationSpecMetricRules#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'ConfigurationSpecMetricRules' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMetricRules(obj: ConfigurationSpecMetricRules | undefined): Record<string, any> | undefined;
/**
 * MetricHTTP defines configuration for metrics for the HTTP server
 *
 * @schema ConfigurationSpecMetricsHttp
 */
export interface ConfigurationSpecMetricsHttp {
    /**
     * If true (default is false) HTTP verbs (e.g., GET, POST) are excluded from the metrics.
     *
     * @schema ConfigurationSpecMetricsHttp#excludeVerbs
     */
    readonly excludeVerbs?: boolean;
    /**
     * If false, metrics for the HTTP server are collected with increased cardinality.
     * The default is true in Dapr 1.13, but will be changed to false in 1.15+
     *
     * @schema ConfigurationSpecMetricsHttp#increasedCardinality
     */
    readonly increasedCardinality?: boolean;
    /**
     * @schema ConfigurationSpecMetricsHttp#pathMatching
     */
    readonly pathMatching?: string[];
}
/**
 * Converts an object of type 'ConfigurationSpecMetricsHttp' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMetricsHttp(obj: ConfigurationSpecMetricsHttp | undefined): Record<string, any> | undefined;
/**
 * MetricsRule defines configuration options for a metric.
 *
 * @schema ConfigurationSpecMetricsRules
 */
export interface ConfigurationSpecMetricsRules {
    /**
     * @schema ConfigurationSpecMetricsRules#labels
     */
    readonly labels: ConfigurationSpecMetricsRulesLabels[];
    /**
     * @schema ConfigurationSpecMetricsRules#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'ConfigurationSpecMetricsRules' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMetricsRules(obj: ConfigurationSpecMetricsRules | undefined): Record<string, any> | undefined;
/**
 * ValidatorSpec contains additional token validators to use.
 *
 * @schema ConfigurationSpecMtlsTokenValidators
 */
export interface ConfigurationSpecMtlsTokenValidators {
    /**
     * Name of the validator
     *
     * @schema ConfigurationSpecMtlsTokenValidators#name
     */
    readonly name: ConfigurationSpecMtlsTokenValidatorsName;
    /**
     * Options for the validator, if any
     *
     * @schema ConfigurationSpecMtlsTokenValidators#options
     */
    readonly options?: any;
}
/**
 * Converts an object of type 'ConfigurationSpecMtlsTokenValidators' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMtlsTokenValidators(obj: ConfigurationSpecMtlsTokenValidators | undefined): Record<string, any> | undefined;
/**
 * SecretsScope defines the scope for secrets.
 *
 * @schema ConfigurationSpecSecretsScopes
 */
export interface ConfigurationSpecSecretsScopes {
    /**
     * @schema ConfigurationSpecSecretsScopes#allowedSecrets
     */
    readonly allowedSecrets?: string[];
    /**
     * @schema ConfigurationSpecSecretsScopes#defaultAccess
     */
    readonly defaultAccess?: string;
    /**
     * @schema ConfigurationSpecSecretsScopes#deniedSecrets
     */
    readonly deniedSecrets?: string[];
    /**
     * @schema ConfigurationSpecSecretsScopes#storeName
     */
    readonly storeName: string;
}
/**
 * Converts an object of type 'ConfigurationSpecSecretsScopes' to JSON representation.
 */
export declare function toJson_ConfigurationSpecSecretsScopes(obj: ConfigurationSpecSecretsScopes | undefined): Record<string, any> | undefined;
/**
 * OtelSpec defines Otel exporter configurations.
 *
 * @schema ConfigurationSpecTracingOtel
 */
export interface ConfigurationSpecTracingOtel {
    /**
     * @schema ConfigurationSpecTracingOtel#endpointAddress
     */
    readonly endpointAddress: string;
    /**
     * Headers to add to the OTLP trace exporter request.
     * Each header can contain plaintext values, reference secrets, or reference environment variables.
     *
     * @schema ConfigurationSpecTracingOtel#headers
     */
    readonly headers?: ConfigurationSpecTracingOtelHeaders[];
    /**
     * @schema ConfigurationSpecTracingOtel#isSecure
     */
    readonly isSecure: boolean;
    /**
     * @schema ConfigurationSpecTracingOtel#protocol
     */
    readonly protocol: string;
    /**
     * Timeout for the OTLP trace exporter request.
     *
     * @schema ConfigurationSpecTracingOtel#timeout
     */
    readonly timeout?: string;
}
/**
 * Converts an object of type 'ConfigurationSpecTracingOtel' to JSON representation.
 */
export declare function toJson_ConfigurationSpecTracingOtel(obj: ConfigurationSpecTracingOtel | undefined): Record<string, any> | undefined;
/**
 * ZipkinSpec defines Zipkin trace configurations.
 *
 * @schema ConfigurationSpecTracingZipkin
 */
export interface ConfigurationSpecTracingZipkin {
    /**
     * @schema ConfigurationSpecTracingZipkin#endpointAddress
     */
    readonly endpointAddress: string;
}
/**
 * Converts an object of type 'ConfigurationSpecTracingZipkin' to JSON representation.
 */
export declare function toJson_ConfigurationSpecTracingZipkin(obj: ConfigurationSpecTracingZipkin | undefined): Record<string, any> | undefined;
/**
 * NamedConcurrencyLimit defines a per-name concurrency limit for a specific
 * workflow or activity name.
 *
 * @schema ConfigurationSpecWorkflowActivityConcurrencyLimits
 */
export interface ConfigurationSpecWorkflowActivityConcurrencyLimits {
    /**
     * MaxConcurrent is the maximum number of concurrent invocations across all
     * replicas.
     *
     * @schema ConfigurationSpecWorkflowActivityConcurrencyLimits#maxConcurrent
     */
    readonly maxConcurrent?: number;
    /**
     * Name is the workflow or activity name to limit.
     *
     * @schema ConfigurationSpecWorkflowActivityConcurrencyLimits#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'ConfigurationSpecWorkflowActivityConcurrencyLimits' to JSON representation.
 */
export declare function toJson_ConfigurationSpecWorkflowActivityConcurrencyLimits(obj: ConfigurationSpecWorkflowActivityConcurrencyLimits | undefined): Record<string, any> | undefined;
/**
 * StateRetentionPolicy defines the retention configuration for workflow
 * state once a workflow reaches a terminal state. If not set, workflow
 * instances will not be automatically purged.
 *
 * @schema ConfigurationSpecWorkflowStateRetentionPolicy
 */
export interface ConfigurationSpecWorkflowStateRetentionPolicy {
    /**
     * AnyTerminal is the TTL for purging workflow instances that reach any
     * terminal state.
     *
     * @schema ConfigurationSpecWorkflowStateRetentionPolicy#anyTerminal
     */
    readonly anyTerminal?: string;
    /**
     * Completed is the TTL for purging workflow instances that reach the
     * Completed terminal state.
     *
     * @schema ConfigurationSpecWorkflowStateRetentionPolicy#completed
     */
    readonly completed?: string;
    /**
     * Failed is the TTL for purging workflow instances that reach the Failed
     * terminal state.
     *
     * @schema ConfigurationSpecWorkflowStateRetentionPolicy#failed
     */
    readonly failed?: string;
    /**
     * Terminated is the TTL for purging workflow instances that reach the
     * Terminated terminal state.
     *
     * @schema ConfigurationSpecWorkflowStateRetentionPolicy#terminated
     */
    readonly terminated?: string;
}
/**
 * Converts an object of type 'ConfigurationSpecWorkflowStateRetentionPolicy' to JSON representation.
 */
export declare function toJson_ConfigurationSpecWorkflowStateRetentionPolicy(obj: ConfigurationSpecWorkflowStateRetentionPolicy | undefined): Record<string, any> | undefined;
/**
 * NamedConcurrencyLimit defines a per-name concurrency limit for a specific
 * workflow or activity name.
 *
 * @schema ConfigurationSpecWorkflowWorkflowConcurrencyLimits
 */
export interface ConfigurationSpecWorkflowWorkflowConcurrencyLimits {
    /**
     * MaxConcurrent is the maximum number of concurrent invocations across all
     * replicas.
     *
     * @schema ConfigurationSpecWorkflowWorkflowConcurrencyLimits#maxConcurrent
     */
    readonly maxConcurrent?: number;
    /**
     * Name is the workflow or activity name to limit.
     *
     * @schema ConfigurationSpecWorkflowWorkflowConcurrencyLimits#name
     */
    readonly name?: string;
}
/**
 * Converts an object of type 'ConfigurationSpecWorkflowWorkflowConcurrencyLimits' to JSON representation.
 */
export declare function toJson_ConfigurationSpecWorkflowWorkflowConcurrencyLimits(obj: ConfigurationSpecWorkflowWorkflowConcurrencyLimits | undefined): Record<string, any> | undefined;
/**
 * AppOperationAction defines the data structure for each app operation.
 *
 * @schema ConfigurationSpecAccessControlPoliciesOperations
 */
export interface ConfigurationSpecAccessControlPoliciesOperations {
    /**
     * @schema ConfigurationSpecAccessControlPoliciesOperations#action
     */
    readonly action: string;
    /**
     * @schema ConfigurationSpecAccessControlPoliciesOperations#httpVerb
     */
    readonly httpVerb?: string[];
    /**
     * @schema ConfigurationSpecAccessControlPoliciesOperations#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'ConfigurationSpecAccessControlPoliciesOperations' to JSON representation.
 */
export declare function toJson_ConfigurationSpecAccessControlPoliciesOperations(obj: ConfigurationSpecAccessControlPoliciesOperations | undefined): Record<string, any> | undefined;
/**
 * SelectorSpec selects target services to which the handler is to be applied.
 *
 * @schema ConfigurationSpecAppHttpPipelineHandlersSelector
 */
export interface ConfigurationSpecAppHttpPipelineHandlersSelector {
    /**
     * @schema ConfigurationSpecAppHttpPipelineHandlersSelector#fields
     */
    readonly fields: ConfigurationSpecAppHttpPipelineHandlersSelectorFields[];
}
/**
 * Converts an object of type 'ConfigurationSpecAppHttpPipelineHandlersSelector' to JSON representation.
 */
export declare function toJson_ConfigurationSpecAppHttpPipelineHandlersSelector(obj: ConfigurationSpecAppHttpPipelineHandlersSelector | undefined): Record<string, any> | undefined;
/**
 * SelectorSpec selects target services to which the handler is to be applied.
 *
 * @schema ConfigurationSpecHttpPipelineHandlersSelector
 */
export interface ConfigurationSpecHttpPipelineHandlersSelector {
    /**
     * @schema ConfigurationSpecHttpPipelineHandlersSelector#fields
     */
    readonly fields: ConfigurationSpecHttpPipelineHandlersSelectorFields[];
}
/**
 * Converts an object of type 'ConfigurationSpecHttpPipelineHandlersSelector' to JSON representation.
 */
export declare function toJson_ConfigurationSpecHttpPipelineHandlersSelector(obj: ConfigurationSpecHttpPipelineHandlersSelector | undefined): Record<string, any> | undefined;
/**
 * MetricsLabel defines an object that allows to set regex expressions for a label.
 *
 * @schema ConfigurationSpecMetricRulesLabels
 */
export interface ConfigurationSpecMetricRulesLabels {
    /**
     * @schema ConfigurationSpecMetricRulesLabels#name
     */
    readonly name: string;
    /**
     * @schema ConfigurationSpecMetricRulesLabels#regex
     */
    readonly regex: {
        [key: string]: string;
    };
}
/**
 * Converts an object of type 'ConfigurationSpecMetricRulesLabels' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMetricRulesLabels(obj: ConfigurationSpecMetricRulesLabels | undefined): Record<string, any> | undefined;
/**
 * MetricsLabel defines an object that allows to set regex expressions for a label.
 *
 * @schema ConfigurationSpecMetricsRulesLabels
 */
export interface ConfigurationSpecMetricsRulesLabels {
    /**
     * @schema ConfigurationSpecMetricsRulesLabels#name
     */
    readonly name: string;
    /**
     * @schema ConfigurationSpecMetricsRulesLabels#regex
     */
    readonly regex: {
        [key: string]: string;
    };
}
/**
 * Converts an object of type 'ConfigurationSpecMetricsRulesLabels' to JSON representation.
 */
export declare function toJson_ConfigurationSpecMetricsRulesLabels(obj: ConfigurationSpecMetricsRulesLabels | undefined): Record<string, any> | undefined;
/**
 * Name of the validator
 *
 * @schema ConfigurationSpecMtlsTokenValidatorsName
 */
export declare enum ConfigurationSpecMtlsTokenValidatorsName {
    /** jwks */
    JWKS = "jwks"
}
/**
 * NameValuePair is a name/value pair.
 *
 * @schema ConfigurationSpecTracingOtelHeaders
 */
export interface ConfigurationSpecTracingOtelHeaders {
    /**
     * EnvRef is the name of an environmental variable to read the value from.
     *
     * @schema ConfigurationSpecTracingOtelHeaders#envRef
     */
    readonly envRef?: string;
    /**
     * Name of the property.
     *
     * @schema ConfigurationSpecTracingOtelHeaders#name
     */
    readonly name: string;
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema ConfigurationSpecTracingOtelHeaders#secretKeyRef
     */
    readonly secretKeyRef?: ConfigurationSpecTracingOtelHeadersSecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema ConfigurationSpecTracingOtelHeaders#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'ConfigurationSpecTracingOtelHeaders' to JSON representation.
 */
export declare function toJson_ConfigurationSpecTracingOtelHeaders(obj: ConfigurationSpecTracingOtelHeaders | undefined): Record<string, any> | undefined;
/**
 * SelectorField defines a selector fields.
 *
 * @schema ConfigurationSpecAppHttpPipelineHandlersSelectorFields
 */
export interface ConfigurationSpecAppHttpPipelineHandlersSelectorFields {
    /**
     * @schema ConfigurationSpecAppHttpPipelineHandlersSelectorFields#field
     */
    readonly field: string;
    /**
     * @schema ConfigurationSpecAppHttpPipelineHandlersSelectorFields#value
     */
    readonly value: string;
}
/**
 * Converts an object of type 'ConfigurationSpecAppHttpPipelineHandlersSelectorFields' to JSON representation.
 */
export declare function toJson_ConfigurationSpecAppHttpPipelineHandlersSelectorFields(obj: ConfigurationSpecAppHttpPipelineHandlersSelectorFields | undefined): Record<string, any> | undefined;
/**
 * SelectorField defines a selector fields.
 *
 * @schema ConfigurationSpecHttpPipelineHandlersSelectorFields
 */
export interface ConfigurationSpecHttpPipelineHandlersSelectorFields {
    /**
     * @schema ConfigurationSpecHttpPipelineHandlersSelectorFields#field
     */
    readonly field: string;
    /**
     * @schema ConfigurationSpecHttpPipelineHandlersSelectorFields#value
     */
    readonly value: string;
}
/**
 * Converts an object of type 'ConfigurationSpecHttpPipelineHandlersSelectorFields' to JSON representation.
 */
export declare function toJson_ConfigurationSpecHttpPipelineHandlersSelectorFields(obj: ConfigurationSpecHttpPipelineHandlersSelectorFields | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema ConfigurationSpecTracingOtelHeadersSecretKeyRef
 */
export interface ConfigurationSpecTracingOtelHeadersSecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema ConfigurationSpecTracingOtelHeadersSecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema ConfigurationSpecTracingOtelHeadersSecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'ConfigurationSpecTracingOtelHeadersSecretKeyRef' to JSON representation.
 */
export declare function toJson_ConfigurationSpecTracingOtelHeadersSecretKeyRef(obj: ConfigurationSpecTracingOtelHeadersSecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * HTTPEndpoint describes a Dapr HTTPEndpoint type for external service invocation.
This endpoint can be external to Dapr, or external to the environment.
 *
 * @schema HTTPEndpoint
 */
export declare class HttpEndpoint extends ApiObject {
    /**
     * Returns the apiVersion and kind for "HTTPEndpoint"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "HTTPEndpoint".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: HttpEndpointProps): any;
    /**
     * Defines a "HTTPEndpoint" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: HttpEndpointProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * HTTPEndpoint describes a Dapr HTTPEndpoint type for external service invocation.
 * This endpoint can be external to Dapr, or external to the environment.
 *
 * @schema HTTPEndpoint
 */
export interface HttpEndpointProps {
    /**
     * @schema HTTPEndpoint#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * Auth represents authentication details for the component.
     *
     * @schema HTTPEndpoint#auth
     */
    readonly auth?: HttpEndpointAuth;
    /**
     * @schema HTTPEndpoint#scopes
     */
    readonly scopes?: string[];
    /**
     * HTTPEndpointSpec describes an access specification for allowing external service invocations.
     *
     * @schema HTTPEndpoint#spec
     */
    readonly spec?: HttpEndpointSpec;
}
/**
 * Converts an object of type 'HttpEndpointProps' to JSON representation.
 */
export declare function toJson_HttpEndpointProps(obj: HttpEndpointProps | undefined): Record<string, any> | undefined;
/**
 * Auth represents authentication details for the component.
 *
 * @schema HttpEndpointAuth
 */
export interface HttpEndpointAuth {
    /**
     * @schema HttpEndpointAuth#secretStore
     */
    readonly secretStore: string;
}
/**
 * Converts an object of type 'HttpEndpointAuth' to JSON representation.
 */
export declare function toJson_HttpEndpointAuth(obj: HttpEndpointAuth | undefined): Record<string, any> | undefined;
/**
 * HTTPEndpointSpec describes an access specification for allowing external service invocations.
 *
 * @schema HttpEndpointSpec
 */
export interface HttpEndpointSpec {
    /**
     * @schema HttpEndpointSpec#baseUrl
     */
    readonly baseUrl: string;
    /**
     * TLS describes how to build client or server TLS configurations.
     *
     * @schema HttpEndpointSpec#clientTLS
     */
    readonly clientTls?: HttpEndpointSpecClientTls;
    /**
     * @schema HttpEndpointSpec#headers
     */
    readonly headers?: HttpEndpointSpecHeaders[];
}
/**
 * Converts an object of type 'HttpEndpointSpec' to JSON representation.
 */
export declare function toJson_HttpEndpointSpec(obj: HttpEndpointSpec | undefined): Record<string, any> | undefined;
/**
 * TLS describes how to build client or server TLS configurations.
 *
 * @schema HttpEndpointSpecClientTls
 */
export interface HttpEndpointSpecClientTls {
    /**
     * TLSDocument describes and in-line or pointer to a document to build a TLS configuration.
     *
     * @schema HttpEndpointSpecClientTls#certificate
     */
    readonly certificate?: HttpEndpointSpecClientTlsCertificate;
    /**
     * TLSDocument describes and in-line or pointer to a document to build a TLS configuration.
     *
     * @schema HttpEndpointSpecClientTls#privateKey
     */
    readonly privateKey?: HttpEndpointSpecClientTlsPrivateKey;
    /**
     * Renegotiation sets the underlying tls negotiation strategy for an http channel.
     *
     * @schema HttpEndpointSpecClientTls#renegotiation
     */
    readonly renegotiation?: HttpEndpointSpecClientTlsRenegotiation;
    /**
     * TLSDocument describes and in-line or pointer to a document to build a TLS configuration.
     *
     * @schema HttpEndpointSpecClientTls#rootCA
     */
    readonly rootCa?: HttpEndpointSpecClientTlsRootCa;
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTls' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecClientTls(obj: HttpEndpointSpecClientTls | undefined): Record<string, any> | undefined;
/**
 * NameValuePair is a name/value pair.
 *
 * @schema HttpEndpointSpecHeaders
 */
export interface HttpEndpointSpecHeaders {
    /**
     * EnvRef is the name of an environmental variable to read the value from.
     *
     * @schema HttpEndpointSpecHeaders#envRef
     */
    readonly envRef?: string;
    /**
     * Name of the property.
     *
     * @schema HttpEndpointSpecHeaders#name
     */
    readonly name: string;
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema HttpEndpointSpecHeaders#secretKeyRef
     */
    readonly secretKeyRef?: HttpEndpointSpecHeadersSecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema HttpEndpointSpecHeaders#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'HttpEndpointSpecHeaders' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecHeaders(obj: HttpEndpointSpecHeaders | undefined): Record<string, any> | undefined;
/**
 * TLSDocument describes and in-line or pointer to a document to build a TLS configuration.
 *
 * @schema HttpEndpointSpecClientTlsCertificate
 */
export interface HttpEndpointSpecClientTlsCertificate {
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema HttpEndpointSpecClientTlsCertificate#secretKeyRef
     */
    readonly secretKeyRef?: HttpEndpointSpecClientTlsCertificateSecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema HttpEndpointSpecClientTlsCertificate#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsCertificate' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecClientTlsCertificate(obj: HttpEndpointSpecClientTlsCertificate | undefined): Record<string, any> | undefined;
/**
 * TLSDocument describes and in-line or pointer to a document to build a TLS configuration.
 *
 * @schema HttpEndpointSpecClientTlsPrivateKey
 */
export interface HttpEndpointSpecClientTlsPrivateKey {
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema HttpEndpointSpecClientTlsPrivateKey#secretKeyRef
     */
    readonly secretKeyRef?: HttpEndpointSpecClientTlsPrivateKeySecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema HttpEndpointSpecClientTlsPrivateKey#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsPrivateKey' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecClientTlsPrivateKey(obj: HttpEndpointSpecClientTlsPrivateKey | undefined): Record<string, any> | undefined;
/**
 * Renegotiation sets the underlying tls negotiation strategy for an http channel.
 *
 * @schema HttpEndpointSpecClientTlsRenegotiation
 */
export declare enum HttpEndpointSpecClientTlsRenegotiation {
    /** Never */
    NEVER = "Never",
    /** OnceAsClient */
    ONCE_AS_CLIENT = "OnceAsClient",
    /** FreelyAsClient */
    FREELY_AS_CLIENT = "FreelyAsClient"
}
/**
 * TLSDocument describes and in-line or pointer to a document to build a TLS configuration.
 *
 * @schema HttpEndpointSpecClientTlsRootCa
 */
export interface HttpEndpointSpecClientTlsRootCa {
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema HttpEndpointSpecClientTlsRootCa#secretKeyRef
     */
    readonly secretKeyRef?: HttpEndpointSpecClientTlsRootCaSecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema HttpEndpointSpecClientTlsRootCa#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsRootCa' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecClientTlsRootCa(obj: HttpEndpointSpecClientTlsRootCa | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema HttpEndpointSpecHeadersSecretKeyRef
 */
export interface HttpEndpointSpecHeadersSecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema HttpEndpointSpecHeadersSecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema HttpEndpointSpecHeadersSecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'HttpEndpointSpecHeadersSecretKeyRef' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecHeadersSecretKeyRef(obj: HttpEndpointSpecHeadersSecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema HttpEndpointSpecClientTlsCertificateSecretKeyRef
 */
export interface HttpEndpointSpecClientTlsCertificateSecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema HttpEndpointSpecClientTlsCertificateSecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema HttpEndpointSpecClientTlsCertificateSecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsCertificateSecretKeyRef' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecClientTlsCertificateSecretKeyRef(obj: HttpEndpointSpecClientTlsCertificateSecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema HttpEndpointSpecClientTlsPrivateKeySecretKeyRef
 */
export interface HttpEndpointSpecClientTlsPrivateKeySecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema HttpEndpointSpecClientTlsPrivateKeySecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema HttpEndpointSpecClientTlsPrivateKeySecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsPrivateKeySecretKeyRef' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecClientTlsPrivateKeySecretKeyRef(obj: HttpEndpointSpecClientTlsPrivateKeySecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema HttpEndpointSpecClientTlsRootCaSecretKeyRef
 */
export interface HttpEndpointSpecClientTlsRootCaSecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema HttpEndpointSpecClientTlsRootCaSecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema HttpEndpointSpecClientTlsRootCaSecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'HttpEndpointSpecClientTlsRootCaSecretKeyRef' to JSON representation.
 */
export declare function toJson_HttpEndpointSpecClientTlsRootCaSecretKeyRef(obj: HttpEndpointSpecClientTlsRootCaSecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * MCPServer describes a Dapr MCPServer resource that declares a connection to
an MCP (Model Context Protocol) server for durable tool execution.
 *
 * @schema MCPServer
 */
export declare class McpServer extends ApiObject {
    /**
     * Returns the apiVersion and kind for "MCPServer"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "MCPServer".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: McpServerProps): any;
    /**
     * Defines a "MCPServer" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: McpServerProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * MCPServer describes a Dapr MCPServer resource that declares a connection to
 * an MCP (Model Context Protocol) server for durable tool execution.
 *
 * @schema MCPServer
 */
export interface McpServerProps {
    /**
     * @schema MCPServer#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * @schema MCPServer#scopes
     */
    readonly scopes?: string[];
    /**
     * MCPServerSpec is the full configuration for an MCP server connection.
     *
     * @schema MCPServer#spec
     */
    readonly spec?: McpServerSpec;
}
/**
 * Converts an object of type 'McpServerProps' to JSON representation.
 */
export declare function toJson_McpServerProps(obj: McpServerProps | undefined): Record<string, any> | undefined;
/**
 * MCPServerSpec is the full configuration for an MCP server connection.
 *
 * @schema McpServerSpec
 */
export interface McpServerSpec {
    /**
     * Catalog holds user-facing governance metadata (display name, description,
     * owner, tags, links). It is purely informational and not used at runtime.
     *
     * @schema McpServerSpec#catalog
     */
    readonly catalog?: McpServerSpecCatalog;
    /**
     * Endpoint describes the transport and target of the MCP server.
     *
     * @schema McpServerSpec#endpoint
     */
    readonly endpoint: McpServerSpecEndpoint;
    /**
     * IgnoreErrors, when true, allows daprd to continue running if validation
     * or secret resolution fails for this MCPServer. When false (default),
     * such failures cause daprd to exit gracefully.
     *
     * @schema McpServerSpec#ignoreErrors
     */
    readonly ignoreErrors?: boolean;
    /**
     * Middleware defines optional workflow hooks invoked around each tool call.
     *
     * @schema McpServerSpec#middleware
     */
    readonly middleware?: McpServerSpecMiddleware;
}
/**
 * Converts an object of type 'McpServerSpec' to JSON representation.
 */
export declare function toJson_McpServerSpec(obj: McpServerSpec | undefined): Record<string, any> | undefined;
/**
 * Catalog holds user-facing governance metadata (display name, description,
 * owner, tags, links). It is purely informational and not used at runtime.
 *
 * @schema McpServerSpecCatalog
 */
export interface McpServerSpecCatalog {
    /**
     * @schema McpServerSpecCatalog#description
     */
    readonly description?: string;
    /**
     * @schema McpServerSpecCatalog#displayName
     */
    readonly displayName?: string;
    /**
     * Links is a free-form map of named URLs (e.g. "docs", "runbook", "dashboard").
     *
     * @schema McpServerSpecCatalog#links
     */
    readonly links?: {
        [key: string]: string;
    };
    /**
     * MCPCatalogOwner identifies the team responsible for the MCP server.
     *
     * @schema McpServerSpecCatalog#owner
     */
    readonly owner?: McpServerSpecCatalogOwner;
    /**
     * @schema McpServerSpecCatalog#tags
     */
    readonly tags?: string[];
}
/**
 * Converts an object of type 'McpServerSpecCatalog' to JSON representation.
 */
export declare function toJson_McpServerSpecCatalog(obj: McpServerSpecCatalog | undefined): Record<string, any> | undefined;
/**
 * Endpoint describes the transport and target of the MCP server.
 *
 * @schema McpServerSpecEndpoint
 */
export interface McpServerSpecEndpoint {
    /**
     * SSE holds configuration for the legacy SSE transport.
     *
     * @schema McpServerSpecEndpoint#sse
     */
    readonly sse?: McpServerSpecEndpointSse;
    /**
     * Stdio holds configuration for the stdio subprocess transport.
     *
     * @schema McpServerSpecEndpoint#stdio
     */
    readonly stdio?: McpServerSpecEndpointStdio;
    /**
     * StreamableHTTP holds configuration for the streamable_http transport.
     *
     * @schema McpServerSpecEndpoint#streamableHTTP
     */
    readonly streamableHttp?: McpServerSpecEndpointStreamableHttp;
}
/**
 * Converts an object of type 'McpServerSpecEndpoint' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpoint(obj: McpServerSpecEndpoint | undefined): Record<string, any> | undefined;
/**
 * Middleware defines optional workflow hooks invoked around each tool call.
 *
 * @schema McpServerSpecMiddleware
 */
export interface McpServerSpecMiddleware {
    /**
     * AfterCallTool hooks are invoked in order after each CallTool.
     * Receives {mcpServer, toolName, arguments, result} as input.
     * Errors fail the workflow — after-hooks act as authorization gates.
     *
     * @schema McpServerSpecMiddleware#afterCallTool
     */
    readonly afterCallTool?: McpServerSpecMiddlewareAfterCallTool[];
    /**
     * AfterListTools hooks are invoked in order after each ListTools.
     * Receives {mcpServer, result} as input.
     * Errors are logged but do not affect the result.
     *
     * @schema McpServerSpecMiddleware#afterListTools
     */
    readonly afterListTools?: McpServerSpecMiddlewareAfterListTools[];
    /**
     * BeforeCallTool hooks are invoked in order before each CallTool.
     * Receives {mcpServer, toolName, arguments} as input.
     * If any hook returns an error, the chain stops and the workflow completes
     * with CallToolResult{isError: true} so the agent/LLM can self-correct.
     *
     * @schema McpServerSpecMiddleware#beforeCallTool
     */
    readonly beforeCallTool?: McpServerSpecMiddlewareBeforeCallTool[];
    /**
     * BeforeListTools hooks are invoked in order before each ListTools.
     * Receives {mcpServer} as input.
     * If any hook returns an error, the chain stops and the error is returned.
     *
     * @schema McpServerSpecMiddleware#beforeListTools
     */
    readonly beforeListTools?: McpServerSpecMiddlewareBeforeListTools[];
}
/**
 * Converts an object of type 'McpServerSpecMiddleware' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddleware(obj: McpServerSpecMiddleware | undefined): Record<string, any> | undefined;
/**
 * MCPCatalogOwner identifies the team responsible for the MCP server.
 *
 * @schema McpServerSpecCatalogOwner
 */
export interface McpServerSpecCatalogOwner {
    /**
     * @schema McpServerSpecCatalogOwner#contact
     */
    readonly contact?: string;
    /**
     * @schema McpServerSpecCatalogOwner#team
     */
    readonly team?: string;
}
/**
 * Converts an object of type 'McpServerSpecCatalogOwner' to JSON representation.
 */
export declare function toJson_McpServerSpecCatalogOwner(obj: McpServerSpecCatalogOwner | undefined): Record<string, any> | undefined;
/**
 * SSE holds configuration for the legacy SSE transport.
 *
 * @schema McpServerSpecEndpointSse
 */
export interface McpServerSpecEndpointSse {
    /**
     * Auth configures authentication for the MCP server connection.
     *
     * @schema McpServerSpecEndpointSse#auth
     */
    readonly auth?: McpServerSpecEndpointSseAuth;
    /**
     * Headers are injected on all outbound HTTP requests to the MCP server.
     *
     * @schema McpServerSpecEndpointSse#headers
     */
    readonly headers?: McpServerSpecEndpointSseHeaders[];
    /**
     * ProtocolVersion pins the MCP spec version the server implements,
     * using the date-based format defined by the MCP specification (e.g. "2025-06-18").
     * When unset, the go-sdk negotiates the latest version supported by both sides.
     *
     * @schema McpServerSpecEndpointSse#protocolVersion
     */
    readonly protocolVersion?: string;
    /**
     * Timeout is the per-call deadline for MCP requests.
     *
     * @schema McpServerSpecEndpointSse#timeout
     */
    readonly timeout?: string;
    /**
     * URL is the endpoint URL of the MCP server.
     *
     * @schema McpServerSpecEndpointSse#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointSse' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointSse(obj: McpServerSpecEndpointSse | undefined): Record<string, any> | undefined;
/**
 * Stdio holds configuration for the stdio subprocess transport.
 *
 * @schema McpServerSpecEndpointStdio
 */
export interface McpServerSpecEndpointStdio {
    /**
     * @schema McpServerSpecEndpointStdio#args
     */
    readonly args?: string[];
    /**
     * Command is the executable to run.
     *
     * @schema McpServerSpecEndpointStdio#command
     */
    readonly command: string;
    /**
     * Env are environment variables injected into the subprocess.
     * Supports plain value, secretKeyRef, and envRef.
     *
     * @schema McpServerSpecEndpointStdio#env
     */
    readonly env?: McpServerSpecEndpointStdioEnv[];
}
/**
 * Converts an object of type 'McpServerSpecEndpointStdio' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStdio(obj: McpServerSpecEndpointStdio | undefined): Record<string, any> | undefined;
/**
 * StreamableHTTP holds configuration for the streamable_http transport.
 *
 * @schema McpServerSpecEndpointStreamableHttp
 */
export interface McpServerSpecEndpointStreamableHttp {
    /**
     * Auth configures authentication for the MCP server connection.
     *
     * @schema McpServerSpecEndpointStreamableHttp#auth
     */
    readonly auth?: McpServerSpecEndpointStreamableHttpAuth;
    /**
     * Headers are injected on all outbound HTTP requests to the MCP server.
     * Each entry follows the same NameValuePair contract used by HTTPEndpoint:
     * plain value, secretKeyRef, or envRef. Secret resolution uses auth.secretStore.
     *
     * @schema McpServerSpecEndpointStreamableHttp#headers
     */
    readonly headers?: McpServerSpecEndpointStreamableHttpHeaders[];
    /**
     * ProtocolVersion pins the MCP spec version the server implements,
     * using the date-based format defined by the MCP specification (e.g. "2025-06-18").
     * When unset, the go-sdk negotiates the latest version supported by both sides.
     *
     * @schema McpServerSpecEndpointStreamableHttp#protocolVersion
     */
    readonly protocolVersion?: string;
    /**
     * Timeout is the per-call deadline for MCP requests.
     *
     * @schema McpServerSpecEndpointStreamableHttp#timeout
     */
    readonly timeout?: string;
    /**
     * URL is the endpoint URL of the MCP server.
     *
     * @schema McpServerSpecEndpointStreamableHttp#url
     */
    readonly url: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttp' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStreamableHttp(obj: McpServerSpecEndpointStreamableHttp | undefined): Record<string, any> | undefined;
/**
 * MutatingMCPMiddlewareHook extends MCPMiddlewareHook with the ability to
 * replace the data flowing through the pipeline when Mutate is true.
 *
 * @schema McpServerSpecMiddlewareAfterCallTool
 */
export interface McpServerSpecMiddlewareAfterCallTool {
    /**
     * Mutate, when true, causes the hook's return value to replace the data
     * flowing through the pipeline:
     * - beforeCallTool: replaces the arguments sent to the tool call
     * (e.g. redact PII, inject defaults).
     * - afterCallTool / afterListTools: replaces the result returned to the caller.
     * When false (default), the hook validates/observes only — its output is discarded.
     *
     * @schema McpServerSpecMiddlewareAfterCallTool#mutate
     */
    readonly mutate?: boolean;
    /**
     * Workflow is the Dapr workflow to invoke as the hook.
     *
     * @schema McpServerSpecMiddlewareAfterCallTool#workflow
     */
    readonly workflow: McpServerSpecMiddlewareAfterCallToolWorkflow;
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareAfterCallTool' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddlewareAfterCallTool(obj: McpServerSpecMiddlewareAfterCallTool | undefined): Record<string, any> | undefined;
/**
 * MutatingMCPMiddlewareHook extends MCPMiddlewareHook with the ability to
 * replace the data flowing through the pipeline when Mutate is true.
 *
 * @schema McpServerSpecMiddlewareAfterListTools
 */
export interface McpServerSpecMiddlewareAfterListTools {
    /**
     * Mutate, when true, causes the hook's return value to replace the data
     * flowing through the pipeline:
     * - beforeCallTool: replaces the arguments sent to the tool call
     * (e.g. redact PII, inject defaults).
     * - afterCallTool / afterListTools: replaces the result returned to the caller.
     * When false (default), the hook validates/observes only — its output is discarded.
     *
     * @schema McpServerSpecMiddlewareAfterListTools#mutate
     */
    readonly mutate?: boolean;
    /**
     * Workflow is the Dapr workflow to invoke as the hook.
     *
     * @schema McpServerSpecMiddlewareAfterListTools#workflow
     */
    readonly workflow: McpServerSpecMiddlewareAfterListToolsWorkflow;
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareAfterListTools' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddlewareAfterListTools(obj: McpServerSpecMiddlewareAfterListTools | undefined): Record<string, any> | undefined;
/**
 * MutatingMCPMiddlewareHook extends MCPMiddlewareHook with the ability to
 * replace the data flowing through the pipeline when Mutate is true.
 *
 * @schema McpServerSpecMiddlewareBeforeCallTool
 */
export interface McpServerSpecMiddlewareBeforeCallTool {
    /**
     * Mutate, when true, causes the hook's return value to replace the data
     * flowing through the pipeline:
     * - beforeCallTool: replaces the arguments sent to the tool call
     * (e.g. redact PII, inject defaults).
     * - afterCallTool / afterListTools: replaces the result returned to the caller.
     * When false (default), the hook validates/observes only — its output is discarded.
     *
     * @schema McpServerSpecMiddlewareBeforeCallTool#mutate
     */
    readonly mutate?: boolean;
    /**
     * Workflow is the Dapr workflow to invoke as the hook.
     *
     * @schema McpServerSpecMiddlewareBeforeCallTool#workflow
     */
    readonly workflow: McpServerSpecMiddlewareBeforeCallToolWorkflow;
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareBeforeCallTool' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddlewareBeforeCallTool(obj: McpServerSpecMiddlewareBeforeCallTool | undefined): Record<string, any> | undefined;
/**
 * MCPMiddlewareHook is a single middleware hook.
 *
 * @schema McpServerSpecMiddlewareBeforeListTools
 */
export interface McpServerSpecMiddlewareBeforeListTools {
    /**
     * Workflow is the Dapr workflow to invoke as the hook.
     *
     * @schema McpServerSpecMiddlewareBeforeListTools#workflow
     */
    readonly workflow: McpServerSpecMiddlewareBeforeListToolsWorkflow;
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareBeforeListTools' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddlewareBeforeListTools(obj: McpServerSpecMiddlewareBeforeListTools | undefined): Record<string, any> | undefined;
/**
 * Auth configures authentication for the MCP server connection.
 *
 * @schema McpServerSpecEndpointSseAuth
 */
export interface McpServerSpecEndpointSseAuth {
    /**
     * OAuth2 configures OAuth2 client credentials flow for the MCP server.
     *
     * @schema McpServerSpecEndpointSseAuth#oauth2
     */
    readonly oauth2?: McpServerSpecEndpointSseAuthOauth2;
    /**
     * SecretStore names the Dapr secret store used to resolve secretKeyRef entries
     * in spec.endpoint.http.headers. auth.oauth2.secretKeyRef is resolved separately
     * at call time by the MCP worker. Defaults to "kubernetes".
     *
     * @default kubernetes".
     * @schema McpServerSpecEndpointSseAuth#secretStore
     */
    readonly secretStore?: string;
    /**
     * SPIFFE configures workload identity JWT injection via Dapr's Sentry CA.
     * No secret is required; Sentry issues the SVID automatically.
     *
     * @schema McpServerSpecEndpointSseAuth#spiffe
     */
    readonly spiffe?: McpServerSpecEndpointSseAuthSpiffe;
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuth' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointSseAuth(obj: McpServerSpecEndpointSseAuth | undefined): Record<string, any> | undefined;
/**
 * NameValuePair is a name/value pair.
 *
 * @schema McpServerSpecEndpointSseHeaders
 */
export interface McpServerSpecEndpointSseHeaders {
    /**
     * EnvRef is the name of an environmental variable to read the value from.
     *
     * @schema McpServerSpecEndpointSseHeaders#envRef
     */
    readonly envRef?: string;
    /**
     * Name of the property.
     *
     * @schema McpServerSpecEndpointSseHeaders#name
     */
    readonly name: string;
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema McpServerSpecEndpointSseHeaders#secretKeyRef
     */
    readonly secretKeyRef?: McpServerSpecEndpointSseHeadersSecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema McpServerSpecEndpointSseHeaders#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseHeaders' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointSseHeaders(obj: McpServerSpecEndpointSseHeaders | undefined): Record<string, any> | undefined;
/**
 * NameValuePair is a name/value pair.
 *
 * @schema McpServerSpecEndpointStdioEnv
 */
export interface McpServerSpecEndpointStdioEnv {
    /**
     * EnvRef is the name of an environmental variable to read the value from.
     *
     * @schema McpServerSpecEndpointStdioEnv#envRef
     */
    readonly envRef?: string;
    /**
     * Name of the property.
     *
     * @schema McpServerSpecEndpointStdioEnv#name
     */
    readonly name: string;
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema McpServerSpecEndpointStdioEnv#secretKeyRef
     */
    readonly secretKeyRef?: McpServerSpecEndpointStdioEnvSecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema McpServerSpecEndpointStdioEnv#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStdioEnv' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStdioEnv(obj: McpServerSpecEndpointStdioEnv | undefined): Record<string, any> | undefined;
/**
 * Auth configures authentication for the MCP server connection.
 *
 * @schema McpServerSpecEndpointStreamableHttpAuth
 */
export interface McpServerSpecEndpointStreamableHttpAuth {
    /**
     * OAuth2 configures OAuth2 client credentials flow for the MCP server.
     *
     * @schema McpServerSpecEndpointStreamableHttpAuth#oauth2
     */
    readonly oauth2?: McpServerSpecEndpointStreamableHttpAuthOauth2;
    /**
     * SecretStore names the Dapr secret store used to resolve secretKeyRef entries
     * in spec.endpoint.http.headers. auth.oauth2.secretKeyRef is resolved separately
     * at call time by the MCP worker. Defaults to "kubernetes".
     *
     * @default kubernetes".
     * @schema McpServerSpecEndpointStreamableHttpAuth#secretStore
     */
    readonly secretStore?: string;
    /**
     * SPIFFE configures workload identity JWT injection via Dapr's Sentry CA.
     * No secret is required; Sentry issues the SVID automatically.
     *
     * @schema McpServerSpecEndpointStreamableHttpAuth#spiffe
     */
    readonly spiffe?: McpServerSpecEndpointStreamableHttpAuthSpiffe;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuth' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStreamableHttpAuth(obj: McpServerSpecEndpointStreamableHttpAuth | undefined): Record<string, any> | undefined;
/**
 * NameValuePair is a name/value pair.
 *
 * @schema McpServerSpecEndpointStreamableHttpHeaders
 */
export interface McpServerSpecEndpointStreamableHttpHeaders {
    /**
     * EnvRef is the name of an environmental variable to read the value from.
     *
     * @schema McpServerSpecEndpointStreamableHttpHeaders#envRef
     */
    readonly envRef?: string;
    /**
     * Name of the property.
     *
     * @schema McpServerSpecEndpointStreamableHttpHeaders#name
     */
    readonly name: string;
    /**
     * SecretKeyRef is the reference of a value in a secret store component.
     *
     * @schema McpServerSpecEndpointStreamableHttpHeaders#secretKeyRef
     */
    readonly secretKeyRef?: McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef;
    /**
     * Value of the property, in plaintext.
     *
     * @schema McpServerSpecEndpointStreamableHttpHeaders#value
     */
    readonly value?: any;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpHeaders' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStreamableHttpHeaders(obj: McpServerSpecEndpointStreamableHttpHeaders | undefined): Record<string, any> | undefined;
/**
 * Workflow is the Dapr workflow to invoke as the hook.
 *
 * @schema McpServerSpecMiddlewareAfterCallToolWorkflow
 */
export interface McpServerSpecMiddlewareAfterCallToolWorkflow {
    /**
     * AppID targets the workflow on a remote Dapr app via service invocation.
     * When unset, the workflow is invoked locally.
     *
     * @schema McpServerSpecMiddlewareAfterCallToolWorkflow#appID
     */
    readonly appId?: string;
    /**
     * WorkflowName is the name of the workflow to invoke.
     *
     * @schema McpServerSpecMiddlewareAfterCallToolWorkflow#workflowName
     */
    readonly workflowName: string;
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareAfterCallToolWorkflow' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddlewareAfterCallToolWorkflow(obj: McpServerSpecMiddlewareAfterCallToolWorkflow | undefined): Record<string, any> | undefined;
/**
 * Workflow is the Dapr workflow to invoke as the hook.
 *
 * @schema McpServerSpecMiddlewareAfterListToolsWorkflow
 */
export interface McpServerSpecMiddlewareAfterListToolsWorkflow {
    /**
     * AppID targets the workflow on a remote Dapr app via service invocation.
     * When unset, the workflow is invoked locally.
     *
     * @schema McpServerSpecMiddlewareAfterListToolsWorkflow#appID
     */
    readonly appId?: string;
    /**
     * WorkflowName is the name of the workflow to invoke.
     *
     * @schema McpServerSpecMiddlewareAfterListToolsWorkflow#workflowName
     */
    readonly workflowName: string;
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareAfterListToolsWorkflow' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddlewareAfterListToolsWorkflow(obj: McpServerSpecMiddlewareAfterListToolsWorkflow | undefined): Record<string, any> | undefined;
/**
 * Workflow is the Dapr workflow to invoke as the hook.
 *
 * @schema McpServerSpecMiddlewareBeforeCallToolWorkflow
 */
export interface McpServerSpecMiddlewareBeforeCallToolWorkflow {
    /**
     * AppID targets the workflow on a remote Dapr app via service invocation.
     * When unset, the workflow is invoked locally.
     *
     * @schema McpServerSpecMiddlewareBeforeCallToolWorkflow#appID
     */
    readonly appId?: string;
    /**
     * WorkflowName is the name of the workflow to invoke.
     *
     * @schema McpServerSpecMiddlewareBeforeCallToolWorkflow#workflowName
     */
    readonly workflowName: string;
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareBeforeCallToolWorkflow' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddlewareBeforeCallToolWorkflow(obj: McpServerSpecMiddlewareBeforeCallToolWorkflow | undefined): Record<string, any> | undefined;
/**
 * Workflow is the Dapr workflow to invoke as the hook.
 *
 * @schema McpServerSpecMiddlewareBeforeListToolsWorkflow
 */
export interface McpServerSpecMiddlewareBeforeListToolsWorkflow {
    /**
     * AppID targets the workflow on a remote Dapr app via service invocation.
     * When unset, the workflow is invoked locally.
     *
     * @schema McpServerSpecMiddlewareBeforeListToolsWorkflow#appID
     */
    readonly appId?: string;
    /**
     * WorkflowName is the name of the workflow to invoke.
     *
     * @schema McpServerSpecMiddlewareBeforeListToolsWorkflow#workflowName
     */
    readonly workflowName: string;
}
/**
 * Converts an object of type 'McpServerSpecMiddlewareBeforeListToolsWorkflow' to JSON representation.
 */
export declare function toJson_McpServerSpecMiddlewareBeforeListToolsWorkflow(obj: McpServerSpecMiddlewareBeforeListToolsWorkflow | undefined): Record<string, any> | undefined;
/**
 * OAuth2 configures OAuth2 client credentials flow for the MCP server.
 *
 * @schema McpServerSpecEndpointSseAuthOauth2
 */
export interface McpServerSpecEndpointSseAuthOauth2 {
    /**
     * @schema McpServerSpecEndpointSseAuthOauth2#audience
     */
    readonly audience?: string;
    /**
     * ClientID is the OAuth2 client identifier sent to the token endpoint.
     * Required by RFC 6749 for the standard client_credentials flow (form parameter
     * or HTTP Basic username). May be left empty for non-standard flows (e.g. JWT-bearer
     * assertions or token endpoints that key solely on the client_secret). Client IDs
     * are typically public identifiers; use spec.headers with a secretKeyRef if your
     * environment requires sourcing the value from a secret store.
     *
     * @schema McpServerSpecEndpointSseAuthOauth2#clientID
     */
    readonly clientId?: string;
    /**
     * Issuer is the token endpoint of the authorization server.
     *
     * @schema McpServerSpecEndpointSseAuthOauth2#issuer
     */
    readonly issuer: string;
    /**
     * @schema McpServerSpecEndpointSseAuthOauth2#scopes
     */
    readonly scopes?: string[];
    /**
     * SecretKeyRef references the client secret in the configured secret store.
     *
     * @schema McpServerSpecEndpointSseAuthOauth2#secretKeyRef
     */
    readonly secretKeyRef?: McpServerSpecEndpointSseAuthOauth2SecretKeyRef;
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuthOauth2' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointSseAuthOauth2(obj: McpServerSpecEndpointSseAuthOauth2 | undefined): Record<string, any> | undefined;
/**
 * SPIFFE configures workload identity JWT injection via Dapr's Sentry CA.
 * No secret is required; Sentry issues the SVID automatically.
 *
 * @schema McpServerSpecEndpointSseAuthSpiffe
 */
export interface McpServerSpecEndpointSseAuthSpiffe {
    /**
     * JWT configures how the SPIFFE SVID JWT is attached to outbound requests.
     *
     * @schema McpServerSpecEndpointSseAuthSpiffe#jwt
     */
    readonly jwt?: McpServerSpecEndpointSseAuthSpiffeJwt;
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuthSpiffe' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointSseAuthSpiffe(obj: McpServerSpecEndpointSseAuthSpiffe | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema McpServerSpecEndpointSseHeadersSecretKeyRef
 */
export interface McpServerSpecEndpointSseHeadersSecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema McpServerSpecEndpointSseHeadersSecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema McpServerSpecEndpointSseHeadersSecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseHeadersSecretKeyRef' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointSseHeadersSecretKeyRef(obj: McpServerSpecEndpointSseHeadersSecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema McpServerSpecEndpointStdioEnvSecretKeyRef
 */
export interface McpServerSpecEndpointStdioEnvSecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema McpServerSpecEndpointStdioEnvSecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema McpServerSpecEndpointStdioEnvSecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStdioEnvSecretKeyRef' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStdioEnvSecretKeyRef(obj: McpServerSpecEndpointStdioEnvSecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * OAuth2 configures OAuth2 client credentials flow for the MCP server.
 *
 * @schema McpServerSpecEndpointStreamableHttpAuthOauth2
 */
export interface McpServerSpecEndpointStreamableHttpAuthOauth2 {
    /**
     * @schema McpServerSpecEndpointStreamableHttpAuthOauth2#audience
     */
    readonly audience?: string;
    /**
     * ClientID is the OAuth2 client identifier sent to the token endpoint.
     * Required by RFC 6749 for the standard client_credentials flow (form parameter
     * or HTTP Basic username). May be left empty for non-standard flows (e.g. JWT-bearer
     * assertions or token endpoints that key solely on the client_secret). Client IDs
     * are typically public identifiers; use spec.headers with a secretKeyRef if your
     * environment requires sourcing the value from a secret store.
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthOauth2#clientID
     */
    readonly clientId?: string;
    /**
     * Issuer is the token endpoint of the authorization server.
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthOauth2#issuer
     */
    readonly issuer: string;
    /**
     * @schema McpServerSpecEndpointStreamableHttpAuthOauth2#scopes
     */
    readonly scopes?: string[];
    /**
     * SecretKeyRef references the client secret in the configured secret store.
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthOauth2#secretKeyRef
     */
    readonly secretKeyRef?: McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuthOauth2' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStreamableHttpAuthOauth2(obj: McpServerSpecEndpointStreamableHttpAuthOauth2 | undefined): Record<string, any> | undefined;
/**
 * SPIFFE configures workload identity JWT injection via Dapr's Sentry CA.
 * No secret is required; Sentry issues the SVID automatically.
 *
 * @schema McpServerSpecEndpointStreamableHttpAuthSpiffe
 */
export interface McpServerSpecEndpointStreamableHttpAuthSpiffe {
    /**
     * JWT configures how the SPIFFE SVID JWT is attached to outbound requests.
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthSpiffe#jwt
     */
    readonly jwt?: McpServerSpecEndpointStreamableHttpAuthSpiffeJwt;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuthSpiffe' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStreamableHttpAuthSpiffe(obj: McpServerSpecEndpointStreamableHttpAuthSpiffe | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef is the reference of a value in a secret store component.
 *
 * @schema McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef
 */
export interface McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef(obj: McpServerSpecEndpointStreamableHttpHeadersSecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef references the client secret in the configured secret store.
 *
 * @schema McpServerSpecEndpointSseAuthOauth2SecretKeyRef
 */
export interface McpServerSpecEndpointSseAuthOauth2SecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema McpServerSpecEndpointSseAuthOauth2SecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema McpServerSpecEndpointSseAuthOauth2SecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuthOauth2SecretKeyRef' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointSseAuthOauth2SecretKeyRef(obj: McpServerSpecEndpointSseAuthOauth2SecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * JWT configures how the SPIFFE SVID JWT is attached to outbound requests.
 *
 * @schema McpServerSpecEndpointSseAuthSpiffeJwt
 */
export interface McpServerSpecEndpointSseAuthSpiffeJwt {
    /**
     * Audience is the intended audience for the JWT (e.g. "mcp://payments").
     *
     * @schema McpServerSpecEndpointSseAuthSpiffeJwt#audience
     */
    readonly audience: string;
    /**
     * Header is the HTTP header name to inject the JWT into (e.g. "Authorization").
     *
     * @schema McpServerSpecEndpointSseAuthSpiffeJwt#header
     */
    readonly header: string;
    /**
     * HeaderValuePrefix is an optional string prepended to the JWT value (e.g. "Bearer ").
     *
     * @schema McpServerSpecEndpointSseAuthSpiffeJwt#headerValuePrefix
     */
    readonly headerValuePrefix?: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointSseAuthSpiffeJwt' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointSseAuthSpiffeJwt(obj: McpServerSpecEndpointSseAuthSpiffeJwt | undefined): Record<string, any> | undefined;
/**
 * SecretKeyRef references the client secret in the configured secret store.
 *
 * @schema McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef
 */
export interface McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef {
    /**
     * Field in the secret.
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef#key
     */
    readonly key?: string;
    /**
     * Secret name.
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef(obj: McpServerSpecEndpointStreamableHttpAuthOauth2SecretKeyRef | undefined): Record<string, any> | undefined;
/**
 * JWT configures how the SPIFFE SVID JWT is attached to outbound requests.
 *
 * @schema McpServerSpecEndpointStreamableHttpAuthSpiffeJwt
 */
export interface McpServerSpecEndpointStreamableHttpAuthSpiffeJwt {
    /**
     * Audience is the intended audience for the JWT (e.g. "mcp://payments").
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthSpiffeJwt#audience
     */
    readonly audience: string;
    /**
     * Header is the HTTP header name to inject the JWT into (e.g. "Authorization").
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthSpiffeJwt#header
     */
    readonly header: string;
    /**
     * HeaderValuePrefix is an optional string prepended to the JWT value (e.g. "Bearer ").
     *
     * @schema McpServerSpecEndpointStreamableHttpAuthSpiffeJwt#headerValuePrefix
     */
    readonly headerValuePrefix?: string;
}
/**
 * Converts an object of type 'McpServerSpecEndpointStreamableHttpAuthSpiffeJwt' to JSON representation.
 */
export declare function toJson_McpServerSpecEndpointStreamableHttpAuthSpiffeJwt(obj: McpServerSpecEndpointStreamableHttpAuthSpiffeJwt | undefined): Record<string, any> | undefined;
/**
 *
 *
 * @schema Resiliency
 */
export declare class Resiliency extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Resiliency"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Resiliency".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: ResiliencyProps): any;
    /**
     * Defines a "Resiliency" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: ResiliencyProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * @schema Resiliency
 */
export interface ResiliencyProps {
    /**
     * @schema Resiliency#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * @schema Resiliency#scopes
     */
    readonly scopes?: string[];
    /**
     * @schema Resiliency#spec
     */
    readonly spec?: ResiliencySpec;
}
/**
 * Converts an object of type 'ResiliencyProps' to JSON representation.
 */
export declare function toJson_ResiliencyProps(obj: ResiliencyProps | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpec
 */
export interface ResiliencySpec {
    /**
     * @schema ResiliencySpec#policies
     */
    readonly policies: ResiliencySpecPolicies;
    /**
     * @schema ResiliencySpec#targets
     */
    readonly targets: ResiliencySpecTargets;
}
/**
 * Converts an object of type 'ResiliencySpec' to JSON representation.
 */
export declare function toJson_ResiliencySpec(obj: ResiliencySpec | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecPolicies
 */
export interface ResiliencySpecPolicies {
    /**
     * @schema ResiliencySpecPolicies#circuitBreakers
     */
    readonly circuitBreakers?: {
        [key: string]: ResiliencySpecPoliciesCircuitBreakers;
    };
    /**
     * @schema ResiliencySpecPolicies#retries
     */
    readonly retries?: {
        [key: string]: ResiliencySpecPoliciesRetries;
    };
    /**
     * @schema ResiliencySpecPolicies#timeouts
     */
    readonly timeouts?: {
        [key: string]: string;
    };
}
/**
 * Converts an object of type 'ResiliencySpecPolicies' to JSON representation.
 */
export declare function toJson_ResiliencySpecPolicies(obj: ResiliencySpecPolicies | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecTargets
 */
export interface ResiliencySpecTargets {
    /**
     * @schema ResiliencySpecTargets#actors
     */
    readonly actors?: {
        [key: string]: ResiliencySpecTargetsActors;
    };
    /**
     * @schema ResiliencySpecTargets#apps
     */
    readonly apps?: {
        [key: string]: ResiliencySpecTargetsApps;
    };
    /**
     * @schema ResiliencySpecTargets#components
     */
    readonly components?: {
        [key: string]: ResiliencySpecTargetsComponents;
    };
}
/**
 * Converts an object of type 'ResiliencySpecTargets' to JSON representation.
 */
export declare function toJson_ResiliencySpecTargets(obj: ResiliencySpecTargets | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecPoliciesCircuitBreakers
 */
export interface ResiliencySpecPoliciesCircuitBreakers {
    /**
     * @schema ResiliencySpecPoliciesCircuitBreakers#interval
     */
    readonly interval?: string;
    /**
     * @schema ResiliencySpecPoliciesCircuitBreakers#maxRequests
     */
    readonly maxRequests?: number;
    /**
     * @schema ResiliencySpecPoliciesCircuitBreakers#timeout
     */
    readonly timeout?: string;
    /**
     * @schema ResiliencySpecPoliciesCircuitBreakers#trip
     */
    readonly trip?: string;
}
/**
 * Converts an object of type 'ResiliencySpecPoliciesCircuitBreakers' to JSON representation.
 */
export declare function toJson_ResiliencySpecPoliciesCircuitBreakers(obj: ResiliencySpecPoliciesCircuitBreakers | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecPoliciesRetries
 */
export interface ResiliencySpecPoliciesRetries {
    /**
     * @schema ResiliencySpecPoliciesRetries#duration
     */
    readonly duration?: string;
    /**
     * RetryMatching represents the rules to trigger retry in specific scenarios.
     *
     * @schema ResiliencySpecPoliciesRetries#matching
     */
    readonly matching?: ResiliencySpecPoliciesRetriesMatching;
    /**
     * @schema ResiliencySpecPoliciesRetries#maxInterval
     */
    readonly maxInterval?: string;
    /**
     * @schema ResiliencySpecPoliciesRetries#maxRetries
     */
    readonly maxRetries?: number;
    /**
     * @schema ResiliencySpecPoliciesRetries#policy
     */
    readonly policy?: string;
}
/**
 * Converts an object of type 'ResiliencySpecPoliciesRetries' to JSON representation.
 */
export declare function toJson_ResiliencySpecPoliciesRetries(obj: ResiliencySpecPoliciesRetries | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecTargetsActors
 */
export interface ResiliencySpecTargetsActors {
    /**
     * @schema ResiliencySpecTargetsActors#circuitBreaker
     */
    readonly circuitBreaker?: string;
    /**
     * @schema ResiliencySpecTargetsActors#circuitBreakerCacheSize
     */
    readonly circuitBreakerCacheSize?: number;
    /**
     * @schema ResiliencySpecTargetsActors#circuitBreakerScope
     */
    readonly circuitBreakerScope?: string;
    /**
     * @schema ResiliencySpecTargetsActors#retry
     */
    readonly retry?: string;
    /**
     * @schema ResiliencySpecTargetsActors#timeout
     */
    readonly timeout?: string;
}
/**
 * Converts an object of type 'ResiliencySpecTargetsActors' to JSON representation.
 */
export declare function toJson_ResiliencySpecTargetsActors(obj: ResiliencySpecTargetsActors | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecTargetsApps
 */
export interface ResiliencySpecTargetsApps {
    /**
     * @schema ResiliencySpecTargetsApps#circuitBreaker
     */
    readonly circuitBreaker?: string;
    /**
     * @schema ResiliencySpecTargetsApps#circuitBreakerCacheSize
     */
    readonly circuitBreakerCacheSize?: number;
    /**
     * @schema ResiliencySpecTargetsApps#retry
     */
    readonly retry?: string;
    /**
     * @schema ResiliencySpecTargetsApps#timeout
     */
    readonly timeout?: string;
}
/**
 * Converts an object of type 'ResiliencySpecTargetsApps' to JSON representation.
 */
export declare function toJson_ResiliencySpecTargetsApps(obj: ResiliencySpecTargetsApps | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecTargetsComponents
 */
export interface ResiliencySpecTargetsComponents {
    /**
     * @schema ResiliencySpecTargetsComponents#inbound
     */
    readonly inbound?: ResiliencySpecTargetsComponentsInbound;
    /**
     * @schema ResiliencySpecTargetsComponents#outbound
     */
    readonly outbound?: ResiliencySpecTargetsComponentsOutbound;
}
/**
 * Converts an object of type 'ResiliencySpecTargetsComponents' to JSON representation.
 */
export declare function toJson_ResiliencySpecTargetsComponents(obj: ResiliencySpecTargetsComponents | undefined): Record<string, any> | undefined;
/**
 * RetryMatching represents the rules to trigger retry in specific scenarios.
 *
 * @schema ResiliencySpecPoliciesRetriesMatching
 */
export interface ResiliencySpecPoliciesRetriesMatching {
    /**
     * GRPCStatusCodes represents gRPC status codes to be retried.
     *
     * @schema ResiliencySpecPoliciesRetriesMatching#gRPCStatusCodes
     */
    readonly gRpcStatusCodes?: string;
    /**
     * HTTPStatusCodes represents HTTP status codes to be retried.
     *
     * @schema ResiliencySpecPoliciesRetriesMatching#httpStatusCodes
     */
    readonly httpStatusCodes?: string;
}
/**
 * Converts an object of type 'ResiliencySpecPoliciesRetriesMatching' to JSON representation.
 */
export declare function toJson_ResiliencySpecPoliciesRetriesMatching(obj: ResiliencySpecPoliciesRetriesMatching | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecTargetsComponentsInbound
 */
export interface ResiliencySpecTargetsComponentsInbound {
    /**
     * @schema ResiliencySpecTargetsComponentsInbound#circuitBreaker
     */
    readonly circuitBreaker?: string;
    /**
     * @schema ResiliencySpecTargetsComponentsInbound#retry
     */
    readonly retry?: string;
    /**
     * @schema ResiliencySpecTargetsComponentsInbound#timeout
     */
    readonly timeout?: string;
}
/**
 * Converts an object of type 'ResiliencySpecTargetsComponentsInbound' to JSON representation.
 */
export declare function toJson_ResiliencySpecTargetsComponentsInbound(obj: ResiliencySpecTargetsComponentsInbound | undefined): Record<string, any> | undefined;
/**
 * @schema ResiliencySpecTargetsComponentsOutbound
 */
export interface ResiliencySpecTargetsComponentsOutbound {
    /**
     * @schema ResiliencySpecTargetsComponentsOutbound#circuitBreaker
     */
    readonly circuitBreaker?: string;
    /**
     * @schema ResiliencySpecTargetsComponentsOutbound#retry
     */
    readonly retry?: string;
    /**
     * @schema ResiliencySpecTargetsComponentsOutbound#timeout
     */
    readonly timeout?: string;
}
/**
 * Converts an object of type 'ResiliencySpecTargetsComponentsOutbound' to JSON representation.
 */
export declare function toJson_ResiliencySpecTargetsComponentsOutbound(obj: ResiliencySpecTargetsComponentsOutbound | undefined): Record<string, any> | undefined;
/**
 * Subscription describes an pub/sub event subscription.
 *
 * @schema Subscription
 */
export declare class Subscription extends ApiObject {
    /**
     * Returns the apiVersion and kind for "Subscription"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "Subscription".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: SubscriptionProps): any;
    /**
     * Defines a "Subscription" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: SubscriptionProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * Subscription describes an pub/sub event subscription.
 *
 * @schema Subscription
 */
export interface SubscriptionProps {
    /**
     * @schema Subscription#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * @schema Subscription#scopes
     */
    readonly scopes?: string[];
    /**
     * SubscriptionSpec is the spec for an event subscription.
     *
     * @schema Subscription#spec
     */
    readonly spec?: SubscriptionSpec;
}
/**
 * Converts an object of type 'SubscriptionProps' to JSON representation.
 */
export declare function toJson_SubscriptionProps(obj: SubscriptionProps | undefined): Record<string, any> | undefined;
/**
 * SubscriptionSpec is the spec for an event subscription.
 *
 * @schema SubscriptionSpec
 */
export interface SubscriptionSpec {
    /**
     * BulkSubscribe encapsulates the bulk subscription configuration for a topic.
     *
     * @schema SubscriptionSpec#bulkSubscribe
     */
    readonly bulkSubscribe?: SubscriptionSpecBulkSubscribe;
    /**
     * @schema SubscriptionSpec#deadLetterTopic
     */
    readonly deadLetterTopic?: string;
    /**
     * @schema SubscriptionSpec#metadata
     */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
     * @schema SubscriptionSpec#pubsubname
     */
    readonly pubsubname: string;
    /**
     * @schema SubscriptionSpec#route
     */
    readonly route: string;
    /**
     * @schema SubscriptionSpec#topic
     */
    readonly topic: string;
}
/**
 * Converts an object of type 'SubscriptionSpec' to JSON representation.
 */
export declare function toJson_SubscriptionSpec(obj: SubscriptionSpec | undefined): Record<string, any> | undefined;
/**
 * BulkSubscribe encapsulates the bulk subscription configuration for a topic.
 *
 * @schema SubscriptionSpecBulkSubscribe
 */
export interface SubscriptionSpecBulkSubscribe {
    /**
     * @schema SubscriptionSpecBulkSubscribe#enabled
     */
    readonly enabled: boolean;
    /**
     * @schema SubscriptionSpecBulkSubscribe#maxAwaitDurationMs
     */
    readonly maxAwaitDurationMs?: number;
    /**
     * @schema SubscriptionSpecBulkSubscribe#maxMessagesCount
     */
    readonly maxMessagesCount?: number;
}
/**
 * Converts an object of type 'SubscriptionSpecBulkSubscribe' to JSON representation.
 */
export declare function toJson_SubscriptionSpecBulkSubscribe(obj: SubscriptionSpecBulkSubscribe | undefined): Record<string, any> | undefined;
/**
 * Subscription describes an pub/sub event subscription.
 *
 * @schema SubscriptionV2Alpha1
 */
export declare class SubscriptionV2Alpha1 extends ApiObject {
    /**
     * Returns the apiVersion and kind for "SubscriptionV2Alpha1"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "SubscriptionV2Alpha1".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: SubscriptionV2Alpha1Props): any;
    /**
     * Defines a "SubscriptionV2Alpha1" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: SubscriptionV2Alpha1Props);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * Subscription describes an pub/sub event subscription.
 *
 * @schema SubscriptionV2Alpha1
 */
export interface SubscriptionV2Alpha1Props {
    /**
     * @schema SubscriptionV2Alpha1#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * @schema SubscriptionV2Alpha1#scopes
     */
    readonly scopes?: string[];
    /**
     * SubscriptionSpec is the spec for an event subscription.
     *
     * @schema SubscriptionV2Alpha1#spec
     */
    readonly spec?: SubscriptionV2Alpha1Spec;
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1Props' to JSON representation.
 */
export declare function toJson_SubscriptionV2Alpha1Props(obj: SubscriptionV2Alpha1Props | undefined): Record<string, any> | undefined;
/**
 * SubscriptionSpec is the spec for an event subscription.
 *
 * @schema SubscriptionV2Alpha1Spec
 */
export interface SubscriptionV2Alpha1Spec {
    /**
     * The option to enable bulk subscription for this topic.
     *
     * @schema SubscriptionV2Alpha1Spec#bulkSubscribe
     */
    readonly bulkSubscribe?: SubscriptionV2Alpha1SpecBulkSubscribe;
    /**
     * The optional dead letter queue for this topic to send events to.
     *
     * @schema SubscriptionV2Alpha1Spec#deadLetterTopic
     */
    readonly deadLetterTopic?: string;
    /**
     * The optional metadata to provide the subscription.
     *
     * @schema SubscriptionV2Alpha1Spec#metadata
     */
    readonly metadata?: {
        [key: string]: string;
    };
    /**
     * The PubSub component name.
     *
     * @schema SubscriptionV2Alpha1Spec#pubsubname
     */
    readonly pubsubname: string;
    /**
     * The Routes configuration for this topic.
     *
     * @schema SubscriptionV2Alpha1Spec#routes
     */
    readonly routes: SubscriptionV2Alpha1SpecRoutes;
    /**
     * The topic name to subscribe to.
     *
     * @schema SubscriptionV2Alpha1Spec#topic
     */
    readonly topic: string;
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1Spec' to JSON representation.
 */
export declare function toJson_SubscriptionV2Alpha1Spec(obj: SubscriptionV2Alpha1Spec | undefined): Record<string, any> | undefined;
/**
 * The option to enable bulk subscription for this topic.
 *
 * @schema SubscriptionV2Alpha1SpecBulkSubscribe
 */
export interface SubscriptionV2Alpha1SpecBulkSubscribe {
    /**
     * @schema SubscriptionV2Alpha1SpecBulkSubscribe#enabled
     */
    readonly enabled: boolean;
    /**
     * @schema SubscriptionV2Alpha1SpecBulkSubscribe#maxAwaitDurationMs
     */
    readonly maxAwaitDurationMs?: number;
    /**
     * @schema SubscriptionV2Alpha1SpecBulkSubscribe#maxMessagesCount
     */
    readonly maxMessagesCount?: number;
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1SpecBulkSubscribe' to JSON representation.
 */
export declare function toJson_SubscriptionV2Alpha1SpecBulkSubscribe(obj: SubscriptionV2Alpha1SpecBulkSubscribe | undefined): Record<string, any> | undefined;
/**
 * The Routes configuration for this topic.
 *
 * @schema SubscriptionV2Alpha1SpecRoutes
 */
export interface SubscriptionV2Alpha1SpecRoutes {
    /**
     * The default path for this topic.
     *
     * @schema SubscriptionV2Alpha1SpecRoutes#default
     */
    readonly default?: string;
    /**
     * The list of rules for this topic.
     *
     * @schema SubscriptionV2Alpha1SpecRoutes#rules
     */
    readonly rules?: SubscriptionV2Alpha1SpecRoutesRules[];
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1SpecRoutes' to JSON representation.
 */
export declare function toJson_SubscriptionV2Alpha1SpecRoutes(obj: SubscriptionV2Alpha1SpecRoutes | undefined): Record<string, any> | undefined;
/**
 * Rule is used to specify the condition for sending
 * a message to a specific path.
 *
 * @schema SubscriptionV2Alpha1SpecRoutesRules
 */
export interface SubscriptionV2Alpha1SpecRoutesRules {
    /**
     * The optional CEL expression used to match the event.
     * If the match is not specified, then the route is considered
     * the default. The rules are tested in the order specified,
     * so they should be define from most-to-least specific.
     * The default route should appear last in the list.
     *
     * @schema SubscriptionV2Alpha1SpecRoutesRules#match
     */
    readonly match: string;
    /**
     * The path for events that match this rule.
     *
     * @schema SubscriptionV2Alpha1SpecRoutesRules#path
     */
    readonly path: string;
}
/**
 * Converts an object of type 'SubscriptionV2Alpha1SpecRoutesRules' to JSON representation.
 */
export declare function toJson_SubscriptionV2Alpha1SpecRoutesRules(obj: SubscriptionV2Alpha1SpecRoutesRules | undefined): Record<string, any> | undefined;
/**
 * WorkflowAccessPolicy controls which app IDs are permitted to schedule
specific workflows and activities on a target application.
 *
 * @schema WorkflowAccessPolicy
 */
export declare class WorkflowAccessPolicy extends ApiObject {
    /**
     * Returns the apiVersion and kind for "WorkflowAccessPolicy"
     */
    static readonly GVK: GroupVersionKind;
    /**
     * Renders a Kubernetes manifest for "WorkflowAccessPolicy".
     *
     * This can be used to inline resource manifests inside other objects (e.g. as templates).
     *
     * @param props initialization props
     */
    static manifest(props?: WorkflowAccessPolicyProps): any;
    /**
     * Defines a "WorkflowAccessPolicy" API object
     * @param scope the scope in which to define this object
     * @param id a scope-local name for the object
     * @param props initialization props
     */
    constructor(scope: Construct, id: string, props?: WorkflowAccessPolicyProps);
    /**
     * Renders the object to Kubernetes JSON.
     */
    toJson(): any;
}
/**
 * WorkflowAccessPolicy controls which app IDs are permitted to schedule
 * specific workflows and activities on a target application.
 *
 * @schema WorkflowAccessPolicy
 */
export interface WorkflowAccessPolicyProps {
    /**
     * @schema WorkflowAccessPolicy#metadata
     */
    readonly metadata?: ApiObjectMetadata;
    /**
     * @schema WorkflowAccessPolicy#scopes
     */
    readonly scopes?: string[];
    /**
     * WorkflowAccessPolicySpec defines the desired state of WorkflowAccessPolicy.
     *
     * @schema WorkflowAccessPolicy#spec
     */
    readonly spec?: WorkflowAccessPolicySpec;
}
/**
 * Converts an object of type 'WorkflowAccessPolicyProps' to JSON representation.
 */
export declare function toJson_WorkflowAccessPolicyProps(obj: WorkflowAccessPolicyProps | undefined): Record<string, any> | undefined;
/**
 * WorkflowAccessPolicySpec defines the desired state of WorkflowAccessPolicy.
 *
 * @schema WorkflowAccessPolicySpec
 */
export interface WorkflowAccessPolicySpec {
    /**
     * Rules defines the allow-list of which callers can perform which operations.
     *
     * @schema WorkflowAccessPolicySpec#rules
     */
    readonly rules?: WorkflowAccessPolicySpecRules[];
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpec' to JSON representation.
 */
export declare function toJson_WorkflowAccessPolicySpec(obj: WorkflowAccessPolicySpec | undefined): Record<string, any> | undefined;
/**
 * WorkflowAccessPolicyRule grants the listed callers access to the listed
 * workflows and/or activities. Presence of a matching rule grants access; if
 * no rule matches, the call is denied. At least one of workflows or
 * activities must be set.
 *
 * @schema WorkflowAccessPolicySpecRules
 */
export interface WorkflowAccessPolicySpecRules {
    /**
     * Activities are the activity rules that the matched callers are allowed.
     *
     * @schema WorkflowAccessPolicySpecRules#activities
     */
    readonly activities?: WorkflowAccessPolicySpecRulesActivities[];
    /**
     * Callers that this rule applies to.
     *
     * @schema WorkflowAccessPolicySpecRules#callers
     */
    readonly callers: WorkflowAccessPolicySpecRulesCallers[];
    /**
     * Workflows are the workflow rules that the matched callers are allowed.
     *
     * @schema WorkflowAccessPolicySpecRules#workflows
     */
    readonly workflows?: WorkflowAccessPolicySpecRulesWorkflows[];
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpecRules' to JSON representation.
 */
export declare function toJson_WorkflowAccessPolicySpecRules(obj: WorkflowAccessPolicySpecRules | undefined): Record<string, any> | undefined;
/**
 * ActivityRule grants the matched callers access to schedule the activity
 * whose name matches Name (exact or glob). Activities only have one
 * operation (schedule).
 *
 * @schema WorkflowAccessPolicySpecRulesActivities
 */
export interface WorkflowAccessPolicySpecRulesActivities {
    /**
     * Name is the exact name or glob pattern for the activity.
     *
     * @schema WorkflowAccessPolicySpecRulesActivities#name
     */
    readonly name: string;
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpecRulesActivities' to JSON representation.
 */
export declare function toJson_WorkflowAccessPolicySpecRulesActivities(obj: WorkflowAccessPolicySpecRulesActivities | undefined): Record<string, any> | undefined;
/**
 * WorkflowCaller identifies a calling application.
 *
 * @schema WorkflowAccessPolicySpecRulesCallers
 */
export interface WorkflowAccessPolicySpecRulesCallers {
    /**
     * AppID is the Dapr app ID of the caller.
     *
     * @schema WorkflowAccessPolicySpecRulesCallers#appID
     */
    readonly appId: string;
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpecRulesCallers' to JSON representation.
 */
export declare function toJson_WorkflowAccessPolicySpecRulesCallers(obj: WorkflowAccessPolicySpecRulesCallers | undefined): Record<string, any> | undefined;
/**
 * WorkflowRule grants the matched callers access to the listed operations on
 * workflows whose name matches Name (exact or glob).
 *
 * @schema WorkflowAccessPolicySpecRulesWorkflows
 */
export interface WorkflowAccessPolicySpecRulesWorkflows {
    /**
     * Name is the exact name or glob pattern for the workflow.
     *
     * @schema WorkflowAccessPolicySpecRulesWorkflows#name
     */
    readonly name: string;
    /**
     * Operations is the set of operations this rule applies to.
     *
     * @schema WorkflowAccessPolicySpecRulesWorkflows#operations
     */
    readonly operations: WorkflowAccessPolicySpecRulesWorkflowsOperations[];
}
/**
 * Converts an object of type 'WorkflowAccessPolicySpecRulesWorkflows' to JSON representation.
 */
export declare function toJson_WorkflowAccessPolicySpecRulesWorkflows(obj: WorkflowAccessPolicySpecRulesWorkflows | undefined): Record<string, any> | undefined;
/**
 * WorkflowOperation is the specific workflow operation being controlled.
 *
 * @schema WorkflowAccessPolicySpecRulesWorkflowsOperations
 */
export declare enum WorkflowAccessPolicySpecRulesWorkflowsOperations {
    /** schedule */
    SCHEDULE = "schedule",
    /** terminate */
    TERMINATE = "terminate",
    /** raise */
    RAISE = "raise",
    /** pause */
    PAUSE = "pause",
    /** resume */
    RESUME = "resume",
    /** purge */
    PURGE = "purge",
    /** get */
    GET = "get",
    /** rerun */
    RERUN = "rerun"
}
